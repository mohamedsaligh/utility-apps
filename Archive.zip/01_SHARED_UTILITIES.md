# FILE 01 — SHARED UTILITIES (utils.py)
# Generate this file FIRST. Every phase script imports from it.

---

## INSTRUCTION TO AGENT

Generate a single Python file called `utils.py` that will be placed at `{PROJECT_ROOT}/.knowledge-base/utils.py`. This file contains ALL shared functionality used by every phase script. It must be completely self-contained — no external dependencies beyond standard library + cx_Oracle/oracledb + requests + pyyaml.

The file should be approximately 1200-1500 lines of Python code.

Required pip packages (install before running): `pyyaml`, `oracledb` (or `cx_Oracle`), `requests`

---

## SECTION 1: CONFIG LOADER

```python
"""
Class: Config
Purpose: Load and validate config.yml, provide typed access to all settings.
"""

import yaml
import os
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from pathlib import Path

@dataclass
class OracleConfig:
    """Oracle database connection settings."""
    enabled: bool = False
    host: str = ""
    port: int = 1521
    service_name: str = ""
    auth_method: str = "kerberos"          # "kerberos" or "password"
    keytab_path: str = ""                  # For Kerberos
    principal: str = ""                    # For Kerberos
    username: str = ""                     # For password auth
    password: str = ""                     # For password auth
    schema_owner: str = ""                 # Default schema
    additional_schemas: List[str] = field(default_factory=list)
    query_timeout_seconds: int = 30
    max_rows_for_distinct: int = 50000
    sample_row_count: int = 10

@dataclass
class GemfireConfig:
    """GemFire/Geode connection settings."""
    enabled: bool = False
    rest_api_url: str = ""                 # e.g. "http://host:7070/gemfire-api/v1"
    auth_username: str = ""
    auth_password: str = ""
    jmx_host: str = ""
    jmx_port: int = 1099
    max_entries_for_full_dump: int = 5000
    sample_entry_count: int = 10

@dataclass
class LLMConfig:
    """LLM calling configuration."""
    mode: str = "claude_code_cli"          # "claude_code_cli" | "copilot_file" | "api"
    claude_code_path: str = "claude"
    claude_model: str = "opus"
    copilot_workspace: str = ""
    api_endpoint: str = ""
    api_key: str = ""
    api_model: str = ""
    max_tokens_per_call: int = 8000
    max_context_tokens: int = 100000
    rate_limit_delay_seconds: int = 2
    max_retries: int = 3

@dataclass
class ProjectConfig:
    """Project structure settings."""
    root: str = ""                         # Absolute path to project root
    name: str = ""
    source_dirs: List[str] = field(default_factory=lambda: ["src/main/java", "src/main/resources"])
    test_dirs: List[str] = field(default_factory=lambda: ["src/test/java"])
    exclude_patterns: List[str] = field(default_factory=lambda: ["**/target/**", "**/build/**", "**/.git/**"])

@dataclass
class ValidationConfig:
    """Validation thresholds."""
    min_method_coverage_pct: int = 100
    min_branch_coverage_pct: int = 95
    min_data_link_pct: int = 100
    random_deep_verify_sample_size: int = 30
    deep_verify_min_score: int = 95

@dataclass
class KBConfig:
    """Knowledge base output settings."""
    output_dir: str = ""
    log_dir: str = ""
    max_validation_iterations: int = 5
    parallel_workers: int = 4
```

### Config.load() method specification:

```python
class Config:
    """
    Main config class. Call Config.load("config.yml") to get an instance.
    
    Implementation:
    1. Read YAML file
    2. Populate each dataclass from the corresponding YAML section
    3. Resolve template variables (e.g., {project.root} in output_dir)
    4. Validate required fields are present
    5. Create output directories if they don't exist
    6. Return populated Config instance
    
    The Config instance has attributes:
        .project (ProjectConfig)
        .oracle (OracleConfig)
        .gemfire (GemfireConfig)
        .llm (LLMConfig)
        .kb (KBConfig)
        .validation (ValidationConfig)
    
    Raise ValueError if:
        - project.root doesn't exist
        - project.root has no pom.xml (not a Maven project)
        - oracle.enabled but host is empty
        - gemfire.enabled but rest_api_url is empty
    """
```

---

## SECTION 2: ORACLE CONNECTION

```python
"""
Class: OracleConnection
Purpose: Manage Oracle DB connection with Kerberos or password auth.
         Provides 20+ query methods for metadata extraction.

CRITICAL IMPLEMENTATION DETAILS:
- Use oracledb (preferred) or cx_Oracle as the driver
- For Kerberos: run subprocess 'kinit -kt {keytab} {principal}' before connecting
- Connection string format: "{host}:{port}/{service_name}"
- Use a connection pool (min=1, max=4) for efficiency
- Every query method must have try/except, log errors, return empty result on failure
- Every query method accepts optional schema_name parameter (defaults to config.schema_owner)
- Use bind variables for all parameters (never f-string SQL)
- Set statement timeout to config.query_timeout_seconds
"""

class OracleConnection:
    def __init__(self, config: OracleConfig):
        """
        1. If auth_method == "kerberos":
           - Run: subprocess.run(["kinit", "-kt", config.keytab_path, config.principal])
           - Raise RuntimeError if kinit fails
           - Connect with external auth: oracledb.connect(externalauth=True, dsn=dsn)
        2. If auth_method == "password":
           - Connect with: oracledb.connect(user=config.username, password=config.password, dsn=dsn)
        3. Create connection pool: oracledb.create_pool(min=1, max=4, ...)
        4. Test connection with: SELECT 1 FROM DUAL
        5. Store pool as self._pool
        """
    
    def get_connection(self):
        """Get a connection from the pool. Use as context manager."""
    
    def close(self):
        """Close the connection pool."""

    # ─── SCHEMA QUERIES ───

    def get_table_schema(self, table_name: str, schema: str = None) -> List[Dict]:
        """
        Query: SELECT column_name, data_type, data_length, data_precision, 
               data_scale, nullable, data_default, column_id
               FROM all_tab_columns 
               WHERE table_name = :t AND owner = :s
               ORDER BY column_id
        
        Returns: List of dicts with keys: column_name, data_type, data_length, 
                 data_precision, data_scale, nullable, data_default, column_id
        
        IMPORTANT: table_name must be UPPER CASE. Oracle stores metadata in upper case.
        If no results, try:
          1. Check if it's a synonym: query all_synonyms for table_name
          2. Check if it's a view: query all_views for table_name
          3. Try each schema in config.additional_schemas
        """

    def get_primary_key(self, table_name: str, schema: str = None) -> List[str]:
        """
        Query: SELECT cols.column_name
               FROM all_constraints cons
               JOIN all_cons_columns cols 
                 ON cons.constraint_name = cols.constraint_name 
                 AND cons.owner = cols.owner
               WHERE cons.table_name = :t AND cons.owner = :s 
                 AND cons.constraint_type = 'P'
               ORDER BY cols.position
        
        Returns: List of column names forming the primary key.
        """

    def get_foreign_keys(self, table_name: str, schema: str = None) -> List[Dict]:
        """
        Query: SELECT a.column_name, 
                      c_pk.table_name as ref_table, 
                      c_pk.owner as ref_schema,
                      b.column_name as ref_column
               FROM all_cons_columns a
               JOIN all_constraints c ON a.constraint_name = c.constraint_name AND a.owner = c.owner
               JOIN all_constraints c_pk ON c.r_constraint_name = c_pk.constraint_name AND c.r_owner = c_pk.owner
               JOIN all_cons_columns b ON c_pk.constraint_name = b.constraint_name AND c_pk.owner = b.owner
               WHERE c.table_name = :t AND c.owner = :s AND c.constraint_type = 'R'
        
        Returns: List of dicts with keys: column_name, ref_table, ref_schema, ref_column
        
        CRITICAL: Every ref_table discovered here must be ADDED to the profiling queue.
        This is how FK chains are followed recursively.
        """

    def get_unique_constraints(self, table_name: str, schema: str = None) -> List[Dict]:
        """
        Query: SELECT cons.constraint_name, cols.column_name, cols.position
               FROM all_constraints cons
               JOIN all_cons_columns cols 
                 ON cons.constraint_name = cols.constraint_name AND cons.owner = cols.owner
               WHERE cons.table_name = :t AND cons.owner = :s 
                 AND cons.constraint_type = 'U'
               ORDER BY cons.constraint_name, cols.position
        
        Returns: List of dicts grouped by constraint_name.
        """

    def get_check_constraints(self, table_name: str, schema: str = None) -> List[Dict]:
        """
        Query: SELECT constraint_name, search_condition
               FROM all_constraints
               WHERE table_name = :t AND owner = :s AND constraint_type = 'C'
               AND constraint_name NOT LIKE 'SYS%'
        
        Returns: List of dicts with keys: constraint_name, search_condition
        Note: Filter out system-generated NOT NULL constraints (SYS_...)
        """

    def get_indexes(self, table_name: str, schema: str = None) -> List[Dict]:
        """
        Query: SELECT i.index_name, i.uniqueness, ic.column_name, ic.column_position
               FROM all_indexes i
               JOIN all_ind_columns ic ON i.index_name = ic.index_name AND i.owner = ic.index_owner
               WHERE i.table_name = :t AND i.owner = :s
               ORDER BY i.index_name, ic.column_position
        
        Returns: List of dicts grouped by index_name.
        """

    def get_row_count(self, table_name: str, schema: str = None) -> int:
        """
        Query: SELECT COUNT(*) FROM {schema}.{table_name}
        
        IMPORTANT: Use dynamic SQL with schema-qualified table name.
        Wrap in try/except — table might not have SELECT privilege.
        If COUNT(*) times out for very large tables, fall back to:
            SELECT num_rows FROM all_tables WHERE table_name = :t AND owner = :s
        (This uses statistics which may be stale but is fast.)
        
        Returns: Integer row count. Return -1 if query fails.
        """

    def get_distinct_values(self, table_name: str, column_name: str, schema: str = None, limit: int = 500) -> List[Dict]:
        """
        Query: SELECT {column_name}, COUNT(*) as frequency
               FROM {schema}.{table_name}
               GROUP BY {column_name}
               ORDER BY COUNT(*) DESC
               FETCH FIRST :limit ROWS ONLY
        
        Returns: List of dicts with keys: value, frequency
        
        IMPORTANT: Only run this for tables classified as LOOKUP or CONFIG.
        Skip if row_count > config.max_rows_for_distinct.
        """

    def get_sample_rows(self, table_name: str, schema: str = None, count: int = None) -> List[Dict]:
        """
        Query: SELECT * FROM {schema}.{table_name} 
               WHERE ROWNUM <= :count
        
        count defaults to config.sample_row_count.
        
        Returns: List of dicts, each dict is one row with column_name: value.
        Convert Oracle-specific types (DATE, TIMESTAMP, CLOB) to strings.
        """

    def get_triggers(self, table_name: str, schema: str = None) -> List[Dict]:
        """
        Query: SELECT trigger_name, trigger_type, triggering_event, trigger_body
               FROM all_triggers
               WHERE table_name = :t AND owner = :s
        
        Returns: List of dicts with trigger details.
        """

    def get_grants(self, table_name: str, schema: str = None) -> List[Dict]:
        """
        Query: SELECT grantee, privilege, grantable
               FROM all_tab_privs
               WHERE table_name = :t AND table_schema = :s
        
        Returns: List of dicts showing who can read/write this table.
        """

    def get_partitions(self, table_name: str, schema: str = None) -> List[Dict]:
        """
        Query: SELECT partition_name, high_value, num_rows
               FROM all_tab_partitions
               WHERE table_name = :t AND table_owner = :s
               ORDER BY partition_position
        
        Returns: List of partition definitions. Empty list if not partitioned.
        """

    def get_synonyms(self, table_name: str) -> List[Dict]:
        """
        Query: SELECT owner, synonym_name, table_owner, table_name
               FROM all_synonyms
               WHERE synonym_name = :t OR table_name = :t
        
        Purpose: Resolve table names that are actually synonyms pointing elsewhere.
        """

    def get_views_referencing(self, table_name: str, schema: str = None) -> List[Dict]:
        """
        Query: SELECT view_name, text_length
               FROM all_views
               WHERE owner = :s AND UPPER(text) LIKE '%' || :t || '%'
        
        Purpose: Find views built on top of this table.
        """

    def get_table_stats(self, table_name: str, schema: str = None) -> Dict:
        """
        Query: SELECT num_rows, blocks, avg_row_len, last_analyzed,
                      sample_size, monitoring
               FROM all_tables
               WHERE table_name = :t AND owner = :s
        
        Returns: Dict with table statistics. 
        last_analyzed tells you how fresh the stats are.
        """

    def get_all_tables(self, schema: str = None) -> List[str]:
        """
        Query: SELECT table_name FROM all_tables WHERE owner = :s ORDER BY table_name
        
        Purpose: Discover ALL tables in the schema, not just those found in code.
        Used in Phase 5 to verify completeness.
        """

    def get_all_views(self, schema: str = None) -> List[str]:
        """
        Query: SELECT view_name FROM all_views WHERE owner = :s ORDER BY view_name
        """

    def execute_query(self, sql: str, params: Dict = None) -> List[Dict]:
        """
        Generic query executor for ad-hoc queries.
        1. Get connection from pool
        2. Create cursor with arraysize=1000 for efficiency
        3. Set statement timeout
        4. Execute with bind params
        5. Fetch all results
        6. Convert to list of dicts using cursor.description for column names
        7. Return results
        
        On error: log the SQL and error, return empty list.
        """
```

---

## SECTION 3: GEMFIRE CONNECTION

```python
"""
Class: GemfireConnection
Purpose: Connect to GemFire/Geode via REST API for region metadata and data extraction.

CRITICAL IMPLEMENTATION DETAILS:
- All operations use the REST API at config.rest_api_url
- Base URL format: http://host:port/gemfire-api/v1
- Key endpoints:
    GET /                          → List all regions
    GET /{region}                  → Get all entries in a region (paginated)
    GET /{region}/{key}            → Get a single entry
    GET /{region}?limit=N&offset=M → Paginated access
    POST /queries?id=...&q=...     → Execute OQL query
- Every HTTP call must have retry logic: 3 retries with exponential backoff (1s, 2s, 4s)
- Every HTTP call must have timeout of 30 seconds
- If auth_username is provided, use HTTP Basic Auth
- Handle JSON response parsing — GemFire returns Java-serialized objects as JSON
"""

class GemfireConnection:
    def __init__(self, config: GemfireConfig):
        """
        1. Build base URL from config.rest_api_url
        2. Set up requests.Session with auth if provided
        3. Test connection: GET {base_url}/ — should return list of regions
        4. If connection fails, log error but don't crash (GemFire might be optional)
        """

    def list_regions(self) -> List[str]:
        """
        GET {base_url}/
        
        Response is JSON list of region names like: 
            {"regions": [{"name": "REGION1", "type": "REPLICATE"}, ...]}
        
        Returns: List of region names.
        """

    def get_region_metadata(self, region_name: str) -> Dict:
        """
        This requires parsing GemFire XML configs from the codebase,
        as REST API doesn't expose all metadata.
        
        Attempt to discover:
        - Region type (REPLICATE, PARTITION, LOCAL) — from config XML
        - Entry count — from GET /{region}?limit=0 or OQL: SELECT COUNT(*) FROM /{region}
        - Key class — from first entry inspection
        - Value class — from first entry inspection
        - Cache loader class — from config XML
        - Cache writer class — from config XML  
        - Expiry/eviction policy — from config XML
        - Disk store name — from config XML
        - Gateway sender — from config XML
        
        Returns: Dict with all discoverable metadata fields.
        """

    def get_entry(self, region_name: str, key: str) -> Any:
        """
        GET {base_url}/{region_name}/{key}
        
        Returns: Parsed JSON value, or None if not found.
        """

    def get_sample_entries(self, region_name: str, count: int = None) -> List[Dict]:
        """
        GET {base_url}/{region_name}?limit={count}
        
        count defaults to config.sample_entry_count.
        
        Returns: List of {key, value} dicts.
        Each value is the full JSON structure of the entry.
        """

    def get_all_keys(self, region_name: str) -> List[str]:
        """
        GET {base_url}/{region_name}/keys
        
        Returns: List of all keys in the region.
        Only call this for REPLICATE regions with < max_entries_for_full_dump entries.
        """

    def dump_all_entries(self, region_name: str) -> Dict:
        """
        For small REPLICATE regions (< max_entries_for_full_dump):
        1. Get all keys
        2. For each key, get the entry
        3. Return dict of {key: value}
        
        This captures ALL reference/lookup data for the knowledge base.
        
        For large regions, just get sample entries instead.
        """

    def execute_oql(self, query: str) -> List[Dict]:
        """
        POST {base_url}/queries?id=query1&q={oql_query}
        
        OQL is similar to SQL. Example: 
            SELECT DISTINCT e.productType FROM /PRODUCT_CONFIG e
        
        Returns: List of results.
        On error: log and return empty list.
        """

    def trace_cache_loader_to_table(self, loader_class_name: str, source_files: Dict) -> Optional[str]:
        """
        Given a cache loader class name (e.g., "com.bank.cache.ProductConfigLoader"):
        1. Find the source file in source_files dict
        2. Search for SQL strings, JdbcTemplate calls, DAO references
        3. Extract the Oracle table name that this loader reads from
        
        Returns: Table name string, or None if can't determine.
        
        This links GemFire Region → Cache Loader → Oracle Table.
        """
```

---

## SECTION 4: LLM CALLER

```python
"""
Class: LLMCaller
Purpose: Abstract away the LLM calling mechanism.
         Supports 3 modes: Claude Code CLI, Copilot file-based, direct API.

CRITICAL IMPLEMENTATION DETAILS:
- Every call has retry logic (config.max_retries, with exponential backoff)
- Every call respects rate limiting (sleep config.rate_limit_delay_seconds between calls)
- Every call logs the prompt length, response length, and duration
- If response is empty or appears truncated, retry once with "Continue from where you left off"
- Track total tokens used across the session for budget awareness
"""

class LLMCaller:
    def __init__(self, config: LLMConfig):
        """
        Set up based on config.mode:
        - "claude_code_cli": Verify claude binary exists at config.claude_code_path
        - "copilot_file": Verify workspace directory exists
        - "api": Verify endpoint and api_key are set
        """

    def call(self, prompt: str, system_prompt: str = None, temperature: float = 0.0) -> str:
        """
        Main entry point. Routes to the appropriate backend.
        
        1. Check prompt length doesn't exceed config.max_context_tokens
           (Use estimate: len(prompt) / 4 ≈ token count)
        2. If prompt too long, raise ValueError with message
        3. Call the appropriate backend
        4. Validate response is non-empty
        5. Log call details
        6. Sleep for rate_limit_delay_seconds
        7. Return response text
        """

    def _call_claude_code(self, prompt: str, system_prompt: str) -> str:
        """
        Use subprocess to call Claude Code CLI:
        
        Command: claude -p "{prompt}" --model {config.claude_model} --max-tokens {config.max_tokens_per_call}
        
        If system_prompt is provided, prepend it to the prompt.
        
        Implementation:
        1. Write prompt to a temp file (prompts can be huge)
        2. Run: subprocess.run(
               [config.claude_code_path, "-p", "@tempfile.txt", 
                "--model", config.claude_model,
                "--max-tokens", str(config.max_tokens_per_call)],
               capture_output=True, text=True, timeout=300
           )
        3. Check return code
        4. Return stdout
        5. Clean up temp file
        """

    def _call_copilot_file(self, prompt: str, system_prompt: str) -> str:
        """
        Copilot file-based mode:
        1. Write prompt to {copilot_workspace}/CURRENT_PROMPT.md
        2. Write a marker file {copilot_workspace}/READY
        3. Wait for response file {copilot_workspace}/RESPONSE.md to appear
           (Poll every 5 seconds, timeout after 600 seconds)
        4. Read and return response
        5. Delete READY marker and response file
        
        This mode requires a Copilot extension or manual intervention
        to process the prompt and write the response.
        """

    def _call_api(self, prompt: str, system_prompt: str) -> str:
        """
        Direct API call:
        
        POST {config.api_endpoint}
        Headers: 
            Content-Type: application/json
            Authorization: Bearer {config.api_key}
            anthropic-version: 2024-01-01
        Body: {
            "model": config.api_model,
            "max_tokens": config.max_tokens_per_call,
            "temperature": 0.0,
            "system": system_prompt or "",
            "messages": [{"role": "user", "content": prompt}]
        }
        
        Parse response:
            response.json()["content"][0]["text"]
        """

    def call_with_context_management(self, prompt_template: str, context_parts: Dict[str, str]) -> str:
        """
        Smart context management for when total context exceeds limit.
        
        1. Estimate token count for prompt_template + all context_parts
        2. If within limit, render template with all parts and call
        3. If over limit:
           a. Keep prompt_template (mandatory)
           b. Priority-order context_parts (source_code > data_context > module_context > call_graph)
           c. Add parts until approaching limit
           d. For remaining parts, summarize them first (call LLM to summarize each)
           e. Add summaries
        4. Return response
        
        This ensures we never exceed the context window while keeping
        the most important information.
        """
```

---

## SECTION 5: JAVA CODE HELPERS

```python
"""
Functions for parsing Java source code without a full Java runtime.
Uses regex-based extraction (works on any machine with Python).

IMPORTANT: These are NOT perfect parsers. They handle 95%+ of standard Java patterns.
Edge cases (very unusual formatting, code in comments, etc.) are caught by the
LLM-based validation in later phases.
"""

def find_all_java_files(project_root: str, source_dirs: List[str], exclude_patterns: List[str]) -> List[str]:
    """
    Walk the project directory tree and find all .java files.
    
    1. For each source_dir in source_dirs:
       - Resolve to absolute path: os.path.join(project_root, module_path, source_dir)
    2. Walk all directories recursively
    3. Filter out any file matching exclude_patterns (use fnmatch)
    4. Return list of absolute file paths, sorted
    
    IMPORTANT: Must handle Maven multi-module projects where each module
    has its own src/main/java directory.
    """

def extract_package(java_source: str) -> str:
    """
    Regex: r'package\s+([\w.]+)\s*;'
    Returns: Package name string, or "" if no package declaration.
    """

def extract_imports(java_source: str) -> List[str]:
    """
    Regex: r'import\s+(?:static\s+)?([\w.*]+)\s*;'
    Returns: List of import strings.
    """

def extract_class_info(java_source: str) -> Dict:
    """
    Extract class-level information.
    
    Returns dict with:
    - name: str — class name
    - type: str — "class" | "interface" | "enum" | "record" | "abstract_class"
    - extends: Optional[str] — parent class
    - implements: List[str] — implemented interfaces
    - annotations: List[str] — class-level annotations (e.g., @Service, @Entity)
    - is_abstract: bool
    - generic_params: Optional[str] — generic type parameters
    
    Regex patterns:
    - Class declaration: r'(?:public|protected|private)?\s*(?:abstract\s+)?(?:class|interface|enum|record)\s+(\w+)(?:<[^>]+>)?(?:\s+extends\s+([\w.<>,\s]+))?(?:\s+implements\s+([\w.<>,\s]+))?'
    - Annotations: r'@(\w+)(?:\([^)]*\))?'  (capture all annotations before class declaration)
    """

def extract_methods(java_source: str) -> List[Dict]:
    """
    Extract all method signatures and their positions in the source.
    
    Returns list of dicts, each with:
    - name: str — method name
    - return_type: str
    - parameters: List[Dict] — [{name: str, type: str}]
    - annotations: List[str] — method-level annotations
    - modifiers: List[str] — public/private/protected, static, final, synchronized
    - start_line: int — line number where method starts
    - end_line: int — line number where method ends (matched by brace counting)
    - body_source: str — the full method body source code
    - throws: List[str] — declared exceptions
    
    Algorithm for finding method boundaries:
    1. Find method signature with regex
    2. From the opening '{', count braces: increment for '{', decrement for '}'
    3. When brace count reaches 0, that's the end of the method
    4. IMPORTANT: Skip braces inside string literals and comments
    
    Regex for method signature:
    r'(?:(@\w+(?:\([^)]*\))?)\s+)*(?:(?:public|protected|private)\s+)?(?:static\s+)?(?:final\s+)?(?:synchronized\s+)?(?:<[\w\s,<>?]+>\s+)?(\w[\w.<>,\[\]\s?]*)\s+(\w+)\s*\(([^)]*)\)(?:\s+throws\s+([\w,\s]+))?\s*\{'
    """

def extract_fields(java_source: str) -> List[Dict]:
    """
    Extract all field declarations.
    
    Returns list of dicts, each with:
    - name: str
    - type: str
    - annotations: List[str]
    - modifiers: List[str]
    - initial_value: Optional[str] — for constants/static finals
    
    Regex: Look for field declarations between class opening brace and first method.
    Pattern: r'(?:@\w+(?:\([^)]*\))?\s+)*(?:(?:public|private|protected)\s+)?(?:static\s+)?(?:final\s+)?(\w[\w.<>,\[\]?]*)\s+(\w+)\s*(?:=\s*([^;]+))?\s*;'
    """

def extract_annotations_with_params(java_source: str) -> List[Dict]:
    """
    Extract ALL annotations with their full parameters.
    
    Returns list of dicts:
    - annotation: str — e.g., "Entity", "Query", "KafkaListener"
    - params: Dict — parsed annotation parameters
    - line: int — line number
    - target: str — what the annotation is on: "class" | "method:{name}" | "field:{name}"
    
    Examples of complex annotations to handle:
    @Entity
    @Table(name = "PRODUCT_CONFIG", schema = "PAYMENT")
    @Query("SELECT p FROM Product p WHERE p.type = :type")
    @KafkaListener(topics = "${kafka.topic.payments}", groupId = "${kafka.group.processor}")
    @Cacheable(cacheNames = "productCache", key = "#productId")
    @Scheduled(cron = "0 0 2 * * ?")
    @Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED)
    
    IMPORTANT: Must handle multi-line annotations, nested parentheses, 
    Spring property placeholders (${...}), and SpEL expressions (#{...}).
    """

def count_branches(java_source: str, method_name: str = None) -> int:
    """
    Count the number of branching points in a method (or entire class if method_name is None).
    
    Count each of these as 1 branch:
    - if (...) → 1 (the else is implied)
    - else if (...) → 1
    - else → 1
    - switch (...) → 1 per case label (including default)
    - catch (...) → 1 per catch block
    - ternary operator (? :) → 1
    - && and || in conditions → 1 each (short-circuit branching)
    - Optional.orElse / .orElseGet / .orElseThrow → 1 each
    
    If method_name is provided, extract that method's body first,
    then count branches within it.
    
    IMPORTANT: Don't count branches inside string literals or comments.
    """

def extract_string_literals(java_source: str) -> List[str]:
    """
    Extract all string literals from Java source.
    
    Purpose: Find hardcoded SQL, table names, cache keys, topic names, etc.
    
    Regex: r'"([^"\\]|\\.)*"'
    
    Returns: List of string values (without quotes).
    
    Filter out very short strings (< 3 chars) and common boilerplate.
    """

def extract_method_calls(java_source: str, method_name: str = None) -> List[Dict]:
    """
    Extract all method calls within a method body.
    
    Returns list of dicts:
    - target: str — object/class the method is called on (e.g., "accountDao", "gemfireRegion")
    - method: str — method name called (e.g., "findByAccountId", "get")
    - arguments: List[str] — argument expressions
    - line: int — line number
    
    Pattern: r'(\w+)\s*\.\s*(\w+)\s*\(([^)]*)\)'
    
    Also detect:
    - Static method calls: ClassName.method()
    - Chained calls: obj.method1().method2()
    - Constructor calls: new ClassName(...)
    """
```

---

## SECTION 6: MAVEN POM PARSER

```python
def parse_pom(pom_path: str) -> Dict:
    """
    Parse a Maven POM file and extract project structure.
    
    Uses xml.etree.ElementTree (standard library, no external deps).
    
    IMPORTANT: Maven POMs use XML namespaces. The default namespace is:
    '{http://maven.apache.org/POM/4.0.0}'
    All element lookups must use this namespace prefix or strip it.
    
    Returns dict with:
    - group_id: str
    - artifact_id: str
    - version: str
    - packaging: str (jar, war, pom)
    - parent: Dict or None — {group_id, artifact_id, version}
    - modules: List[str] — child module names (for parent POMs)
    - dependencies: List[Dict] — [{group_id, artifact_id, version, scope}]
    - internal_dependencies: List[str] — artifact_ids that belong to this project
    - plugins: List[Dict] — [{group_id, artifact_id, configuration}]
    - properties: Dict — all <properties> entries
    - profiles: List[Dict] — [{id, activation, properties, dependencies}]
    """

def build_module_dependency_graph(project_root: str) -> Dict:
    """
    Walk the entire Maven multi-module project and build the dependency DAG.
    
    Algorithm:
    1. Find root pom.xml
    2. Parse it to get modules list
    3. For each module, parse its pom.xml
    4. If a module is also a parent (packaging=pom), recursively parse its children
    5. Build adjacency list: {module_name: [list of internal modules it depends on]}
    6. Detect circular dependencies (log warning if found)
    7. Compute topological sort order (for processing order)
    
    Returns dict:
    - modules: Dict[str, Dict] — {module_name: parsed_pom_dict}
    - adjacency: Dict[str, List[str]] — {module_name: [dependency_module_names]}
    - topological_order: List[str] — modules in dependency order (leaves first)
    - root_pom: Dict — the root POM parsed
    """
```

---

## SECTION 7: ANNOTATION SCANNER

```python
"""
25+ annotation patterns to scan for, each mapped to a category.
"""

ANNOTATION_PATTERNS = {
    # ─── JPA / Database ───
    'Entity':           {'category': 'jpa', 'extracts': ['table_name from @Table']},
    'Table':            {'category': 'jpa', 'extracts': ['name', 'schema']},
    'Column':           {'category': 'jpa', 'extracts': ['name', 'nullable', 'length']},
    'Id':               {'category': 'jpa', 'extracts': []},
    'GeneratedValue':   {'category': 'jpa', 'extracts': ['strategy']},
    'ManyToOne':        {'category': 'jpa', 'extracts': ['fetch', 'cascade']},
    'OneToMany':        {'category': 'jpa', 'extracts': ['mappedBy', 'fetch', 'cascade']},
    'ManyToMany':       {'category': 'jpa', 'extracts': ['fetch', 'cascade']},
    'JoinColumn':       {'category': 'jpa', 'extracts': ['name', 'referencedColumnName']},
    'Query':            {'category': 'jpa', 'extracts': ['value (the JPQL/SQL string)']},
    'NamedQuery':       {'category': 'jpa', 'extracts': ['name', 'query']},
    'Repository':       {'category': 'spring_data', 'extracts': ['entity type from generic']},
    
    # ─── Spring Core ───
    'Service':          {'category': 'spring', 'extracts': ['value (bean name)']},
    'Component':        {'category': 'spring', 'extracts': ['value']},
    'Controller':       {'category': 'spring', 'extracts': []},
    'RestController':   {'category': 'spring', 'extracts': []},
    'Configuration':    {'category': 'spring', 'extracts': []},
    'Bean':             {'category': 'spring', 'extracts': ['name', 'initMethod', 'destroyMethod']},
    'Autowired':        {'category': 'spring', 'extracts': []},
    'Value':            {'category': 'spring', 'extracts': ['property placeholder string']},
    'ConditionalOnProperty': {'category': 'spring', 'extracts': ['name', 'havingValue']},
    'Profile':          {'category': 'spring', 'extracts': ['profile names']},
    
    # ─── REST Endpoints ───
    'RequestMapping':   {'category': 'rest', 'extracts': ['value/path', 'method']},
    'GetMapping':       {'category': 'rest', 'extracts': ['value/path']},
    'PostMapping':      {'category': 'rest', 'extracts': ['value/path']},
    'PutMapping':       {'category': 'rest', 'extracts': ['value/path']},
    'DeleteMapping':    {'category': 'rest', 'extracts': ['value/path']},
    'PathVariable':     {'category': 'rest', 'extracts': ['name']},
    'RequestBody':      {'category': 'rest', 'extracts': []},
    'RequestParam':     {'category': 'rest', 'extracts': ['name', 'required', 'defaultValue']},
    
    # ─── Kafka ───
    'KafkaListener':    {'category': 'kafka', 'extracts': ['topics', 'groupId', 'containerFactory']},
    'SendTo':           {'category': 'kafka', 'extracts': ['topic name']},
    'KafkaHandler':     {'category': 'kafka', 'extracts': []},
    
    # ─── MQ ───
    'JmsListener':      {'category': 'mq', 'extracts': ['destination', 'containerFactory']},
    
    # ─── GemFire / Cache ───
    'Region':           {'category': 'gemfire', 'extracts': ['region name from injection']},
    'Cacheable':        {'category': 'cache', 'extracts': ['cacheNames', 'key', 'condition']},
    'CachePut':         {'category': 'cache', 'extracts': ['cacheNames', 'key']},
    'CacheEvict':       {'category': 'cache', 'extracts': ['cacheNames', 'key', 'allEntries']},
    
    # ─── Scheduling ───
    'Scheduled':        {'category': 'scheduler', 'extracts': ['cron', 'fixedRate', 'fixedDelay']},
    'EnableScheduling': {'category': 'scheduler', 'extracts': []},
    
    # ─── Validation ───
    'Valid':            {'category': 'validation', 'extracts': []},
    'NotNull':          {'category': 'validation', 'extracts': ['message']},
    'NotBlank':         {'category': 'validation', 'extracts': ['message']},
    'Size':             {'category': 'validation', 'extracts': ['min', 'max']},
    'Pattern':          {'category': 'validation', 'extracts': ['regexp']},
    'Min':              {'category': 'validation', 'extracts': ['value']},
    'Max':              {'category': 'validation', 'extracts': ['value']},
    
    # ─── Transaction ───
    'Transactional':    {'category': 'transaction', 'extracts': ['propagation', 'isolation', 'readOnly', 'rollbackFor']},
    
    # ─── Async ───
    'Async':            {'category': 'async', 'extracts': ['value (executor name)']},
    'EnableAsync':      {'category': 'async', 'extracts': []},
}

def scan_all_annotations(java_files: List[str]) -> Dict:
    """
    Scan every Java file for every annotation pattern above.
    
    Returns dict with:
    - by_category: Dict[str, List] — all annotations grouped by category
    - by_file: Dict[str, List] — all annotations per file
    - tables_discovered: List[str] — table names from @Entity/@Table
    - regions_discovered: List[str] — region names from GemFire injections
    - topics_discovered: List[str] — Kafka topic names from @KafkaListener/@SendTo
    - queues_discovered: List[str] — MQ queue names from @JmsListener
    - endpoints_discovered: List[Dict] — REST endpoints with path + method
    - scheduled_tasks: List[Dict] — scheduled methods with cron expressions
    - cache_usages: List[Dict] — cache read/write/evict operations
    
    For each discovery, also record:
    - file_path: where it was found
    - class_name: which class
    - method_name: which method (if method-level annotation)
    - line_number: line in source file
    
    ALSO scan for non-annotation patterns:
    - JdbcTemplate usage: grep for 'jdbcTemplate.' or 'namedParameterJdbcTemplate.'
    - RestTemplate usage: grep for 'restTemplate.' or 'webClient.'
    - KafkaTemplate usage: grep for 'kafkaTemplate.send'
    - JmsTemplate usage: grep for 'jmsTemplate.'
    - GemfireTemplate: grep for 'gemfireTemplate.' or region variable access
    - DataSource: grep for 'DataSource' bean definitions
    """

def build_access_map(annotation_scan: Dict, config_scan: Dict) -> Dict:
    """
    Build the code→data access map by combining annotation scan with config scan.
    
    Returns dict:
    - table_access: Dict[str, List[Dict]] — {table_name: [{class, method, access_type, query}]}
    - region_access: Dict[str, List[Dict]] — {region_name: [{class, method, operation}]}
    - topic_access: Dict[str, List[Dict]] — {topic_name: [{class, method, role: producer|consumer}]}
    - queue_access: Dict[str, List[Dict]] — {queue_name: [{class, method, role}]}
    - endpoint_access: Dict[str, List[Dict]] — {path: [{class, method, http_method}]}
    
    For table_access, resolve:
    - @Entity classes → table name from @Table or class name
    - @Repository interfaces → entity class → table name
    - JdbcTemplate calls → SQL string → table name extraction
    - Spring Data method names → query derivation (findByXxx → SELECT WHERE xxx)
    """
```

---

## SECTION 8: TABLE CLASSIFICATION ENGINE

```python
def classify_table(table_name: str, oracle_profile: Dict, code_access: List[Dict], 
                   gemfire_regions: Dict) -> str:
    """
    Classify a table as: LOOKUP | CONFIG | TRANSACTIONAL | AUDIT
    
    Uses multi-signal scoring (NOT simple if/else).
    
    Signal weights (higher = stronger signal):
    
    LOOKUP signals (reference data, rarely changes):
        +3: Row count < 1000
        +2: Row count < 5000
        +3: Zero write operations in code (SELECT only)
        +2: Read count > 5x write count
        +2: Name contains: CONFIG, LOOKUP, REF, PARAM, RULE, STATIC, CODE, TYPE, STATUS, CATEGORY
        +3: Loaded into GemFire REPLICATE region
        +1: Has no temporal columns (CREATED_DATE, MODIFIED_DATE, etc.)
        +1: Table statistics show low churn (last_analyzed long ago but num_rows stable)
    
    CONFIG signals (application configuration, changes during deploys):
        +2: Row count < 100
        +3: Name contains: CONFIG, SETTING, PROPERTY, PARAMETER, FEATURE_FLAG
        +2: Has key-value structure (2-3 columns, one is a key)
        +1: Only written by admin/batch processes
    
    TRANSACTIONAL signals (business data, changes frequently):
        +3: Row count > 100,000
        +2: Row count > 10,000
        +3: Write count > read count
        +2: Has AUTO_INCREMENT or SEQUENCE-based PK
        +2: Has temporal columns
        +2: Name contains: TXN, TRANSACTION, LOG, EVENT, ORDER, PAYMENT, MESSAGE, INSTRUCTION
        +1: Partitioned table
        +1: Has triggers
    
    AUDIT signals (write-once logging):
        +3: Name contains: AUDIT, LOG, HISTORY, ARCHIVE, TRACE
        +2: Only INSERT operations (no UPDATE/DELETE in code)
        +2: Has timestamp PK or leading timestamp column
        +1: Partitioned by date
    
    Algorithm:
    1. Score each category
    2. Return category with highest score
    3. If tie, prefer LOOKUP > CONFIG > TRANSACTIONAL > AUDIT
    4. Store all scores in the classification result for transparency
    
    Returns: String classification AND the scoring breakdown.
    """
```

---

## SECTION 9: PROMPT TEMPLATE RENDERER

```python
def render_prompt(template_path: str, context: Dict) -> str:
    """
    Read a prompt template file and substitute context variables.
    
    Template format uses {variable_name} placeholders.
    
    1. Read template file
    2. For each key in context:
       - If value is a string, substitute directly
       - If value is a dict or list, convert to formatted string first
       - If value is None, substitute with "(not available)"
    3. Return rendered prompt
    
    IMPORTANT: If rendered prompt exceeds LLM context limit,
    log a warning with the size and the context keys that are largest.
    """

def format_dict_for_prompt(d: Dict, indent: int = 0) -> str:
    """Format a dict as readable text for inclusion in a prompt."""

def format_list_for_prompt(lst: List, indent: int = 0) -> str:
    """Format a list as readable text for inclusion in a prompt."""

def format_schema_for_prompt(schema: List[Dict]) -> str:
    """
    Format an Oracle table schema as a readable table:
    | Column | Type | Nullable | Default |
    |--------|------|----------|---------|
    | ...    | ...  | ...      | ...     |
    """

def format_distinct_values_for_prompt(values: List[Dict]) -> str:
    """
    Format distinct values as a readable list:
    - VALUE_A (occurs 1,234 times)
    - VALUE_B (occurs 567 times)
    - ...
    """
```

---

## SECTION 10: COMMON HELPERS

```python
def estimate_tokens(text: str) -> int:
    """Rough token estimate: len(text) / 4"""

def chunk_text(text: str, max_tokens: int) -> List[str]:
    """
    Split text into chunks that fit within max_tokens.
    Split at method boundaries if Java source, or at paragraph breaks otherwise.
    Never split in the middle of a code block.
    """

def safe_json_load(filepath: str) -> Any:
    """Load JSON with error handling. Return empty dict/list on failure."""

def safe_json_dump(data: Any, filepath: str):
    """Write JSON with pretty-printing. Create parent dirs if needed."""

def safe_read_file(filepath: str) -> str:
    """Read file with multiple encoding fallbacks: utf-8, latin-1, cp1252."""

def safe_write_file(filepath: str, content: str):
    """Write file with UTF-8 encoding. Create parent dirs if needed."""

def setup_logging(phase_name: str, log_dir: str) -> logging.Logger:
    """
    Set up logging for a phase:
    - File handler: {log_dir}/{phase_name}-{timestamp}.log
    - Console handler: INFO level
    - File handler: DEBUG level
    - Format: "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    """

def load_manifest(phase_dir: str) -> Dict:
    """Load a phase's manifest.json, return empty dict if doesn't exist."""

def save_manifest(phase_dir: str, manifest: Dict):
    """Save a phase's manifest.json."""

def get_phase_output_dir(config: Config, phase_num: int) -> str:
    """Return the output directory for a given phase number."""

def find_module_for_class(class_name: str, module_graph: Dict) -> str:
    """Given a class name, find which Maven module it belongs to."""

def sanitize_filename(name: str) -> str:
    """Convert a class/table/region name to a safe filename."""

def git_changed_files(project_root: str, since_days: int = 7) -> List[str]:
    """
    Run: git diff --name-only HEAD~{commits} -- '*.java' '*.xml' '*.yml' '*.properties'
    Or:  git log --since="{since_days} days ago" --name-only --format=''
    
    Returns list of changed file paths relative to project root.
    """

class ProgressTracker:
    """
    Track progress of long-running operations.
    
    Methods:
    - start(total: int, description: str)
    - update(current: int)
    - log_eta() — estimate time remaining based on current rate
    - complete()
    
    Prints progress to console every 10% or every 60 seconds.
    Also writes progress to a JSON file for monitoring.
    """

class ManifestBuilder:
    """
    Build a phase manifest incrementally.
    
    Methods:
    - add_processed(item_name: str, status: str, details: Dict = None)
    - add_gap(description: str, severity: str = "warning")
    - add_metric(name: str, value: Any)
    - set_coverage(covered: int, total: int)
    - is_complete() -> bool — coverage == 100% and no critical gaps
    - save(output_dir: str)
    
    The manifest JSON has structure:
    {
        "phase": "phase-N",
        "timestamp": "ISO datetime",
        "duration_seconds": int,
        "status": "COMPLETE" | "INCOMPLETE" | "FAILED",
        "coverage": {"covered": int, "total": int, "percentage": float},
        "metrics": {...},
        "processed_items": [...],
        "gaps": [...],
        "iteration": int  // which validation iteration this is
    }
    """
```

---

## SECTION 11: CONFIG FILE PARSER

```python
def parse_yaml_config(filepath: str) -> Dict:
    """Parse a YAML file (application.yml, bootstrap.yml). Handle Spring profiles."""

def parse_properties(filepath: str) -> Dict:
    """Parse a .properties file into key-value dict."""

def parse_spring_xml(filepath: str) -> Dict:
    """
    Parse Spring XML config files (applicationContext.xml, etc.)
    Extract: bean definitions, property placeholders, import statements.
    """

def parse_gemfire_xml(filepath: str) -> Dict:
    """
    Parse GemFire cache.xml or gemfire-*.xml.
    Extract:
    - Region definitions (name, type, key-constraint, value-constraint)
    - Cache loader classes for each region
    - Cache writer classes for each region
    - Expiry/eviction policies
    - Disk store configurations
    - Gateway sender configurations
    """

def parse_liquibase_changelog(filepath: str) -> Dict:
    """
    Parse Liquibase changelog files (XML or YAML).
    Extract: table creates, column adds, constraint changes, index creates.
    This gives the DDL history of the database.
    """

def resolve_spring_placeholders(value: str, all_configs: Dict) -> str:
    """
    Resolve ${property.name} and ${property.name:default} placeholders.
    Search through all parsed config files for the value.
    """

def scan_all_configs(project_root: str, source_dirs: List[str]) -> Dict:
    """
    Find and parse ALL configuration files in the project.
    
    File patterns to scan:
    - **/application*.yml, **/application*.yaml
    - **/bootstrap*.yml, **/bootstrap*.yaml
    - **/*.properties
    - **/spring-*.xml, **/applicationContext*.xml
    - **/cache.xml, **/gemfire-*.xml, **/geode-*.xml
    - **/persistence.xml
    - **/liquibase/**/*.xml, **/liquibase/**/*.yml
    - **/flyway/**/*.sql
    - **/logback*.xml, **/log4j*.xml
    
    Returns dict:
    - yaml_configs: List[Dict] — parsed YAML files
    - properties_configs: List[Dict] — parsed properties files
    - spring_xml_configs: List[Dict] — parsed Spring XML files
    - gemfire_xml_configs: List[Dict] — parsed GemFire configs
    - liquibase_changelogs: List[Dict] — parsed Liquibase files
    - all_properties: Dict — merged properties from all sources (with profile awareness)
    - tables_from_configs: List[str] — table names found in configs
    - regions_from_configs: List[str] — region names found in configs
    - topics_from_configs: List[str] — Kafka topics found in configs
    - queues_from_configs: List[str] — MQ queues found in configs
    """
```

---

## END OF FILE 01 SPECIFICATION

When generating utils.py:
1. Include ALL classes and functions specified above
2. Add comprehensive docstrings to every class and method
3. Add type hints to all function signatures
4. Include proper error handling (try/except) in every I/O operation
5. Use Python logging throughout (not print statements)
6. Make it importable: `from utils import Config, OracleConnection, GemfireConnection, LLMCaller, ...`
7. Total size should be approximately 1200-1500 lines
8. Test imports at the bottom: `if __name__ == "__main__": print("utils.py loaded successfully")`

# FILE 02 — PHASE 0: DISCOVERY & PROFILING
# No LLM needed. Pure Python scripts. Connects to Oracle + GemFire.
# This is the foundation — every other phase reads Phase 0 output.

---

## INSTRUCTION TO AGENT

Generate the following Python scripts for Phase 0. Place them all in `{PROJECT_ROOT}/.knowledge-base/phase-0/`.

All scripts import from `../utils.py`. All scripts take `--config ../config.yml` as CLI argument.

Phase 0 has 8 extraction steps + 1 validation script + 1 orchestrator.

---

## SCRIPT 1: run_phase_0.py (Main Orchestrator)

```
PURPOSE: Run all Phase 0 steps in order, then run the validation loop.
         If validation finds gaps, re-run targeted extraction, then re-validate.
         Repeat until 100% coverage or max_validation_iterations reached.

ALGORITHM:

1. Load config
2. Set up logging: phase-0-{timestamp}.log
3. Create output directory: phase-0/output/
4. Check resume: if manifest.json exists and has completed steps, skip those

5. Step 1: parse_maven.py → module_graph.json
   - Call: parse_maven.build_module_dependency_graph(config.project.root)
   - Save: phase-0/output/module_graph.json

6. Step 2: parse_java_ast.py → class_index.json + method_signatures.json
   - For EVERY .java file in the project:
     - Extract: package, class info, method signatures, field declarations
   - Save: phase-0/output/class_index.json (every class with file path, package, type, module)
   - Save: phase-0/output/method_signatures.json (every method with full signature)
   - Save: phase-0/output/call_graph.json (method → method calls)
   - Progress: log every 1000 files processed

7. Step 3: scan_annotations.py → annotation_scan.json + access_map.json
   - Scan every Java file for ALL annotation patterns from utils.ANNOTATION_PATTERNS
   - Also scan for non-annotation patterns (JdbcTemplate, RestTemplate, etc.)
   - Build the access_map linking code to data
   - Save: phase-0/output/annotation_scan.json
   - Save: phase-0/output/access_map.json

8. Step 4: scan_configs.py → config_scan.json
   - Parse every config file in the project
   - Resolve Spring property placeholders
   - Save: phase-0/output/config_scan.json

9. Step 5: profile_oracle.py → oracle_profiles.json
   - ONLY if config.oracle.enabled
   - For EVERY table discovered in steps 3 + 4:
     - Full Oracle metadata profile (schema, PKs, FKs, constraints, indexes, triggers, grants, partitions, row count, samples)
   - Follow FK chains recursively (if FK points to a table not yet profiled, add it to the queue)
   - Save: phase-0/output/oracle_profiles.json

10. Step 6: profile_gemfire.py → gemfire_profiles.json
    - ONLY if config.gemfire.enabled
    - For EVERY region discovered in steps 3 + 4:
      - Region metadata, sample entries, full dump for small REPLICATE regions
      - Trace cache loaders to Oracle source tables
    - Save: phase-0/output/gemfire_profiles.json

11. Step 7: classify_tables.py → table_classification.json
    - For EVERY table in oracle_profiles:
      - Run multi-signal classification (LOOKUP | CONFIG | TRANSACTIONAL | AUDIT)
    - For tables classified as LOOKUP or CONFIG:
      - Run distinct value analysis for ALL columns
      - Store ALL distinct values in the profile
    - Save: phase-0/output/table_classification.json
    - UPDATE oracle_profiles.json with distinct values

12. Step 8: Build combined discovery summary
    - Merge all discoveries into a summary manifest
    - Count: total Java files, total classes, total methods, total tables, total regions,
             total Kafka topics, total MQ queues, total REST endpoints

13. VALIDATION LOOP:
    iteration = 0
    while iteration < config.kb.max_validation_iterations:
        gaps = validate_phase_0.validate(config, output_dir)
        if len(gaps) == 0:
            manifest.status = "COMPLETE"
            break
        
        iteration += 1
        log(f"Validation iteration {iteration}: {len(gaps)} gaps found")
        
        for gap in gaps:
            if gap.type == "table_not_profiled":
                profile_oracle.profile_single_table(gap.table_name)
            elif gap.type == "region_not_profiled":
                profile_gemfire.profile_single_region(gap.region_name)
            elif gap.type == "fk_target_missing":
                profile_oracle.profile_single_table(gap.ref_table)
            elif gap.type == "file_not_parsed":
                parse_java_ast.parse_single_file(gap.file_path)
            elif gap.type == "synonym_unresolved":
                profile_oracle.resolve_synonym(gap.synonym_name)
            elif gap.type == "loader_table_unknown":
                profile_gemfire.trace_loader(gap.region_name, gap.loader_class)
    
    if iteration >= config.kb.max_validation_iterations and len(gaps) > 0:
        manifest.status = "INCOMPLETE"
        safe_json_dump(gaps, "phase-0/output/gaps.json")
        log(f"Phase 0 incomplete: {len(gaps)} unresolved gaps flagged for manual review")
    
    save_manifest("phase-0/output/", manifest)

CLI:
    python run_phase_0.py --config ../config.yml [--resume] [--step N] [--validate-only]
    
    --resume: Skip completed steps (check manifest)
    --step N: Run only step N (for debugging)
    --validate-only: Run only the validation loop
```

---

## SCRIPT 2: parse_maven.py

```
PURPOSE: Parse all pom.xml files and build the Maven module dependency graph.

FUNCTIONS:

def run(config: Config) -> Dict:
    """
    Main entry point.
    
    1. Find root pom.xml at config.project.root
    2. Parse root POM
    3. Recursively discover all modules:
       - If a POM has <modules>, each module has its own pom.xml
       - Modules can be nested (parent → child → grandchild)
    4. For each module POM, extract:
       - group_id, artifact_id, version
       - packaging (jar, war, pom)
       - dependencies (internal and external)
       - plugins
       - profiles
       - properties
    5. Build adjacency list: module → [modules it depends on]
    6. Compute topological sort order
    7. Identify shared/common modules (depended on by 3+ modules)
    
    Returns:
    {
        "modules": {
            "module-name": {
                "artifact_id": "...",
                "group_id": "...",
                "version": "...",
                "packaging": "jar",
                "path": "relative/path/to/module",
                "parent": "parent-module-name" or null,
                "internal_dependencies": ["dep1", "dep2"],
                "external_dependencies": [{...}],
                "source_dir": "src/main/java",
                "resource_dir": "src/main/resources",
                "java_file_count": 123,
                "is_shared": true/false  (depended on by 3+ modules)
            }
        },
        "adjacency": {"module-name": ["dep1", "dep2"]},
        "topological_order": ["leaf1", "leaf2", "mid1", "root"],
        "shared_modules": ["common-module1", "common-module2"]
    }
    """

def parse_single_pom(pom_path: str) -> Dict:
    """Parse one pom.xml. Handle Maven namespace. Resolve parent properties."""

def resolve_version(version_str: str, properties: Dict) -> str:
    """Resolve ${property} references in version strings."""

def find_all_poms(project_root: str) -> List[str]:
    """Find every pom.xml in the project, respecting .gitignore and exclude patterns."""
```

---

## SCRIPT 3: parse_java_ast.py

```
PURPOSE: Parse every Java file to extract class info, method signatures, fields, and call graph.

FUNCTIONS:

def run(config: Config, module_graph: Dict) -> Tuple[Dict, Dict, Dict]:
    """
    Main entry point.
    
    1. Find ALL Java files across all modules
    2. For each file (with progress tracking):
       a. Read file content
       b. Extract package
       c. Extract imports
       d. Extract class info (name, type, annotations, extends, implements)
       e. Extract all method signatures with positions
       f. Extract all fields
       g. Extract method call targets (for call graph)
    3. Build class_index: {fully_qualified_class_name: {file_path, package, module, class_info}}
    4. Build method_signatures: {fully_qualified_class_name: [method_dicts]}
    5. Build call_graph: {caller_fqn.method: [callee_fqn.method]}
    
    Error handling:
    - If a file can't be parsed (encoding issues, unusual syntax), log it and skip
    - Add skipped files to a "parse_failures" list in the output
    - NEVER crash on a single file failure
    
    Returns: (class_index_dict, method_signatures_dict, call_graph_dict)
    """

def parse_single_file(filepath: str) -> Dict:
    """
    Parse one Java file.
    
    Returns:
    {
        "file_path": "/absolute/path/to/File.java",
        "package": "com.bank.payment.service",
        "imports": ["java.util.List", "org.springframework.stereotype.Service", ...],
        "class": {
            "name": "PaymentRouter",
            "fqn": "com.bank.payment.service.PaymentRouter",
            "type": "class",  // class|interface|enum|record|abstract_class
            "annotations": [
                {"name": "Service", "params": {}},
                {"name": "Slf4j", "params": {}}
            ],
            "extends": "AbstractPaymentHandler",
            "implements": ["PaymentProcessor", "Auditable"],
            "is_abstract": false
        },
        "fields": [
            {
                "name": "accountDao",
                "type": "AccountDao",
                "annotations": [{"name": "Autowired", "params": {}}],
                "modifiers": ["private"],
                "initial_value": null
            }
        ],
        "methods": [
            {
                "name": "routeInstruction",
                "return_type": "PaymentResult",
                "parameters": [
                    {"name": "instruction", "type": "PaymentInstruction"},
                    {"name": "context", "type": "RoutingContext"}
                ],
                "annotations": [{"name": "Transactional", "params": {"readOnly": "false"}}],
                "modifiers": ["public"],
                "start_line": 45,
                "end_line": 120,
                "throws": ["PaymentException"],
                "calls": [
                    {"target": "accountDao", "method": "findByAccountId", "line": 48},
                    {"target": "gemfireRegion", "method": "get", "line": 52},
                    {"target": "rtgsProcessor", "method": "process", "line": 67}
                ],
                "branch_count": 8,
                "line_count": 75
            }
        ],
        "inner_classes": [...],  // same structure, nested
        "string_literals": ["SELECT * FROM ...", "ROUTING_CONFIG", ...],
        "parse_errors": []  // any issues during parsing
    }
    """

def build_call_graph(all_parsed_files: Dict) -> Dict:
    """
    Build a project-wide call graph from parsed files.
    
    For each method call found in each method:
    1. Resolve the target: field type → class → method
    2. If target is an interface, note all implementations
    3. Build edges: {caller_fqn.method_name: [{callee_fqn, method_name, line}]}
    
    Also build reverse edges: {callee_fqn.method_name: [{caller_fqn, method_name, line}]}
    
    Returns:
    {
        "forward": {caller → [callees]},
        "reverse": {callee → [callers]},
        "unresolved": [calls where target class couldn't be found]
    }
    """
```

---

## SCRIPT 4: scan_annotations.py

```
PURPOSE: Scan all Java files for the 25+ annotation patterns defined in utils.py.
         Build the code→data access map that links code to tables, regions, topics, queues.

FUNCTION:

def run(config: Config, class_index: Dict) -> Tuple[Dict, Dict]:
    """
    Main entry point.
    
    1. For each Java file in class_index:
       - Use utils.extract_annotations_with_params() to get ALL annotations
       - Match against ANNOTATION_PATTERNS
       - For each matched annotation, extract the relevant data:
         * @Entity/@Table → table_name
         * @Repository → entity class → table_name
         * @Query → SQL/JPQL string → table names, conditions
         * @KafkaListener → topic name(s)
         * @SendTo / KafkaTemplate → outbound topic name
         * @JmsListener → queue name
         * JmsTemplate → outbound queue name
         * @RequestMapping/@GetMapping/etc. → REST endpoint path + method
         * @Cacheable/@CachePut/@CacheEvict → cache name, key expression
         * @Scheduled → cron expression, fixed rate/delay
         * @Transactional → propagation, isolation, rollbackFor
         * GemFire Region injection → region name
    
    2. ALSO scan for non-annotation data access patterns:
       - JdbcTemplate/NamedParameterJdbcTemplate usage:
         * Find all .query(), .queryForList(), .queryForMap(), .update(), .execute() calls
         * Extract SQL strings from arguments
         * Parse table names from SQL
       - RestTemplate/WebClient usage:
         * Find all .getForObject(), .postForObject(), .exchange() calls
         * Extract URLs
       - KafkaTemplate usage:
         * Find all .send() calls
         * Extract topic names
    
    3. Build the access_map:
       table_access: For each table, list every class+method that reads or writes it
       region_access: For each GemFire region, list every class+method
       topic_access: For each Kafka topic, list producers and consumers
       queue_access: For each MQ queue, list senders and receivers
       endpoint_access: For each REST endpoint, list the handler
       cache_access: For each cache name, list all operations
    
    4. Resolve Spring property placeholders in topic names, queue names, etc.
       e.g., @KafkaListener(topics = "${kafka.topic.payments}") 
       → look up kafka.topic.payments in config_scan
    
    Returns: (annotation_scan_dict, access_map_dict)
    """

def extract_sql_table_names(sql: str) -> List[str]:
    """
    Parse SQL string to extract table names.
    
    Handles:
    - SELECT ... FROM table_name
    - SELECT ... FROM table_name alias
    - SELECT ... FROM schema.table_name
    - INSERT INTO table_name
    - UPDATE table_name
    - DELETE FROM table_name
    - JOIN table_name ON ...
    - subqueries
    
    Regex approach:
    - FROM\s+(\w+\.?\w+)
    - JOIN\s+(\w+\.?\w+)
    - INTO\s+(\w+\.?\w+)
    - UPDATE\s+(\w+\.?\w+)
    
    Returns: List of table names (uppercased).
    """

def resolve_spring_data_query(method_name: str) -> Dict:
    """
    Derive query from Spring Data repository method name.
    
    Examples:
    - findByAccountId → SELECT ... WHERE account_id = ?
    - findByStatusAndType → SELECT ... WHERE status = ? AND type = ?
    - countByProductType → SELECT COUNT(*) WHERE product_type = ?
    - existsByCode → SELECT COUNT(*) > 0 WHERE code = ?
    - deleteByExpiredTrue → DELETE WHERE expired = true
    
    Returns: {operation: SELECT|COUNT|DELETE, conditions: [{field, operator}]}
    """
```

---

## SCRIPT 5: scan_configs.py

```
PURPOSE: Find and parse ALL configuration files in the project.

FUNCTION:

def run(config: Config, module_graph: Dict) -> Dict:
    """
    1. Find all config files (YAML, properties, XML, Liquibase)
    2. Parse each one using the appropriate parser from utils.py
    3. Resolve Spring profile-specific configs
    4. Build merged property map (all sources combined)
    5. Extract data-relevant configs:
       - DataSource definitions (JDBC URLs → Oracle connection details)
       - GemFire region definitions from XML
       - Kafka topic configs
       - MQ queue configs
       - Cache configs
    
    Returns:
    {
        "files_scanned": ["path1", "path2", ...],
        "yaml_configs": {...},
        "properties_configs": {...},
        "spring_xml_configs": {...},
        "gemfire_xml_configs": {
            "regions": [
                {
                    "name": "ROUTING_CONFIG",
                    "type": "REPLICATE",
                    "key_constraint": "java.lang.String",
                    "value_constraint": "com.bank.model.RoutingConfig",
                    "cache_loader": "com.bank.cache.RoutingConfigLoader",
                    "cache_writer": null,
                    "expiry_ttl_seconds": 3600,
                    "eviction_max_entries": 0,
                    "disk_store": null
                }
            ]
        },
        "liquibase_changelogs": {...},
        "merged_properties": {"kafka.topic.payments": "payment-events", ...},
        "datasource_configs": [{url, driver, schema, ...}],
        "tables_from_configs": ["TABLE1", "TABLE2"],
        "regions_from_configs": ["REGION1", "REGION2"],
        "topics_from_configs": ["topic1", "topic2"],
        "queues_from_configs": ["queue1", "queue2"]
    }
    """
```

---

## SCRIPT 6: profile_oracle.py

```
PURPOSE: Connect to Oracle and profile EVERY discovered table.
         Follow FK chains recursively to discover related tables.

FUNCTIONS:

def run(config: Config, access_map: Dict, config_scan: Dict) -> Dict:
    """
    Main entry point.
    
    1. Collect ALL table names from:
       - access_map.table_access (tables found in code)
       - config_scan.tables_from_configs (tables found in config files)
       - config_scan.liquibase_changelogs (tables from DDL history)
    2. Deduplicate and uppercase all table names
    3. Initialize Oracle connection from config
    4. Profile queue: start with all discovered tables
    5. For each table in queue:
       a. Call profile_single_table()
       b. If table has FK targets not yet in queue, add them (recursive discovery)
    6. Close Oracle connection
    7. Return all profiles
    
    Returns:
    {
        "TABLE_NAME": {
            "table_name": "TABLE_NAME",
            "exists_in_db": true,
            "schema": [...column definitions...],
            "primary_key": ["COL1", "COL2"],
            "foreign_keys": [
                {"column": "ACCT_ID", "ref_table": "ACCOUNT", "ref_schema": "PAYMENT", "ref_column": "ID"}
            ],
            "unique_constraints": [...],
            "check_constraints": [...],
            "indexes": [...],
            "row_count": 12345,
            "sample_rows": [...],
            "triggers": [...],
            "grants": [...],
            "partitions": [...],
            "synonyms": [...],
            "views_referencing": [...],
            "table_stats": {...},
            "distinct_values": {},  // Populated later by classify_tables.py for LOOKUP/CONFIG tables
            "discovery_source": "code|config|fk_chain",  // How this table was discovered
            "profiled_at": "ISO timestamp"
        }
    }
    """

def profile_single_table(oracle_conn: OracleConnection, table_name: str, 
                          config: Config) -> Dict:
    """
    Profile one table completely.
    
    1. Get schema (columns, types, nullable, defaults)
       - If no results: try as synonym, try as view, try in additional schemas
       - If still no results: mark exists_in_db = false, return
    2. Get primary key
    3. Get foreign keys
    4. Get unique constraints
    5. Get check constraints
    6. Get indexes
    7. Get row count
    8. Get sample rows
    9. Get triggers
    10. Get grants
    11. Get partitions
    12. Get synonyms
    13. Get views referencing this table
    14. Get table stats
    
    CRITICAL ERROR HANDLING:
    - Each query is independent. If one fails (permission denied, timeout), 
      log the error and continue with the next query.
    - NEVER let a single query failure prevent profiling the rest of the table.
    - Store the error in a "profiling_errors" list in the result.
    """

def discover_fk_chain(oracle_conn: OracleConnection, starting_tables: Set[str], 
                       existing_profiles: Dict) -> Set[str]:
    """
    Follow FK chains to discover related tables.
    
    Algorithm:
    1. Start with starting_tables
    2. For each table, get its FK targets
    3. If any FK target is not in existing_profiles, add to new_tables set
    4. Recursively process new_tables
    5. Stop after 3 levels of recursion (prevent infinite loops)
    
    Returns: Set of newly discovered table names to profile.
    """

def resolve_table_name(oracle_conn: OracleConnection, name: str, config: Config) -> Tuple[str, str]:
    """
    Try to resolve a table name that wasn't found in the default schema.
    
    Strategy:
    1. Try UPPER(name) in default schema
    2. Try as synonym: query all_synonyms
    3. Try as view: query all_views
    4. Try in each additional_schemas
    5. Try without schema prefix if name contains '.'
    
    Returns: (resolved_table_name, resolved_schema) or (None, None)
    """
```

---

## SCRIPT 7: profile_gemfire.py

```
PURPOSE: Connect to GemFire and profile EVERY discovered region.
         Trace cache loaders back to Oracle source tables.

FUNCTIONS:

def run(config: Config, access_map: Dict, config_scan: Dict, 
        oracle_profiles: Dict, class_index: Dict) -> Dict:
    """
    Main entry point.
    
    1. Collect ALL region names from:
       - access_map.region_access (regions found in code)
       - config_scan.regions_from_configs (regions found in config)
       - config_scan.gemfire_xml_configs.regions (regions from GemFire XML)
    2. Deduplicate region names
    3. Initialize GemFire connection
    4. For each region:
       a. Get region metadata (type, size, config)
       b. Get sample entries
       c. For REPLICATE regions < max_entries: dump ALL entries
       d. Trace cache loader to Oracle source table
    5. Close GemFire connection
    6. Return all profiles
    
    Returns:
    {
        "REGION_NAME": {
            "region_name": "REGION_NAME",
            "exists_in_gemfire": true,
            "type": "REPLICATE",  // REPLICATE | PARTITION | LOCAL
            "entry_count": 234,
            "key_type": "java.lang.String",
            "value_type": "com.bank.model.RoutingConfig",
            "value_fields": [
                {"name": "currencyPair", "type": "String"},
                {"name": "routingType", "type": "String"},
                {"name": "processingMode", "type": "String"}
            ],
            "cache_loader": "com.bank.cache.RoutingConfigLoader",
            "source_table": "ROUTING_CONFIG",  // Oracle table this maps to
            "cache_writer": null,
            "expiry_policy": {"type": "TTL", "seconds": 3600},
            "eviction_policy": null,
            "disk_store": null,
            "gateway_sender": null,
            "sample_entries": [
                {"key": "USD/SGD", "value": {"currencyPair": "USD/SGD", "routingType": "RTGS", ...}}
            ],
            "full_dump": {  // Only for REPLICATE regions < max_entries
                "USD/SGD": {"currencyPair": "USD/SGD", "routingType": "RTGS", ...},
                "EUR/USD": {...}
            },
            "all_keys": ["USD/SGD", "EUR/USD", ...],
            "discovery_source": "code|config|xml",
            "profiled_at": "ISO timestamp"
        }
    }
    """

def trace_cache_loader_to_table(loader_class_name: str, class_index: Dict, 
                                 oracle_profiles: Dict) -> Optional[str]:
    """
    Given a cache loader class name, find which Oracle table it loads from.
    
    Strategy:
    1. Find the loader class source file in class_index
    2. Read the source code
    3. Search for:
       a. SQL strings (SELECT ... FROM table_name)
       b. DAO/Repository injection and method calls
       c. JdbcTemplate calls
       d. @Table annotation on entity classes referenced
    4. If found, verify the table exists in oracle_profiles
    5. If not found in source, check:
       a. Constructor parameters (table name might be injected)
       b. Config properties referenced (might be in application.yml)
       c. Parent class (if extends AbstractCacheLoader)
    
    Returns: Oracle table name, or None if undetermined.
    """
```

---

## SCRIPT 8: classify_tables.py

```
PURPOSE: Classify every profiled Oracle table as LOOKUP/CONFIG/TRANSACTIONAL/AUDIT.
         For LOOKUP and CONFIG tables: capture ALL distinct values.

FUNCTION:

def run(config: Config, oracle_profiles: Dict, access_map: Dict, 
        gemfire_profiles: Dict) -> Dict:
    """
    Main entry point.
    
    1. For each table in oracle_profiles:
       a. Run multi-signal classification (see utils.classify_table)
       b. Store classification and scoring breakdown
    
    2. For tables classified as LOOKUP or CONFIG:
       a. Connect to Oracle
       b. For EACH column in the table:
          - Run: SELECT DISTINCT {column}, COUNT(*) as freq 
                 FROM {table} GROUP BY {column} ORDER BY freq DESC
          - Store all distinct values with frequencies
       c. Store in oracle_profiles[table]['distinct_values']
       
       IMPORTANT: This is where we capture the ACTUAL DATA that drives code behavior.
       For a ROUTING_CONFIG table with 50 rows and 8 columns, we capture every single
       unique value in every column.
    
    3. Special handling for GemFire-backed tables:
       - If a table is the source for a GemFire REPLICATE region,
         classify it as LOOKUP even if row count is slightly high
       - Cross-reference: gemfire full dump should match Oracle data
         (flag discrepancies — cache might be stale)
    
    Returns:
    {
        "TABLE_NAME": {
            "classification": "LOOKUP",
            "scores": {"LOOKUP": 14, "CONFIG": 3, "TRANSACTIONAL": 2, "AUDIT": 0},
            "signals": ["row_count < 1000 (+3)", "zero writes (+3)", ...],
            "distinct_values_captured": true,
            "column_count": 8,
            "distinct_value_count": 156  // total across all columns
        }
    }
    
    ALSO: Modifies oracle_profiles in-place to add distinct_values.
    Save the updated oracle_profiles.json.
    """
```

---

## SCRIPT 9: validate_phase_0.py

```
PURPOSE: Validate Phase 0 completeness. Return list of gaps to fix.

THIS IS THE SELF-CLOSING VALIDATION LOOP.

FUNCTION:

def validate(config: Config, output_dir: str) -> List[Dict]:
    """
    Run 12 validation checks. Each check produces gap entries or passes.
    
    Returns: List of gap dicts. Empty list means Phase 0 is 100% complete.
    
    Each gap dict has:
    {
        "type": str,           # Gap type for resolution routing
        "severity": str,       # "critical" | "warning" | "info"
        "description": str,    # Human-readable description
        "item": str,           # The specific item with the gap
        "resolution": str      # Suggested fix
    }
    
    THE 12 CHECKS:
    
    CHECK 1: Every Java file was parsed
    - Load class_index.json
    - Find all .java files on disk
    - Any file on disk but not in class_index → gap
    - Type: "file_not_parsed"
    
    CHECK 2: Every table referenced in code has an Oracle profile
    - Load access_map.json → get all table names
    - Load oracle_profiles.json → get all profiled tables
    - Table in code but not profiled → gap
    - Type: "table_not_profiled"
    
    CHECK 3: Every table in Oracle profile was found in DB
    - For tables with exists_in_db = false → gap
    - Type: "table_not_found_in_db"
    - Resolution: "Check if synonym or view, or if table was dropped"
    
    CHECK 4: Every region referenced in code has a GemFire profile
    - Load access_map.json → get all region names
    - Load gemfire_profiles.json → get all profiled regions
    - Region in code but not profiled → gap
    - Type: "region_not_profiled"
    
    CHECK 5: Every GemFire region with a cache loader has a traced source table
    - For each region where cache_loader is not null but source_table is null → gap
    - Type: "loader_table_unknown"
    
    CHECK 6: Every FK target table is profiled
    - For each profiled table, check all foreign_keys
    - If ref_table is not in oracle_profiles → gap
    - Type: "fk_target_missing"
    
    CHECK 7: Every config-referenced table/region exists in code
    - Tables in config but not in code → warning (might be orphaned config)
    - Type: "config_orphan"
    - Severity: "warning"
    
    CHECK 8: Module graph completeness
    - Every pom.xml was parsed
    - Every module has at least one Java file
    - No broken internal dependencies (module depends on non-existent module)
    - Type: "module_graph_incomplete"
    
    CHECK 9: LOOKUP/CONFIG tables have distinct values captured
    - For tables classified as LOOKUP or CONFIG:
      - distinct_values must not be empty
    - Type: "distinct_values_missing"
    
    CHECK 10: GemFire ↔ Oracle data consistency
    - For regions with source_table:
      - Region entry_count should roughly match table row_count
      - If > 20% difference → warning (cache might be stale or filtered)
    - Type: "cache_data_mismatch"
    - Severity: "warning"
    
    CHECK 11: Annotation scan coverage
    - Every Java file should have been scanned for annotations
    - Check annotation_scan.json covers all files in class_index.json
    - Type: "annotation_scan_incomplete"
    
    CHECK 12: Config scan coverage
    - Every config file pattern was checked
    - At least one application.yml/properties was found
    - At least one pom.xml was found
    - Type: "config_scan_incomplete"
    
    AFTER ALL CHECKS:
    - Log summary: X checks passed, Y gaps found (Z critical, W warning, V info)
    - Return gaps list sorted by severity (critical first)
    """
```

---

## OUTPUT FILE FORMATS

### class_index.json
```json
{
  "com.bank.payment.service.PaymentRouter": {
    "file_path": "/project/payment-service/src/main/java/com/bank/payment/service/PaymentRouter.java",
    "package": "com.bank.payment.service",
    "module": "payment-service",
    "class_name": "PaymentRouter",
    "class_type": "class",
    "annotations": ["Service", "Slf4j"],
    "extends": "AbstractPaymentHandler",
    "implements": ["PaymentProcessor"],
    "method_count": 12,
    "field_count": 6,
    "line_count": 350,
    "is_abstract": false,
    "inner_classes": []
  }
}
```

### access_map.json
```json
{
  "table_access": {
    "ROUTING_CONFIG": [
      {
        "class": "com.bank.payment.dao.RoutingConfigDao",
        "method": "findByCurrencyPair",
        "access_type": "SELECT",
        "query": "SELECT r FROM RoutingConfig r WHERE r.currencyPair = :pair",
        "file_path": "/project/.../RoutingConfigDao.java",
        "line": 15
      }
    ]
  },
  "region_access": {
    "ROUTING_CONFIG": [
      {
        "class": "com.bank.payment.service.PaymentRouter",
        "method": "routeInstruction",
        "operation": "GET",
        "file_path": "/project/.../PaymentRouter.java",
        "line": 52
      }
    ]
  },
  "topic_access": {
    "payment-events": {
      "producers": [{"class": "...", "method": "..."}],
      "consumers": [{"class": "...", "method": "...", "group_id": "payment-processor"}]
    }
  },
  "queue_access": {...},
  "endpoint_access": {...}
}
```

### oracle_profiles.json (single table example)
```json
{
  "ROUTING_CONFIG": {
    "table_name": "ROUTING_CONFIG",
    "exists_in_db": true,
    "schema": [
      {"column_name": "CURRENCY_PAIR", "data_type": "VARCHAR2", "data_length": 10, "nullable": "N", "column_id": 1},
      {"column_name": "ROUTING_TYPE", "data_type": "VARCHAR2", "data_length": 20, "nullable": "N", "column_id": 2},
      {"column_name": "PROCESSING_MODE", "data_type": "VARCHAR2", "data_length": 30, "nullable": "Y", "column_id": 3},
      {"column_name": "CUT_OFF_TIME", "data_type": "TIMESTAMP", "data_length": 11, "nullable": "Y", "column_id": 4}
    ],
    "primary_key": ["CURRENCY_PAIR"],
    "foreign_keys": [],
    "unique_constraints": [],
    "check_constraints": [
      {"constraint_name": "CHK_ROUTING_TYPE", "search_condition": "ROUTING_TYPE IN ('RTGS','NETTING','BATCH')"}
    ],
    "indexes": [
      {"index_name": "PK_ROUTING_CONFIG", "uniqueness": "UNIQUE", "columns": ["CURRENCY_PAIR"]}
    ],
    "row_count": 47,
    "sample_rows": [
      {"CURRENCY_PAIR": "USD/SGD", "ROUTING_TYPE": "RTGS", "PROCESSING_MODE": "STRAIGHT_THROUGH", "CUT_OFF_TIME": "2025-12-31 16:00:00"}
    ],
    "triggers": [],
    "grants": [{"grantee": "PAYMENT_APP", "privilege": "SELECT", "grantable": "NO"}],
    "partitions": [],
    "synonyms": [],
    "views_referencing": [],
    "table_stats": {"num_rows": 47, "last_analyzed": "2025-10-15 03:00:00"},
    "distinct_values": {
      "ROUTING_TYPE": [
        {"value": "RTGS", "frequency": 25},
        {"value": "NETTING", "frequency": 15},
        {"value": "BATCH", "frequency": 7}
      ],
      "PROCESSING_MODE": [
        {"value": "STRAIGHT_THROUGH", "frequency": 30},
        {"value": "MANUAL_REVIEW", "frequency": 12},
        {"value": "BATCH", "frequency": 5}
      ]
    },
    "classification": "LOOKUP",
    "discovery_source": "code",
    "profiled_at": "2025-11-01T02:15:00Z"
  }
}
```

---

## END OF FILE 02 SPECIFICATION

When generating Phase 0 scripts:
1. Every script must import from utils.py
2. Every script must accept --config CLI argument
3. Every I/O operation must have try/except
4. Progress must be logged for long operations
5. All output files in phase-0/output/ directory
6. Validation loop must run automatically from run_phase_0.py
7. Gap resolution must be targeted (only re-extract what's missing)

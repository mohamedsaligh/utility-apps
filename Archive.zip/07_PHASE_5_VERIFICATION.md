# FILE 07 — PHASE 5: VERIFICATION & GAP CLOSURE
# The Karpathy loop. Validates the ENTIRE knowledge base.
# Re-queries ALL live systems. Runs random deep LLM verification.
# Does NOT produce new content — only validates and fixes.

---

## INSTRUCTION TO AGENT

Generate Python scripts for Phase 5. Place in `{PROJECT_ROOT}/.knowledge-base/phase-5/`.

This phase is a meta-validation layer. It doesn't add new documentation — it verifies
everything produced by Phases 0-4 is accurate, complete, and consistent, then closes any
remaining gaps. It connects to Oracle + GemFire to verify data hasn't drifted.

---

## SCRIPT 1: run_phase_5.py (Main Orchestrator)

```
PURPOSE: Run 8 mega-checks across the entire knowledge base.
         For each failure, trigger targeted re-extraction from the relevant phase.
         Loop until all checks pass or max iterations reached.

ALGORITHM:

1. Load config
2. Load ALL phase outputs (0 through 4)
3. Connect to Oracle + GemFire
4. Initialize LLM caller

5. MEGA-CHECKS (run all, collect all gaps):

   MEGA-CHECK 1: TOTAL FILE COVERAGE
   ─────────────────────────────────
   all_java_files = find_all_java_files(config)
   documented_files = find_all_logic_docs(phase_2_output)
   
   # Map logic docs back to source files
   documented_sources = set()
   for doc_path in documented_files:
       class_name = extract_class_from_path(doc_path)
       if class_name in class_index:
           documented_sources.add(class_index[class_name]['file_path'])
   
   undocumented = all_java_files - documented_sources
   
   # Filter out trivial files:
   # - Files with < 3 methods AND no data access AND no annotations
   # - Auto-generated files
   # - Pure test files
   non_trivial_undocumented = [f for f in undocumented if is_non_trivial(f)]
   
   if non_trivial_undocumented:
       for f in non_trivial_undocumented:
           gaps.append({
               'type': 'file_not_documented',
               'severity': 'critical',
               'item': f,
               'fix_phase': 2,
               'description': f'Java file {f} has non-trivial logic but no Phase 2 doc'
           })
   
   coverage_pct = (len(documented_sources) / len(all_java_files)) * 100
   metrics['file_coverage_pct'] = coverage_pct


   MEGA-CHECK 2: TOTAL METHOD COVERAGE
   ─────────────────────────────────────
   total_methods = 0
   documented_methods = 0
   
   for class_name, class_info in class_index.items():
       source = read_file(class_info['file_path'])
       source_methods = extract_methods(source)
       total_methods += len(source_methods)
       
       logic_doc = read_logic_doc(class_name)
       if logic_doc:
           doc_methods = parse_documented_methods(logic_doc)
           documented_methods += len(doc_methods)
           
           # Check each source method is documented
           for sm in source_methods:
               if sm['name'] not in [dm['name'] for dm in doc_methods]:
                   gaps.append({
                       'type': 'method_not_documented',
                       'severity': 'critical' if not is_simple_getter_setter(sm) else 'info',
                       'item': f'{class_name}.{sm["name"]}',
                       'fix_phase': 2
                   })
   
   metrics['method_coverage_pct'] = (documented_methods / total_methods) * 100


   MEGA-CHECK 3: DATA FRESHNESS — RE-QUERY ORACLE
   ────────────────────────────────────────────────
   # For every LOOKUP/CONFIG table:
   for table_name, profile in oracle_profiles.items():
       if profile['classification'] not in ('LOOKUP', 'CONFIG'):
           continue
       
       # Re-query distinct values from live Oracle
       for column_name, stored_values in profile.get('distinct_values', {}).items():
           stored_value_set = set(v['value'] for v in stored_values)
           
           live_values = oracle_conn.get_distinct_values(table_name, column_name)
           live_value_set = set(v['value'] for v in live_values)
           
           # New values not in KB
           new_values = live_value_set - stored_value_set
           if new_values:
               gaps.append({
                   'type': 'new_data_values',
                   'severity': 'critical',
                   'item': f'{table_name}.{column_name}',
                   'new_values': list(new_values),
                   'fix_phase': 3,
                   'description': f'Live DB has new values {new_values} in {table_name}.{column_name} not in KB'
               })
           
           # Removed values (stale KB)
           removed_values = stored_value_set - live_value_set
           if removed_values:
               gaps.append({
                   'type': 'stale_data_values',
                   'severity': 'warning',
                   'item': f'{table_name}.{column_name}',
                   'removed_values': list(removed_values),
                   'fix_phase': 3,
                   'description': f'KB has values {removed_values} no longer in live DB'
               })
   

   MEGA-CHECK 4: DATA FRESHNESS — RE-QUERY GEMFIRE
   ────────────────────────────────────────────────
   # Same as MEGA-CHECK 3 but for GemFire regions
   for region_name, profile in gemfire_profiles.items():
       if not profile.get('exists_in_gemfire'):
           continue
       
       live_keys = set(gemfire_conn.get_all_keys(region_name))
       stored_keys = set(profile.get('all_keys', []))
       
       new_keys = live_keys - stored_keys
       if new_keys and len(new_keys) > 0:
           gaps.append({
               'type': 'new_region_entries',
               'severity': 'critical' if profile['type'] == 'REPLICATE' else 'warning',
               'item': region_name,
               'new_keys_count': len(new_keys),
               'fix_phase': 3
           })


   MEGA-CHECK 5: RANDOM DEEP LLM VERIFICATION
   ────────────────────────────────────────────
   # Pick N random classes, have LLM compare source vs doc
   sample_size = config.validation.random_deep_verify_sample_size
   all_documented_classes = list(get_all_documented_classes())
   sample = random.sample(all_documented_classes, min(sample_size, len(all_documented_classes)))
   
   for class_name in sample:
       source = read_source(class_name)
       logic_doc = read_logic_doc(class_name)
       
       # Get data context for this class
       tables = get_tables_for_class(class_name)
       data_context = {}
       for t in tables:
           data_context[t] = {
               'schema': oracle_profiles.get(t, {}).get('schema', []),
               'distinct_values': oracle_profiles.get(t, {}).get('distinct_values', {})
           }
       
       prompt = render_prompt('phase-5/prompts/deep_verify.prompt.md', {
           'source': source,
           'doc': logic_doc,
           'data_context': data_context
       })
       
       result = llm.call(prompt)
       scores = parse_verification_scores(result)
       
       if scores['overall'] < config.validation.deep_verify_min_score:
           gaps.append({
               'type': 'deep_verify_failed',
               'severity': 'critical',
               'item': class_name,
               'score': scores['overall'],
               'issues': scores['issues'],
               'fix_phase': 2,
               'description': f'{class_name} scored {scores["overall"]}/100 on deep verification'
           })
   
   metrics['avg_deep_verify_score'] = sum(all_scores) / len(all_scores)


   MEGA-CHECK 6: EDGE GRAPH INTEGRITY
   ───────────────────────────────────
   all_edges = load_all_edge_files(phase_3_output)
   
   for edge in all_edges:
       # Verify source node exists
       if edge.get('data_source'):
           source_type, source_name = parse_node_ref(edge['data_source'])
           if source_type == 'oracle' and source_name not in oracle_profiles:
               gaps.append({'type': 'edge_source_missing', 'item': edge['data_source'], 'fix_phase': 0})
           elif source_type == 'gemfire' and source_name not in gemfire_profiles:
               gaps.append({'type': 'edge_source_missing', 'item': edge['data_source'], 'fix_phase': 0})
       
       # Verify target node exists  
       if edge.get('activates'):
           target_class = extract_class_from_fqn(edge['activates'])
           if not logic_doc_exists(target_class):
               gaps.append({'type': 'edge_target_missing', 'item': edge['activates'], 'fix_phase': 2})


   MEGA-CHECK 7: FLOW COMPLETENESS
   ────────────────────────────────
   all_entry_points = find_all_entry_points(access_map)
   all_flow_docs = find_all_flow_docs(phase_4_output)
   
   for ep in all_entry_points:
       if ep['name'] not in all_flow_docs:
           gaps.append({'type': 'flow_missing', 'item': ep['name'], 'fix_phase': 4})
       else:
           flow = read_flow_doc(ep['name'])
           if not has_terminal_point(flow):
               gaps.append({'type': 'flow_incomplete', 'item': ep['name'], 'fix_phase': 4})


   MEGA-CHECK 8: CROSS-PHASE CONSISTENCY
   ──────────────────────────────────────
   # Phase 0 discovered tables must all appear in Phase 3 edges
   for table in table_classification:
       if table_classification[table]['classification'] in ('LOOKUP', 'CONFIG'):
           if not has_data_link(table, phase_3_output):
               gaps.append({'type': 'cross_phase_gap', 'item': table, 'fix_phase': 3})
   
   # Phase 1 modules must all appear in Phase 4 flows
   # Phase 2 classes with data access must appear in Phase 3 edges
   # Phase 3 edges must be referenced in Phase 4 flows


6. GAP RESOLUTION LOOP:
   iteration = 0
   while gaps and iteration < max_iterations:
       iteration += 1
       
       # Group gaps by fix_phase
       gaps_by_phase = group_by_phase(gaps)
       
       for phase_num, phase_gaps in sorted(gaps_by_phase.items()):
           if phase_num == 0:
               # Re-run Phase 0 extraction for specific items
               for gap in phase_gaps:
                   if gap['type'] == 'new_data_values':
                       profile_oracle.profile_single_table(gap['item'].split('.')[0])
               # Re-run Phase 0 validation
               
           elif phase_num == 2:
               # Re-run Phase 2 extraction for specific classes
               for gap in phase_gaps:
                   if gap['type'] in ('file_not_documented', 'deep_verify_failed'):
                       rerun_phase2_for_class(gap['item'])
               
           elif phase_num == 3:
               # Re-run Phase 3 for specific tables/edges
               for gap in phase_gaps:
                   if gap['type'] in ('new_data_values', 'cross_phase_gap'):
                       rerun_phase3_for_table(gap['item'])
               
           elif phase_num == 4:
               # Re-run Phase 4 for specific flows
               for gap in phase_gaps:
                   if gap['type'] in ('flow_missing', 'flow_incomplete'):
                       rerun_phase4_for_flow(gap['item'])
       
       # Re-validate
       gaps = run_all_mega_checks(...)
   
   # Save results
   write_kb('phase-5/output/verification_report.md', format_report(metrics, gaps))
   safe_json_dump(gaps, 'phase-5/output/remaining_gaps.json')
   save_manifest(...)
```

---

## PROMPT TEMPLATE: deep_verify.prompt.md

```markdown
# Deep Verification Task

Compare the SOURCE CODE against the DOCUMENTATION for this class.
Score the documentation quality and identify every discrepancy.

## SOURCE CODE:
```java
{source_code}
```

## EXISTING DOCUMENTATION:
{logic_doc}

## DATA CONTEXT (actual values from live database):
{data_context}

---

## YOUR TASK:

Score each dimension 0-100:

### 1. METHOD COVERAGE (0-100)
- List every method in the source code
- For each, mark: DOCUMENTED | MISSING | INCOMPLETE
- Score = (documented + 0.5*incomplete) / total * 100

### 2. BRANCH COVERAGE (0-100)
- For each method, count branches in source (if/else/switch/catch/ternary)
- Count branches documented
- Score = documented_branches / total_branches * 100

### 3. DATA LINKAGE (0-100)
- For each data access in the source (DAO call, cache read, config lookup):
  * Is it mentioned in the doc?
  * Does the doc show which table/region?
  * Does the doc list the actual values from DATA CONTEXT?
  * Does the doc map values to code paths?
- Score = linked_accesses / total_accesses * 100

### 4. ACCURACY (0-100)
- Does the documentation correctly describe what the code actually does?
- Are there any WRONG descriptions?
- Are there any hallucinated methods or logic not in the source?
- Score: start at 100, deduct 10 for each inaccuracy

### 5. NULL/ERROR HANDLING (0-100)
- For each method that can receive null or encounter errors:
  * Does the doc mention null handling?
  * Does the doc mention error paths?
- Score = covered_paths / total_risk_paths * 100

## OUTPUT FORMAT:

```json
{
  "method_coverage": {"score": NN, "documented": N, "missing": N, "incomplete": N, "total": N},
  "branch_coverage": {"score": NN, "documented": N, "total": N},
  "data_linkage": {"score": NN, "linked": N, "total": N},
  "accuracy": {"score": NN, "inaccuracies": ["description1", "description2"]},
  "null_error_handling": {"score": NN, "covered": N, "total": N},
  "overall": NN,
  "issues": [
    {"type": "missing_method", "detail": "method_name not documented"},
    {"type": "wrong_description", "detail": "method_name described as X but actually does Y"},
    {"type": "missing_data_link", "detail": "DAO.findByX() not linked to table"},
    {"type": "missing_null_check", "detail": "method_name doesn't mention null path for param X"}
  ]
}
```
```

---

## SCRIPT 2: validate_phase_5.py

```
PURPOSE: Meta-validation — verify Phase 5 itself completed properly.

def validate(config, phase_5_output) -> List[Dict]:
    """
    CHECK 1: Verification report exists
    CHECK 2: All 8 mega-checks were run (check metrics dict has all keys)
    CHECK 3: File coverage >= config.validation.min_method_coverage_pct
    CHECK 4: Method coverage >= config.validation.min_method_coverage_pct
    CHECK 5: Average deep verify score >= config.validation.deep_verify_min_score
    CHECK 6: No critical gaps remaining
    CHECK 7: All data freshness checks were run (Oracle + GemFire queried)
    """
```

---

## END OF FILE 07 SPECIFICATION

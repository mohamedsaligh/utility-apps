# FILE 08 — PHASE 6: SYNTHESIS & AGENT PACKAGING
# Generates impact analysis guides, enhancement playbooks, and SKILL.md.
# Self-validates by testing the KB with 50+ real questions.
# Connects to Oracle + GemFire for answer verification.

---

## INSTRUCTION TO AGENT

Generate Python scripts for Phase 6. Place in `{PROJECT_ROOT}/.knowledge-base/phase-6/`.

This phase makes the knowledge base USABLE by AI agents and humans. It produces:
1. Impact analysis guides (how to answer "what breaks if I change X?")
2. Enhancement guides (how to answer "what do I need to modify to add feature Y?")
3. Common patterns catalog
4. Non-obvious gotchas document
5. The SKILL.md file that AI agents read as instructions

---

## SCRIPT 1: run_phase_6.py (Main Orchestrator)

```
PURPOSE: Synthesize all KB content into agent-ready documents.
         Validate by testing with real questions.

ALGORITHM:

1. Load config
2. Load ALL phase outputs (0 through 5)
3. Connect to Oracle + GemFire (for answer verification)

4. STEP 1: Generate IMPACT_ANALYSIS_GUIDE.md
   
   Build context from:
   - All edge files (data_drives_branch, code_reads_data, code_writes_data, implicit_relationships)
   - Table classification (which tables are lookup/config)
   - Module dependency graph
   - All flow docs from Phase 4
   
   prompt = render_prompt('phase-6/prompts/impact_analysis.prompt.md', {
       'edge_summary': summarize_edges(all_edges),
       'module_graph': module_graph,
       'data_catalog': summarize_data_catalog(oracle_profiles, gemfire_profiles, table_classification),
       'flow_summary': summarize_flows(phase_4_flows),
       'sample_questions': [
           "What happens if I add a new value to ROUTING_CONFIG.ROUTING_TYPE?",
           "Which services are affected if ACCOUNT_CONFIG schema changes?",
           "What is the impact of changing the cutoff time for USD?",
           "Which Kafka topics carry payment instruction data?",
           "What happens if GemFire region ROUTING_CONFIG is unavailable?"
       ]
   })
   
   result = llm.call(prompt)
   write_kb('phase-6/output/IMPACT_ANALYSIS_GUIDE.md', result)

5. STEP 2: Generate ENHANCEMENT_GUIDE.md
   
   prompt = render_prompt('phase-6/prompts/enhancement_guide.prompt.md', {
       'module_overviews': all_module_overviews,
       'common_patterns': extract_common_patterns(phase_2_docs),
       'entry_points': all_entry_points,
       'data_catalog': data_catalog,
       'sample_enhancements': [
           "Add a new payment type",
           "Add a new currency pair to the system",
           "Add a new outbound integration (REST API to external system)",
           "Add validation rules for a new regulatory requirement",
           "Add a new field to the payment instruction"
       ]
   })
   result = llm.call(prompt)
   write_kb('phase-6/output/ENHANCEMENT_GUIDE.md', result)

6. STEP 3: Generate COMMON_PATTERNS.md
   
   # Analyze all Phase 2 logic docs to find recurring patterns:
   # - DAO → process → publish pattern
   # - Cache-first, DB-fallback pattern
   # - Parallel fan-out → aggregate → continue pattern
   # - Event listener → process → respond pattern
   # - Validation → enrichment → routing pattern
   # - Retry with exponential backoff pattern
   # - Circuit breaker pattern
   
   prompt = render_prompt('phase-6/prompts/common_patterns.prompt.md', {
       'logic_doc_samples': sample_logic_docs(phase_2_docs, n=30),
       'flow_docs': all_flow_docs
   })
   result = llm.call(prompt)
   write_kb('phase-6/output/COMMON_PATTERNS.md', result)

7. STEP 4: Generate GOTCHAS.md
   
   # Extract non-obvious coupling, hidden dependencies, dangerous assumptions:
   # - Tables that look independent but are implicitly linked
   # - Methods that silently swallow exceptions
   # - Data that must be in sync across Oracle and GemFire
   # - Race conditions in parallel processing
   # - Order-dependent processing that isn't explicitly sequenced
   # - Default/fallback paths that silently handle unknown values
   # - Hard-coded values that should be configurable
   
   prompt = render_prompt('phase-6/prompts/gotchas.prompt.md', {
       'implicit_relationships': all_implicit_relationships,
       'null_risk_points': extract_null_risks(phase_2_docs),
       'default_branches': extract_default_branches(phase_3_edges),
       'parallel_patterns': extract_parallel_patterns(phase_4_flows),
       'stale_data_risks': extract_stale_data_risks(phase_5_report)
   })
   result = llm.call(prompt)
   write_kb('phase-6/output/GOTCHAS.md', result)

8. STEP 5: Generate SKILL.md
   
   # This is the master instruction file for AI agents
   # It tells an agent HOW to use the knowledge base
   
   prompt = render_prompt('phase-6/prompts/skill_generation.prompt.md', {
       'kb_structure': describe_kb_structure(),
       'edge_file_descriptions': describe_edge_files(),
       'data_catalog_summary': data_catalog,
       'module_list': all_modules,
       'sample_usage': generate_sample_usage_scenarios()
   })
   result = llm.call(prompt)
   write_kb('phase-6/output/SKILL.md', result)
   # Also copy to KB root:
   write_kb(f'{config.kb.output_dir}/SKILL.md', result)

9. VALIDATION: Test the KB with 50+ questions
   
   test_questions = generate_test_questions(all_phase_outputs)
   # Mix of:
   # - Impact questions: "What if X changes?"
   # - Lookup questions: "Where is Y used?"
   # - Flow questions: "Trace the path from A to B"
   # - Data questions: "What values does table Z column W have?"
   # - Integration questions: "What happens when topic Q receives a message?"
   
   passing = 0
   total = len(test_questions)
   
   for question in test_questions:
       # Step A: Answer using ONLY the KB
       kb_sections = find_relevant_kb_sections(question, all_phase_outputs)
       answer = llm.call(f"Using ONLY this knowledge base, answer: {question}\n\nKB Content:\n{kb_sections}")
       
       # Step B: Verify answer against source code + live data
       source_context = find_relevant_source(question, class_index)
       live_data = query_relevant_data(question, oracle_conn, gemfire_conn)
       
       verification = llm.call(render_prompt('phase-6/prompts/verify_answer.prompt.md', {
           'question': question,
           'kb_answer': answer,
           'source_code': source_context,
           'live_data': live_data,
           'instruction': 'Is the KB answer CORRECT and COMPLETE? Score 0-100. List any errors.'
       }))
       
       score = parse_score(verification)
       
       if score >= 80:
           passing += 1
       else:
           gaps.append({
               'type': 'qa_failure',
               'severity': 'critical' if score < 50 else 'warning',
               'question': question,
               'score': score,
               'issues': parse_issues(verification),
               'description': f'KB failed to answer correctly (score: {score}/100)'
           })
   
   metrics['qa_pass_rate'] = (passing / total) * 100

10. GAP RESOLUTION:
    If qa_pass_rate < 95:
        # For each failed question, trace back to the KB gap and fix it
        for gap in qa_gaps:
            identify_kb_section_to_fix(gap)
            rerun_relevant_phase(gap)
    
    # Re-run QA
    
11. Save manifest
```

---

## PROMPT TEMPLATE: impact_analysis.prompt.md

```markdown
# Impact Analysis Guide Generation

You are creating the definitive guide for performing impact analysis on a payment system.
This guide will be used by AI agents and human developers.

## Edge Graph Summary (data→code connections):
{edge_summary}

## Module Dependency Graph:
{module_graph}

## Data Catalog (tables/regions with classification):
{data_catalog}

## Business Flow Summary:
{flow_summary}

---

## YOUR TASK:

Generate a comprehensive IMPACT_ANALYSIS_GUIDE.md that covers:

### 1. HOW TO PERFORM IMPACT ANALYSIS

Step-by-step process:
1. Identify what is changing (table, column, value, method, config, etc.)
2. Look up the change item in the edge graph (which edge file to check)
3. Follow all edges from the change point outward
4. For each affected node, check its logic doc for side effects
5. Continue until you reach terminal points (no further outbound edges)
6. Compile the full impact report

### 2. IMPACT ANALYSIS BY CHANGE TYPE

For each type of change, provide a specific playbook:

#### A. Adding a new value to a LOOKUP table
- Check data_drives_branch.json for __UNKNOWN__ entries
- These show what currently happens for unrecognized values
- List every method that reads from this table (from code_reads_data.json)
- For each method, explain what needs to change

#### B. Changing a table schema (adding/removing/modifying a column)
- Check code_reads_data.json for all code that reads this table
- Check the logic docs for those classes to find column references
- Trace downstream effects through the flow docs

#### C. Adding a new Kafka topic
- Template from existing topic contracts
- List the common consumer/producer patterns

#### D. Modifying a GemFire region
- Check oracle→gemfire mapping (source_table in gemfire_profiles)
- Check all code that reads from this region
- Check cache loader/writer impact

#### E. Changing business logic in a method
- Use call_graph to find all callers
- Check if the method output feeds into data-driven branches
- Trace through flows that include this method

### 3. SAMPLE IMPACT ANALYSES

For each sample question, provide a worked example showing exactly how to use the KB:

{for each sample question:}
#### Question: {question}
**Step 1**: Look up {what to look up} in {which file}
**Step 2**: Found edges: {list edges}
**Step 3**: Trace to: {affected classes}
**Step 4**: Terminal impact: {what ultimately changes}
**Conclusion**: {summary of total impact}
{end for}

### 4. QUICK REFERENCE: Data Source Impact Matrix

| Data Source | Classification | Accessed By (modules) | Change Impact Level |
|-------------|---------------|----------------------|-------------------|
{for each LOOKUP/CONFIG table:}
| {table_name} | {classification} | {accessing_modules} | {HIGH/MEDIUM/LOW based on edge count} |
{end for}
```

---

## PROMPT TEMPLATE: skill_generation.prompt.md

```markdown
# SKILL.md Generation

Generate a SKILL.md file that instructs AI agents how to use this knowledge base.

## KB Structure:
{kb_structure}

## Available Edge Files:
{edge_file_descriptions}

## Data Catalog:
{data_catalog_summary}

## Modules:
{module_list}

---

## YOUR TASK:

Generate a SKILL.md following this exact structure:

```markdown
# Payment System Knowledge Base — SKILL.md

## When working on this codebase, ALWAYS follow these steps:

### 1. ORIENT YOURSELF
- Read MANIFEST.md for the full index and last-updated timestamps
- Read IMPACT_ANALYSIS_GUIDE.md for how to trace changes
- Read GOTCHAS.md before making ANY changes

### 2. FOR UNDERSTANDING A MODULE
Read: phase-1/output/modules/{module_name}/OVERVIEW.md
Then: phase-1/output/modules/{module_name}/CLASS_MAP.md
Then: phase-1/output/modules/{module_name}/DEPENDENCIES.md

### 3. FOR UNDERSTANDING A CLASS
Read: phase-2/output/modules/{module_name}/classes/{ClassName}.logic.md
This contains: every method, every branch, every data access with live data values mapped.

### 4. FOR IMPACT ANALYSIS ("what breaks if I change X?")
...detailed instructions with exact file paths...

### 5. FOR ENHANCEMENT ("add feature Y")
...detailed instructions...

### 6. FOR DATA QUESTIONS ("what values does table X have?")
...direct path to oracle_profiles.json...

### 7. FOR INTEGRATION QUESTIONS ("how does service A talk to service B?")
...path to flow docs and contracts...

## KEY FILES QUICK REFERENCE:
| Question | File to Read |
|----------|-------------|
| What modules exist? | phase-0/output/module_graph.json |
| What does class X do? | phase-2/output/modules/{module}/classes/X.logic.md |
| What tables exist? | phase-0/output/oracle_profiles.json |
| What values drive behavior? | phase-3/output/edges/data_drives_branch.json |
| How does flow Y work? | phase-4/output/flows/{flow}.flow.md |
| What breaks if I change Z? | IMPACT_ANALYSIS_GUIDE.md |
```
```

---

## SCRIPT 2: validate_phase_6.py

```
def validate(config, phase_6_output) -> List[Dict]:
    """
    CHECK 1: All 5 documents generated
    - IMPACT_ANALYSIS_GUIDE.md exists and has > 500 words
    - ENHANCEMENT_GUIDE.md exists
    - COMMON_PATTERNS.md exists
    - GOTCHAS.md exists
    - SKILL.md exists
    
    CHECK 2: SKILL.md references correct file paths
    - Every file path mentioned in SKILL.md must exist on disk
    
    CHECK 3: QA pass rate >= 95%
    - From metrics in manifest
    
    CHECK 4: Impact analysis guide covers all LOOKUP/CONFIG tables
    - Parse the guide, verify every LOOKUP/CONFIG table is mentioned
    
    CHECK 5: Enhancement guide covers common enhancement types
    - At least 5 enhancement scenarios documented
    """
```

---

## END OF FILE 08 SPECIFICATION

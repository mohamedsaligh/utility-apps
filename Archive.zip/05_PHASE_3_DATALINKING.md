# FILE 05 — PHASE 3: DATA-CODE LINKING
# Builds the edge graph that links every data value to the code path it activates.
# Discovers implicit FKs, chained lookups, and decision columns.
# Connects to Oracle + GemFire for live data queries.

---

## INSTRUCTION TO AGENT

Generate Python scripts for Phase 3. Place in `{PROJECT_ROOT}/.knowledge-base/phase-3/`.

This phase is THE DIFFERENTIATOR. It transforms the knowledge base from "dead documentation"
into a living, queryable graph where you can ask "what happens if value X changes in table Y?"
and get an immediate answer tracing through every affected code path.

---

## SCRIPT 1: run_phase_3.py (Main Orchestrator)

```
PURPOSE: For each LOOKUP/CONFIG data source, build complete value→code path mappings.
         Discover implicit relationships (FKs that exist only in code, not in DB).
         Build edge JSON files that connect data nodes to code nodes.

ALGORITHM:

1. Load config
2. Load Phase 0: oracle_profiles, gemfire_profiles, table_classification, access_map, class_index
3. Load Phase 2: all logic docs (these describe how code uses data)
4. Connect to Oracle + GemFire
5. Create output dirs: phase-3/output/data_links/, phase-3/output/edges/

6. Initialize edge collections:
   data_drives_branch = []       # Data value → which code path activates
   code_reads_data = []          # Method → which data it reads
   code_writes_data = []         # Method → which data it writes
   implicit_relationships = []   # Implicit FKs between tables (no DB FK exists)
   chained_lookups = []          # A.result → used as key for B lookup

7. STEP 1: Identify all decision columns
   For each LOOKUP/CONFIG table:
     For each column in the table:
       score = score_decision_column(table, column, access_map, oracle_profiles, phase_2_docs)
       if score > threshold:
           add to decision_columns list
   
   Decision column scoring:
   - +3: Column appears in WHERE clause of code queries
   - +3: Column value is used in if/else/switch in code (found in Phase 2 docs)
   - +2: Column has < 50 distinct values (likely a category/type/status)
   - +2: Column name contains: TYPE, STATUS, MODE, CODE, CATEGORY, FLAG, INDICATOR
   - +1: Column is NOT the primary key (PKs are lookups, not decisions)
   - +1: Column has CHECK constraint limiting values
   - -2: Column is a date/timestamp (unlikely to be a decision column)
   - -2: Column has > 1000 distinct values (too many to be a category)

8. STEP 2: For each decision column, build value→code path mapping
   For each (table, decision_column):
     # Get ALL current distinct values from live DB
     live_values = oracle_conn.get_distinct_values(table, decision_column)
     
     # Find ALL code that reads this column
     accessing_methods = find_methods_accessing_column(table, decision_column, 
                                                        access_map, phase_2_docs)
     
     # Send to LLM: given the code + the values, map each value to a code path
     prompt = render_prompt('phase-3/prompts/data_code_linkage.prompt.md', {
         'table': table,
         'column': decision_column,
         'distinct_values': live_values,
         'accessing_code': [{
             'class': m['class'],
             'method': m['method'],
             'source_snippet': extract_method_source(m),
             'logic_doc_excerpt': extract_relevant_logic(m, table, decision_column)
         } for m in accessing_methods]
     })
     
     result = llm.call(prompt)
     
     # Parse result into edges
     parsed_edges = parse_value_code_mapping(result)
     data_drives_branch.extend(parsed_edges)
     
     # Write per-table linkage doc
     write_kb(f'phase-3/output/data_links/oracle.{table}.{decision_column}.link.md', result)

9. STEP 3: Same for GemFire regions
   For each REPLICATE/CONFIG region:
     # Get all entries (or sample for large regions)
     entries = gemfire_conn.dump_all_entries(region) or gemfire_conn.get_sample_entries(region)
     
     # For each field in the value object that looks like a decision field:
     for field in identify_decision_fields(entries, access_map):
         # Map values to code paths (same LLM approach as step 2)
         ...

10. STEP 4: Discover implicit relationships (no DB foreign key exists)
    For each pair of tables that are accessed by the same class:
      prompt = render_prompt('phase-3/prompts/implicit_relationship.prompt.md', {
          'table_a': table_a_profile,
          'table_b': table_b_profile,
          'code_that_uses_both': relevant_logic_docs,
          'instruction': 'Identify if the result of looking up table A is used as a key to look up table B. This would be an implicit foreign key relationship.'
      })
      result = llm.call(prompt)
      implicit_rels = parse_implicit_relationships(result)
      implicit_relationships.extend(implicit_rels)

11. STEP 5: Discover chained lookups
    For each logic doc:
      # Search for patterns where the result of one lookup feeds another:
      # e.g., account = accountDao.find(id); fees = feeDao.find(account.feeGroup)
      # This creates a chain: ACCOUNT.fee_group → FEE_SCHEDULE.fee_group
      
      chains = extract_chained_lookups_from_logic_doc(logic_doc)
      chained_lookups.extend(chains)

12. STEP 6: Build complete code↔data edges
    For each class in Phase 2:
      For each data access mentioned in the logic doc:
        code_reads_data.append({
            'source': f'{class_name}.{method_name}',
            'target': f'oracle.{table_name}' or f'gemfire.{region_name}',
            'access_type': 'SELECT|INSERT|UPDATE|DELETE|GET|PUT',
            'columns_read': [...],
            'line': line_number
        })
        # Same for writes

13. STEP 7: Save all edge files
    safe_json_dump(data_drives_branch, 'phase-3/output/edges/data_drives_branch.json')
    safe_json_dump(code_reads_data, 'phase-3/output/edges/code_reads_data.json')
    safe_json_dump(code_writes_data, 'phase-3/output/edges/code_writes_data.json')
    safe_json_dump(implicit_relationships, 'phase-3/output/edges/implicit_relationships.json')
    safe_json_dump(chained_lookups, 'phase-3/output/edges/chained_lookups.json')

14. VALIDATION LOOP (connects to Oracle + GemFire):
    gaps = validate_phase_3(...)
    while gaps and iteration < max:
        fix_gaps(gaps, oracle_conn, gemfire_conn, llm)
        gaps = validate_phase_3(...)
    
    save_manifest(...)
```

---

## PROMPT TEMPLATE: data_code_linkage.prompt.md

```markdown
# Data-Code Linkage Task

You are mapping how data values in a database table drive code behavior.
For EVERY distinct value, identify which code path activates.

## Table: {table_name}
## Column: {column_name}

### All Distinct Values (from live database):
{for each value:}
- "{value}" (occurs {frequency} times)
{end for}

### Code That Reads This Column:

{for each accessing method:}
#### {class_name}.{method_name}()

Source code snippet:
```java
{source_snippet}
```

Existing logic documentation excerpt:
{logic_doc_excerpt}

{end for}

---

## YOUR TASK:

For EACH distinct value listed above, document:

### Value: "{value}"
- **Code path activated**: {class}.{method} → line {N} → {what branch/case is taken}
- **Downstream effect**: {what happens next — which service is called, what message is published, what gets written}
- **End result**: {final outcome of this code path}

### Value: (NEW / UNKNOWN — any value not in the current list)
- **Code path**: {what happens for unrecognized values — default case, exception, fallback}
- **Risk**: {is there proper handling for new values or will it fail?}

### Value: null
- **Code path**: {what happens if this column is null in the database}
- **Risk**: {is null properly handled?}

---

FORMAT each mapping as a structured entry:
```json
{
  "data_source": "oracle.{TABLE_NAME}",
  "field": "{COLUMN_NAME}",
  "value": "{VALUE}",
  "activates": "{fully.qualified.ClassName}.{methodName}()",
  "branch_location": "{fully.qualified.ClassName}.{methodName}():{lineNumber}",
  "downstream_effect": "{description of what happens}",
  "terminal_action": "{final DB write, Kafka publish, REST response, etc.}"
}
```

Produce one JSON entry per value. Include entries for NULL and UNKNOWN/NEW.
```

---

## PROMPT TEMPLATE: implicit_relationship.prompt.md

```markdown
# Implicit Relationship Discovery Task

Two database tables are accessed by the same code but have no foreign key in the database.
Determine if there is an implicit relationship — where the result of querying table A
is used as a key to query table B.

## Table A: {table_a_name}
Schema: {table_a_schema}
Sample data: {table_a_sample}

## Table B: {table_b_name}
Schema: {table_b_schema}
Sample data: {table_b_sample}

## Code that uses both tables:
{relevant_logic_docs}

---

## YOUR TASK:

1. Is there a CHAINED LOOKUP? (Result from table A used as key for table B)
   If yes: identify the join columns
   Format: "IMPLICIT FK: {table_a}.{column} → {table_b}.{column}"

2. Is there a SHARED KEY? (Both tables queried with the same key from a third source)
   If yes: identify the common key
   Format: "SHARED KEY: both use {key_name} from {source}"

3. Is there a VALUE DEPENDENCY? (Value from table A determines WHETHER to query table B)
   If yes: document the condition
   Format: "CONDITIONAL: query {table_b} only when {table_a}.{column} = '{value}'"

4. If NO relationship exists, state: "NO IMPLICIT RELATIONSHIP"
```

---

## SCRIPT 2: validate_phase_3.py

```
PURPOSE: Validate Phase 3 edge graph completeness and accuracy.
         Connects to Oracle + GemFire to verify data freshness.

FUNCTION:

def validate(config, phase_0_output, phase_2_output, phase_3_output,
             oracle_conn, gemfire_conn) -> List[Dict]:
    """
    THE 9 CHECKS:
    
    CHECK 1: Every LOOKUP/CONFIG table has a linkage doc
    - Load table_classification.json → get all LOOKUP + CONFIG tables
    - Check phase-3/output/data_links/oracle.{table}.*.link.md exists
    - Missing → gap type: "table_no_linkage_doc"
    
    CHECK 2: Every distinct value in every decision column has a mapped code path
    - For each LOOKUP table:
      For each decision column:
        Load linkage doc and parse value mappings
        Re-query Oracle for current distinct values
        For each live value:
          If not in mappings → gap type: "unmapped_value"
          Description: "Table {T}.{C} has value '{V}' with no code path mapping"
    
    CHECK 3: Every GemFire REPLICATE region has value→code mappings
    - Same as CHECK 2 but for GemFire regions
    - gap type: "region_unmapped_value"
    
    CHECK 4: Edge graph traversability
    - Load all edge JSON files
    - For each edge: verify source node has a doc (logic doc or data profile)
    - For each edge: verify target node has a doc
    - Broken edge → gap type: "broken_edge"
    
    CHECK 5: NEW values in live DB not in edge graph (DATA FRESHNESS)
    - Re-query Oracle for ALL LOOKUP/CONFIG tables
    - Compare live distinct values with values in data_drives_branch.json
    - New values not in edges → gap type: "new_data_value"
    - CRITICAL: These are values that code may not handle
    
    CHECK 6: STALE values in edge graph not in live DB
    - Values in edges but no longer in live DB → gap type: "stale_edge"
    - Severity: "warning" (value was removed, edge is outdated)
    
    CHECK 7: Implicit relationship completeness
    - For each chained lookup in Phase 2 logic docs:
      Verify a matching edge exists in implicit_relationships.json or chained_lookups.json
    - Missing → gap type: "missing_implicit_relationship"
    
    CHECK 8: code_reads_data coverage
    - For each class in Phase 2 that has data access:
      Verify at least one code_reads_data edge exists
    - Missing → gap type: "missing_read_edge"
    
    CHECK 9: NULL and UNKNOWN handling documented
    - For each decision column linkage:
      Check that NULL value mapping exists
      Check that UNKNOWN/NEW value mapping exists
    - Missing → gap type: "missing_null_unknown_handling"
    
    Returns: gaps list
    """
```

---

## EDGE FILE FORMATS

### data_drives_branch.json
```json
[
  {
    "data_source": "oracle.ROUTING_CONFIG",
    "field": "ROUTING_TYPE",
    "value": "RTGS",
    "activates": "com.bank.payment.service.PaymentRouter.routeInstruction()",
    "branch_location": "com.bank.payment.service.PaymentRouter.routeInstruction():143",
    "downstream_effect": "Calls RtgsProcessor.process() which publishes to kafka.swift.outbound",
    "terminal_action": "Kafka publish to swift.outbound topic"
  },
  {
    "data_source": "oracle.ROUTING_CONFIG",
    "field": "ROUTING_TYPE",
    "value": "__NULL__",
    "activates": "com.bank.payment.service.PaymentRouter.routeInstruction()",
    "branch_location": "com.bank.payment.service.PaymentRouter.routeInstruction():143",
    "downstream_effect": "NullPointerException — no null check exists",
    "terminal_action": "RUNTIME ERROR — unhandled"
  },
  {
    "data_source": "oracle.ROUTING_CONFIG",
    "field": "ROUTING_TYPE",
    "value": "__UNKNOWN__",
    "activates": "com.bank.payment.service.PaymentRouter.routeInstruction()",
    "branch_location": "com.bank.payment.service.PaymentRouter.routeInstruction():155",
    "downstream_effect": "Falls to default branch → ManualQueue.enqueue()",
    "terminal_action": "Added to manual processing queue"
  }
]
```

### implicit_relationships.json
```json
[
  {
    "type": "IMPLICIT_FK",
    "source_table": "ACCOUNT_CONFIG",
    "source_column": "FEE_GROUP",
    "target_table": "FEE_SCHEDULE",
    "target_column": "FEE_GROUP",
    "discovered_in_class": "com.bank.payment.service.EnrichmentService",
    "discovered_in_method": "enrich",
    "description": "Account's fee_group used to look up fee schedule. No DB FK exists."
  }
]
```

### chained_lookups.json
```json
[
  {
    "chain_id": "chain_001",
    "steps": [
      {"step": 1, "source": "input.debitAccount", "lookup_table": "ACCOUNT_CONFIG", "lookup_key": "ACCOUNT_ID", "result_field": "FEE_GROUP"},
      {"step": 2, "source": "step1.FEE_GROUP", "lookup_table": "FEE_SCHEDULE", "lookup_key": "FEE_GROUP", "result_field": "*"},
      {"step": 3, "source": "step1.BASE_CURRENCY", "lookup_table": "CUTOFF_TIME", "lookup_key": "CURRENCY", "result_field": "*"}
    ],
    "discovered_in": "com.bank.payment.service.EnrichmentService.enrich()",
    "description": "Debit account → account config → fee schedule AND cutoff time (parallel chain)"
  }
]
```

---

## END OF FILE 05 SPECIFICATION

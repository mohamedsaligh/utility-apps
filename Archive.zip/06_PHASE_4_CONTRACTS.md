# FILE 06 — PHASE 4: CONTRACT & INTEGRATION MAPPING
# Documents every Kafka topic, MQ queue, REST endpoint as contracts.
# Traces end-to-end flows from entry points to terminal points.
# Connects to Oracle + GemFire for live verification.

---

## INSTRUCTION TO AGENT

Generate Python scripts for Phase 4. Place in `{PROJECT_ROOT}/.knowledge-base/phase-4/`.

---

## SCRIPT 1: run_phase_4.py (Main Orchestrator)

```
PURPOSE: Document every integration point as a contract.
         Trace every end-to-end business flow across services.

ALGORITHM:

1. Load config
2. Load ALL previous phase outputs
3. Connect to Oracle + GemFire (for data context in flow tracing)
4. Create output dirs: phase-4/output/contracts/{kafka,mq,rest}/, phase-4/output/flows/

5. STEP 1: Kafka Topic Contracts
   For each Kafka topic in access_map.topic_access:
     producers = find_all_producers(topic)
     consumers = find_all_consumers(topic)
     
     # Try to determine message schema:
     # a. Check for Avro schema files (.avsc) in project
     # b. Check producer code for the DTO/class being sent
     # c. Check consumer code for the class being deserialized
     message_schema = determine_message_schema(topic, producers, consumers)
     
     # Build context: producer logic docs + consumer logic docs + message schema
     prompt = render_prompt('phase-4/prompts/kafka_contract.prompt.md', {
         'topic': topic,
         'producers': [{
             'class': p['class'],
             'method': p['method'],
             'logic_doc': read_logic_doc(p['class']),
             'source_snippet': extract_method_source(p)
         } for p in producers],
         'consumers': [{
             'class': c['class'],
             'method': c['method'],
             'group_id': c.get('group_id'),
             'logic_doc': read_logic_doc(c['class']),
             'source_snippet': extract_method_source(c)
         } for c in consumers],
         'message_schema': message_schema,
         'data_context': get_data_context_for_topic(topic)
     })
     result = llm.call(prompt)
     write_kb(f'phase-4/output/contracts/kafka/{sanitize(topic)}.md', result)

6. STEP 2: MQ Queue Contracts (same pattern as Kafka)
   For each MQ queue in access_map.queue_access:
     senders = find_all_senders(queue)
     receivers = find_all_receivers(queue)
     message_schema = determine_mq_message_schema(queue, senders, receivers)
     # ... same LLM call pattern ...
     write_kb(f'phase-4/output/contracts/mq/{sanitize(queue)}.md', result)

7. STEP 3: REST Endpoint Contracts
   For each REST endpoint in access_map.endpoint_access:
     handler_class = endpoint['class']
     handler_method = endpoint['method']
     http_method = endpoint['http_method']
     path = endpoint['path']
     
     # Get request/response DTOs from method signature
     request_dto = extract_request_body_type(handler_method)
     response_dto = extract_return_type(handler_method)
     
     # Get caller info: who calls this endpoint externally?
     # Check for RestTemplate/WebClient calls to this path in other modules
     callers = find_rest_callers(path, access_map)
     
     prompt = render_prompt('phase-4/prompts/rest_contract.prompt.md', {
         'path': path,
         'http_method': http_method,
         'handler_class': handler_class,
         'handler_method': handler_method,
         'handler_logic': read_logic_doc(handler_class),
         'request_dto': get_dto_structure(request_dto),
         'response_dto': get_dto_structure(response_dto),
         'callers': callers
     })
     result = llm.call(prompt)
     write_kb(f'phase-4/output/contracts/rest/{sanitize(path)}.md', result)

8. STEP 4: End-to-End Flow Tracing
   # Identify all ENTRY POINTS into the system:
   entry_points = []
   entry_points += find_rest_endpoints()          # REST controllers
   entry_points += find_kafka_consumers()          # Kafka listeners
   entry_points += find_mq_receivers()             # MQ listeners
   entry_points += find_scheduled_tasks()          # @Scheduled methods
   entry_points += find_event_listeners()          # Spring ApplicationEvent listeners
   
   For each entry_point:
     # Trace the flow using call graph + data edges
     reachable = trace_reachable_methods(entry_point, call_graph, data_edges)
     
     # Gather all logic docs along the flow
     flow_docs = [read_logic_doc(cls) for cls in unique_classes(reachable)]
     
     # Gather data context along the flow
     flow_data = gather_flow_data_context(reachable, access_map, 
                                           oracle_profiles, gemfire_profiles)
     
     prompt = render_prompt('phase-4/prompts/trace_flow.prompt.md', {
         'entry_point': entry_point,
         'reachable_methods': reachable,
         'logic_docs': flow_docs,
         'data_context': flow_data,
         'data_edges': get_relevant_edges(reachable),
         'contracts': get_relevant_contracts(reachable)
     })
     result = llm.call(prompt)
     write_kb(f'phase-4/output/flows/{sanitize(entry_point["name"])}.flow.md', result)

9. VALIDATION LOOP:
   gaps = validate_phase_4(...)
   while gaps and iteration < max:
       fix_gaps(...)
       gaps = validate_phase_4(...)
   save_manifest(...)
```

---

## PROMPT TEMPLATE: kafka_contract.prompt.md

```markdown
# Kafka Topic Contract Documentation

Document this Kafka topic as a complete contract between producers and consumers.

## Topic: {topic_name}

### Producers:
{for each producer:}
#### Producer: {class_name}.{method_name}
Logic doc excerpt: {logic_doc}
Source snippet:
```java
{source_snippet}
```
{end for}

### Consumers:
{for each consumer:}
#### Consumer: {class_name}.{method_name} (Group: {group_id})
Logic doc excerpt: {logic_doc}
Source snippet:
```java
{source_snippet}
```
{end for}

### Message Schema:
{message_schema}

---

## YOUR TASK:

### 1. MESSAGE CONTRACT
- **Message key**: What is the partition key? How is it derived?
- **Message value**: Complete field-by-field schema of the message body
- **Required fields**: Which fields must always be present?
- **Serialization**: JSON, Avro, Protobuf, or Java serialization?
- **Headers**: Any Kafka headers used?

### 2. PRODUCER BEHAVIOR
For each producer:
- **Trigger**: What causes this producer to send a message?
- **Message construction**: How is the message built? Which data sources feed it?
- **Failure handling**: What happens if Kafka publish fails? Retry? Dead letter?
- **Ordering guarantee**: Is message ordering important? How is it ensured?

### 3. CONSUMER BEHAVIOR
For each consumer:
- **Processing semantics**: At-least-once? Exactly-once? At-most-once?
- **Processing logic**: What does the consumer DO with the message? (Summary from logic doc)
- **Idempotency**: Can the same message be processed twice safely?
- **Error handling**: What happens if processing fails? DLQ? Retry? Manual intervention?
- **Offset commit**: Auto-commit or manual? When?

### 4. DATA FLOW
- **Complete chain**: What data enters the producer → becomes the message → what the consumer does with it → where does the data end up?
- **Data transformations**: Is the message structure different from the source data?
- **Data enrichment**: Does the consumer look up additional data before processing?

### 5. OPERATIONAL CONCERNS
- **Topic partitions**: How many? What determines partition assignment?
- **Consumer groups**: How many consumer instances? Can they scale independently?
- **Lag monitoring**: What's the acceptable consumer lag?
```

---

## PROMPT TEMPLATE: trace_flow.prompt.md

```markdown
# End-to-End Flow Tracing Task

Trace the COMPLETE flow from an entry point through all services, data lookups,
and integrations until it reaches terminal point(s).

## Entry Point: {entry_point_type} — {entry_point_name}
Class: {entry_class}.{entry_method}
Trigger: {how this entry point is activated}

## Methods Reachable From This Entry Point:
{reachable_methods}

## Logic Documentation Along This Flow:
{logic_docs}

## Data Accessed Along This Flow:
{data_context}

## Data-Driven Branches Along This Flow:
{relevant_data_edges}

## Integration Points Along This Flow:
{relevant_contracts}

---

## YOUR TASK:

### FLOW DIAGRAM (text-based):
```
Step 1: [entry point] receives {input type}
  ↓
Step 2: [Class.method()] — {what it does}
  ↓ reads {table/region}
Step 3: [Class.method()] — {what it does}
  ├── IF {condition from data}: 
  │     ↓ Step 4a: [path A]
  │     ↓ publishes to {Kafka topic / MQ queue}
  │     ↓ [TERMINAL: message sent]
  └── ELSE:
        ↓ Step 4b: [path B]
        ↓ writes to {Oracle table}
        ↓ [TERMINAL: DB record created]
```

### DETAILED FLOW STEPS:
For each step:
1. **Step N**: {Class.method()} — Line {X}
   - **Action**: {what happens}
   - **Data read**: {table.column or region.key}
   - **Data values that affect flow**: 
     * If {column} = "{value1}" → go to step {M}
     * If {column} = "{value2}" → go to step {P}
   - **Data written**: {table.column or Kafka topic}
   - **Error handling**: {what happens if this step fails}

### TERMINAL POINTS:
List every possible endpoint of this flow:
- **Normal completion**: {what success looks like}
- **Error paths**: {each distinct error outcome}
- **Timeout paths**: {what happens if external calls timeout}

### PARALLEL PROCESSING:
If this flow involves parallel execution (CompletableFuture, @Async, thread pools):
- Which steps run in parallel?
- How are results aggregated?
- What happens if one parallel branch fails?

### DATA MUTATION SUMMARY:
By the time this flow completes, what data has been:
- **Created**: {new records in which tables}
- **Updated**: {modified records in which tables}
- **Published**: {messages to which Kafka topics / MQ queues}
- **Cached**: {entries written to which GemFire regions}
```

---

## SCRIPT 2: validate_phase_4.py

```
PURPOSE: Validate all contracts and flows for completeness.

FUNCTION:

def validate(config, all_phase_outputs, oracle_conn, gemfire_conn) -> List[Dict]:
    """
    THE 8 CHECKS:
    
    CHECK 1: Every Kafka topic has a contract doc
    - All topics from access_map → check contracts/kafka/{topic}.md exists
    - Contract must have producer AND consumer sections
    - Topic with no documented consumer → gap type: "topic_no_consumer" (warning — might be external)
    - Topic with no documented producer → gap type: "topic_no_producer"
    
    CHECK 2: Every MQ queue has a contract doc
    - Same pattern as Kafka
    
    CHECK 3: Every REST endpoint has a contract doc
    - All endpoints from access_map → check contracts/rest/{endpoint}.md exists
    - gap type: "endpoint_no_contract"
    
    CHECK 4: Every entry point has a traced flow
    - All entry points (REST, Kafka consumer, MQ listener, scheduler) → check flows/{name}.flow.md
    - gap type: "entry_point_no_flow"
    
    CHECK 5: Every flow reaches a terminal point
    - Parse each flow doc
    - Flow must have at least one terminal (response, publish, write)
    - No terminal → gap type: "flow_no_terminal"
    
    CHECK 6: Every flow step references a documented method
    - Each step in a flow doc should reference a class.method from Phase 2
    - Reference to undocumented method → gap type: "flow_step_undocumented"
    
    CHECK 7: Cross-flow message schema consistency
    - If flow A publishes to topic X with schema S_A, and flow B consumes from topic X
      expecting schema S_B, verify S_A is compatible with S_B
    - Mismatch → gap type: "schema_mismatch"
    
    CHECK 8: Data branch completeness in flows
    - Each flow that passes through a data-driven branch point (from Phase 3 edges)
      should document ALL possible paths from that branch
    - Missing branch variant → gap type: "flow_missing_branch_variant"
    """
```

---

## END OF FILE 06 SPECIFICATION

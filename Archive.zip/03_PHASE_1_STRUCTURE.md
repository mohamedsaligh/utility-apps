# FILE 03 — PHASE 1: STRUCTURAL MAPPING
# LLM-powered breadth-first module analysis.
# Reads Phase 0 output. No direct DB connection needed (uses Phase 0 cached data).

---

## INSTRUCTION TO AGENT

Generate Python scripts for Phase 1. Place in `{PROJECT_ROOT}/.knowledge-base/phase-1/`.
Also generate the prompt template files in `phase-1/prompts/`.

---

## SCRIPT 1: run_phase_1.py (Main Orchestrator)

```
PURPOSE: For each Maven module, use LLM to generate structural documentation.
         Then run cross-module reconciliation. Then validate and loop.

ALGORITHM:

1. Load config
2. Load Phase 0 outputs:
   - module_graph.json (module names, dependencies, topological order)
   - class_index.json (every class with module, type, annotations)
   - access_map.json (code→data mappings)
   - config_scan.json (all parsed configs)
   - oracle_profiles.json (table schemas — used for data context)
   - gemfire_profiles.json (region metadata)
   - table_classification.json (LOOKUP vs TRANSACTIONAL)
3. Create output directory: phase-1/output/modules/

4. Process modules in topological order (dependencies first, dependents later):
   for module_name in module_graph['topological_order']:
       
       # Skip if already documented and --resume flag
       if resume and module_overview_exists(module_name):
           continue
       
       # Build context for this module
       context = build_module_context(module_name, module_graph, class_index, 
                                       access_map, config_scan, oracle_profiles,
                                       gemfire_profiles, table_classification)
       
       # Call LLM with module overview prompt
       prompt = render_prompt('phase-1/prompts/module_overview.prompt.md', context)
       response = llm.call(prompt)
       
       # Parse response into structured sections
       sections = parse_module_response(response)
       
       # Write output files
       write_kb(f'phase-1/output/modules/{module_name}/OVERVIEW.md', sections['overview'])
       write_kb(f'phase-1/output/modules/{module_name}/CLASS_MAP.md', sections['class_map'])
       write_kb(f'phase-1/output/modules/{module_name}/DEPENDENCIES.md', sections['dependencies'])
       write_kb(f'phase-1/output/modules/{module_name}/CONFIG.md', sections['config'])

5. Cross-module reconciliation:
   - Concatenate ALL module overviews into one document
   - Send to LLM with reconciliation prompt
   - Ask LLM to identify:
     * Inconsistencies between module descriptions
     * Missing cross-module relationships
     * Modules that should reference each other but don't
     * Contradictions in data ownership claims
   - Write: phase-1/output/RECONCILIATION_REPORT.md

6. VALIDATION LOOP:
   iteration = 0
   while iteration < max_iterations:
       gaps = validate_phase_1(config, phase_0_output, phase_1_output)
       if len(gaps) == 0:
           break
       
       iteration += 1
       for gap in gaps:
           if gap.type == "module_not_documented":
               reprocess_module(gap.module_name)
           elif gap.type == "class_not_in_map":
               reprocess_module_with_extra_context(gap.module_name, gap.class_name)
           elif gap.type == "cross_module_inconsistency":
               reprocess_both_modules(gap.module_a, gap.module_b)
           elif gap.type == "data_ref_missing":
               reprocess_module_with_data_context(gap.module_name, gap.table_name)
   
   save_manifest(...)
```

### build_module_context() function specification:

```python
def build_module_context(module_name: str, module_graph: Dict, class_index: Dict,
                          access_map: Dict, config_scan: Dict, oracle_profiles: Dict,
                          gemfire_profiles: Dict, table_classification: Dict) -> Dict:
    """
    Build a RICH context dict for LLM processing of one module.
    
    The context includes:
    
    1. MODULE METADATA:
       - artifact_id, group_id, packaging
       - Path in project
       - Internal dependencies (which modules this depends on)
       - Dependents (which modules depend on this)
       - Is this a shared/common module?
    
    2. CLASS LIST (every class in this module):
       For each class:
       - Fully qualified name
       - Type (class, interface, enum, abstract)
       - Annotations (just names, not full params)
       - Extends/implements
       - Method count
       - Field count
       
       Group classes by type:
       - Services (annotated @Service)
       - Controllers (annotated @Controller/@RestController)
       - Repositories/DAOs (annotated @Repository or extends JpaRepository)
       - Entities (annotated @Entity)
       - DTOs/Models (no Spring annotations, mostly fields)
       - Configurations (annotated @Configuration)
       - Utilities (everything else)
    
    3. DATA ACCESS SUMMARY (from access_map):
       - Tables this module accesses (with read/write breakdown)
       - GemFire regions this module uses
       - Kafka topics this module produces to / consumes from
       - MQ queues this module uses
       - REST endpoints this module exposes
       - REST endpoints this module calls (outbound)
    
    4. DATA DETAILS (from oracle_profiles + gemfire_profiles):
       For each table/region this module accesses:
       - Schema (column names and types only — not full profile)
       - Classification (LOOKUP vs TRANSACTIONAL)
       - Row count
       - For LOOKUP tables: summary of distinct values in key columns
    
    5. CONFIG CONTEXT:
       - Module-specific application.yml properties
       - Profile-specific overrides
       - Bean definitions from Spring XML if any
    
    6. DEPENDENCY CONTEXT:
       - For each internal dependency module:
         * Brief description (from its overview if already processed, else from POM description)
         * What this module likely imports from the dependency
    
    TOKEN MANAGEMENT:
    - Estimate total tokens
    - If over LLM context limit, prioritize: class list > data summary > config > dependency context
    - Truncate least important sections first
    - Log what was truncated
    
    Returns: Dict with all sections, ready for template rendering.
    """
```

---

## PROMPT TEMPLATE: module_overview.prompt.md

```markdown
# Module Analysis Task

You are analyzing one module of a large Java microservices payment processing system.
Your task is to produce comprehensive structural documentation for this module.

## Module: {module_name}
- Artifact: {artifact_id}
- Group: {group_id}
- Packaging: {packaging}
- Path: {module_path}

## Internal Dependencies (modules this depends on):
{internal_dependencies}

## Modules That Depend On This:
{dependents}

## Classes in This Module:

### Services:
{service_classes}

### Controllers:
{controller_classes}

### Repositories/DAOs:
{repository_classes}

### Entities:
{entity_classes}

### DTOs/Models:
{dto_classes}

### Configurations:
{config_classes}

### Other:
{other_classes}

## Data Access:

### Oracle Tables Accessed:
{table_access_summary}

### GemFire Regions Used:
{region_access_summary}

### Kafka Topics:
{kafka_summary}

### MQ Queues:
{mq_summary}

### REST Endpoints Exposed:
{rest_endpoints}

## Data Details:
{data_details}

## Configuration:
{config_context}

---

## YOUR TASK — Produce ALL of the following sections:

### SECTION 1: OVERVIEW.md

Write 3-5 paragraphs covering:
1. What is this module's PRIMARY purpose in the payment system?
2. What business domain does it serve? (e.g., payment routing, validation, enrichment, settlement)
3. What are the ENTRY POINTS into this module? (REST endpoints, Kafka consumers, MQ listeners, schedulers, or calls from other modules)
4. What are the EXIT POINTS from this module? (outbound Kafka, MQ, REST calls, DB writes)
5. What STATIC DATA / REFERENCE DATA does this module depend on to make decisions?
6. How does this module interact with other modules? (sync calls, async events, shared data)

Be SPECIFIC. Name actual classes, actual tables, actual topics. Don't be vague.

### SECTION 2: CLASS_MAP.md

For EVERY class in this module, produce one line:
```
| ClassName | Type | Purpose (1 sentence) | Key Dependencies |
```

Type is one of: Service, Controller, DAO, Entity, DTO, Config, Util, Listener, Processor, Validator, Mapper, Exception, Test

Purpose must be specific to what this class ACTUALLY does, not generic.
Key Dependencies: list the 2-3 most important injected dependencies.

Do NOT skip any class. Every single class must appear in this table.

### SECTION 3: DEPENDENCIES.md

Document:
1. **Inbound dependencies**: What does this module IMPORT from other internal modules?
   For each dependency module, list:
   - Which classes/interfaces from that module are used here
   - WHY they're needed (what functionality they provide)

2. **Outbound dependencies**: What does this module EXPORT to other modules?
   - Which classes/interfaces from this module are used by dependents
   - Which shared DTOs or service interfaces are defined here

3. **Data dependencies**: 
   - Which Oracle tables does this module OWN (writes to)?
   - Which Oracle tables does this module READ from?
   - Which GemFire regions does this module depend on?
   - What would break if each data source became unavailable?

4. **External dependencies**:
   - Kafka topics: producer vs consumer role
   - MQ queues: sender vs receiver role
   - REST APIs: called vs exposed

### SECTION 4: CONFIG.md

Document:
1. All configuration properties this module uses
2. Which properties are environment-specific (differ by profile)
3. What happens if a required property is missing
4. Any feature flags or conditional beans
5. Connection configs (DB, cache, messaging)

---

CRITICAL REQUIREMENTS:
- Do NOT skip any class in the CLASS_MAP. Every class must be listed.
- Do NOT use vague descriptions. Be specific about what each thing does.
- Name actual table names, actual region names, actual topic names.
- If you see a class but aren't sure what it does, say "Purpose unclear from structural analysis — needs deeper review" rather than guessing.
- Separate your response into exactly 4 clearly labeled sections: OVERVIEW, CLASS_MAP, DEPENDENCIES, CONFIG.
```

---

## PROMPT TEMPLATE: reconciliation.prompt.md

```markdown
# Cross-Module Reconciliation Task

You have the structural overviews of ALL modules in a payment processing system.
Your task is to find INCONSISTENCIES, GAPS, and MISSING RELATIONSHIPS.

## Module Overviews:
{all_module_overviews}

## Module Dependency Graph:
{adjacency_graph}

## Complete Data Access Map:
{data_access_summary}

---

## YOUR TASK:

1. **Cross-Reference Check**: For each module that says it depends on module X, verify that module X's overview mentions providing that functionality.

2. **Data Ownership Conflicts**: If two modules both claim to WRITE to the same Oracle table, flag this as a potential conflict (or confirm it's intentional).

3. **Missing Relationships**: Based on the data access map, identify modules that access the SAME data sources but don't mention each other in their dependency docs.

4. **Orphan Modules**: Modules with no inbound or outbound dependencies — are they truly standalone or did we miss connections?

5. **Flow Gaps**: Can you identify any business flows where the chain of modules is incomplete? (e.g., module A produces to Kafka topic X, but no module is documented as consuming from topic X)

6. **Inconsistent Terminology**: Different modules using different names for the same concept.

For each finding, format as:
```
FINDING: [type]
MODULES: [affected modules]
DESCRIPTION: [what's wrong]
SUGGESTED FIX: [how to resolve]
```
```

---

## SCRIPT 2: validate_phase_1.py

```
PURPOSE: Validate Phase 1 completeness. Return gaps to fix.

FUNCTION:

def validate(config: Config, phase_0_output: str, phase_1_output: str) -> List[Dict]:
    """
    THE 8 CHECKS:
    
    CHECK 1: Every module has documentation
    - Load module_graph.json → get all module names
    - Check phase-1/output/modules/{module}/ exists with OVERVIEW.md, CLASS_MAP.md, DEPENDENCIES.md, CONFIG.md
    - Missing module → gap type: "module_not_documented"
    
    CHECK 2: Every class appears in at least one module's CLASS_MAP
    - Load class_index.json → get all class FQNs
    - Parse all CLASS_MAP.md files → get all documented classes
    - Class in index but not in any class map → gap type: "class_not_in_map"
    
    CHECK 3: Cross-module dependency consistency
    - If module A's DEPENDENCIES.md says it imports from module B,
      module B should exist and its OVERVIEW.md should mention 
      providing that functionality
    - Inconsistency → gap type: "cross_module_inconsistency"
    
    CHECK 4: Data reference completeness
    - For each table in access_map, find the module(s) that access it
    - Check that each accessing module's OVERVIEW.md or DEPENDENCIES.md mentions this table
    - Table accessed but not mentioned → gap type: "data_ref_missing"
    
    CHECK 5: Same check for GemFire regions
    - Region accessed but not mentioned in module docs → gap type: "region_ref_missing"
    
    CHECK 6: Same check for Kafka topics
    - Topic produced/consumed but not mentioned → gap type: "topic_ref_missing"
    
    CHECK 7: Same check for REST endpoints
    - Endpoint exposed but not documented → gap type: "endpoint_ref_missing"
    
    CHECK 8: Reconciliation findings resolved
    - Parse RECONCILIATION_REPORT.md
    - Any "CRITICAL" findings that weren't addressed → gap
    - Type: "reconciliation_unresolved"
    
    Return all gaps sorted by severity.
    """
```

---

## END OF FILE 03 SPECIFICATION

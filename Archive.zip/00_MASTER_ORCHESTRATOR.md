# MASTER ORCHESTRATOR — Knowledge Base Builder v2
# Complete Self-Verifying, Data-Linked Knowledge Base for Java Microservices Payment System

---

## WHAT THIS IS

This is a set of prompt documents (files 00 through 09). Each document contains the COMPLETE specification for generating Python scripts that build one phase of an exhaustive knowledge base from a large Java microservices codebase (~50k files). You feed each document to an AI agent (GitHub Copilot, Claude Code, etc.) on your remote machine, and it generates all the scripts for that phase.

## CRITICAL: READ ORDER

Generate scripts in this exact order. Each phase depends on the previous.

```
FILE 01 → Generate utils.py (shared by ALL phases)
FILE 02 → Generate Phase 0 scripts (Discovery & Profiling)
FILE 03 → Generate Phase 1 scripts (Structural Mapping)
FILE 04 → Generate Phase 2 scripts (Logic Extraction)
FILE 05 → Generate Phase 3 scripts (Data-Code Linking)
FILE 06 → Generate Phase 4 scripts (Contract & Integration Mapping)
FILE 07 → Generate Phase 5 scripts (Verification & Gap Closure)
FILE 08 → Generate Phase 6 scripts (Synthesis & Agent Packaging)
FILE 09 → Generate Weekly Update scripts (Incremental Maintenance)
```

## TARGET ENVIRONMENT

- **Network**: Restricted network inside a global bank (no external internet)
- **Codebase**: Java microservices, Maven multi-module, Spring Boot/Spring Framework
- **Data layer**: Oracle DB (Kerberos authentication), GemFire/Apache Geode distributed cache
- **Messaging**: Apache Kafka, IBM MQ, REST APIs
- **Processing**: Parallel processing with aggregation, event-driven design
- **AI tools**: GitHub Copilot (Opus 4.6 or other) in VS Code/IntelliJ, OR Claude Code CLI
- **DB access**: Python scripts can connect to Oracle via cx_Oracle/oracledb and GemFire via REST API
- **Python**: 3.9+ available on the machine

## EVERY PHASE HAS THIS INTERNAL STRUCTURE

```
┌────────────────────────────────────────────┐
│             PHASE N EXECUTION              │
│                                            │
│   ┌──────────┐                             │
│   │ EXTRACT  │◄─────────────────┐          │
│   └────┬─────┘                  │          │
│        ▼                        │          │
│   ┌──────────┐    ┌──────────┐  │ NO       │
│   │ VALIDATE ├───►│ 100%?    ├──┘          │
│   └──────────┘    └────┬─────┘             │
│                        │ YES               │
│                        ▼                   │
│                  ┌───────────┐             │
│                  │ LOCK PHASE│             │
│                  │ → NEXT    │             │
│                  └───────────┘             │
│                                            │
│   MAX ITERATIONS: 5 (then flag for manual) │
└────────────────────────────────────────────┘
```

Every phase:
1. EXTRACTS information (code parsing, DB queries, LLM calls)
2. VALIDATES its own output against source of truth
3. LOOPS if validation finds gaps (re-extracts with targeted context)
4. LOCKS only when validation passes 100% OR max iterations reached (remaining gaps flagged)
5. Produces a `manifest.json` with coverage stats, gaps list, and lock status

## config.yml SPECIFICATION

Create this file FIRST before running any phase. Every script reads from it.

```yaml
# ============================================================
# config.yml — Master Configuration for Knowledge Base Builder
# ============================================================

project:
  root: "/path/to/your/java/project"           # Absolute path to project root
  name: "payment-system"                         # Human-readable project name
  source_dirs:                                   # Directories containing Java source
    - "src/main/java"
    - "src/main/resources"
  test_dirs:                                     # Test directories (documented separately)
    - "src/test/java"
  exclude_patterns:                              # Glob patterns to skip
    - "**/target/**"
    - "**/build/**"
    - "**/node_modules/**"
    - "**/.git/**"
    - "**/generated-sources/**"

oracle:
  enabled: true                                  # Set false if no Oracle access
  host: "oracle-host.bank.internal"
  port: 1521
  service_name: "PAYMENT_DB"
  auth_method: "kerberos"                        # "kerberos" or "password"
  # For Kerberos auth:
  keytab_path: "/path/to/your.keytab"
  principal: "user@BANK.REALM"
  # For password auth (fallback):
  # username: "readonly_user"
  # password: "***"
  schema_owner: "PAYMENT_SCHEMA"                 # Default schema to query
  additional_schemas:                             # Other schemas to check
    - "AUDIT_SCHEMA"
    - "CONFIG_SCHEMA"
  query_timeout_seconds: 30
  max_rows_for_distinct: 50000                   # Skip distinct value scan if > this
  sample_row_count: 10                           # Number of sample rows to capture

gemfire:
  enabled: true                                  # Set false if no GemFire access
  rest_api_url: "http://gemfire-locator:7070/gemfire-api/v1"
  # If GemFire requires auth:
  auth_username: ""
  auth_password: ""
  # If using JMX instead of REST:
  jmx_host: ""
  jmx_port: 1099
  max_entries_for_full_dump: 5000                # Dump all entries if region < this
  sample_entry_count: 10

llm:
  mode: "claude_code_cli"                        # "claude_code_cli" | "copilot_file" | "api"
  # For claude_code_cli:
  claude_code_path: "claude"                     # Path to claude CLI binary
  claude_model: "opus"                           # Model to use
  # For copilot_file mode:
  copilot_workspace: "/path/to/copilot/workspace"  # Dir where Copilot reads files
  # For API mode:
  api_endpoint: "https://api.internal/v1/chat"
  api_key: ""
  api_model: "claude-opus-4-20250115"
  # Common settings:
  max_tokens_per_call: 8000                      # Max output tokens per LLM call
  max_context_tokens: 100000                     # Max input context tokens
  rate_limit_delay_seconds: 2                    # Delay between LLM calls
  max_retries: 3                                 # Retry failed LLM calls

knowledge_base:
  output_dir: "{project.root}/.knowledge-base"   # Where KB files are written
  log_dir: "{project.root}/.knowledge-base/.logs"
  max_validation_iterations: 5                   # Max self-healing loops per phase
  parallel_workers: 4                            # Parallel file processing threads

validation:
  min_method_coverage_pct: 100                   # Target: every method documented
  min_branch_coverage_pct: 95                    # Target: 95% of branches documented
  min_data_link_pct: 100                         # Target: every data access linked
  random_deep_verify_sample_size: 30             # Classes to deep-verify in Phase 5
  deep_verify_min_score: 95                      # Minimum score (0-100) to pass
```

## DIRECTORY STRUCTURE (created by scripts)

```
{PROJECT_ROOT}/.knowledge-base/
├── MANIFEST.md                          # Master index, timestamps, coverage
├── SKILL.md                             # Agent instruction file
├── config.yml                           # YOUR configuration (create manually)
├── utils.py                             # Shared utilities (generated from FILE 01)
├── phase-0/
│   ├── run_phase_0.py
│   ├── parse_maven.py
│   ├── parse_java_ast.py
│   ├── scan_annotations.py
│   ├── scan_configs.py
│   ├── profile_oracle.py
│   ├── profile_gemfire.py
│   ├── classify_tables.py
│   ├── validate_phase_0.py
│   └── output/
│       ├── manifest.json
│       ├── module_graph.json
│       ├── class_index.json
│       ├── method_signatures.json
│       ├── annotation_scan.json
│       ├── config_scan.json
│       ├── oracle_profiles.json
│       ├── gemfire_profiles.json
│       ├── table_classification.json
│       ├── access_map.json
│       ├── call_graph.json
│       └── gaps.json
├── phase-1/
│   ├── run_phase_1.py
│   ├── validate_phase_1.py
│   ├── prompts/
│   │   ├── module_overview.prompt.md
│   │   └── reconciliation.prompt.md
│   └── output/
│       ├── manifest.json
│       └── modules/{module_name}/
│           ├── OVERVIEW.md
│           ├── CLASS_MAP.md
│           ├── DEPENDENCIES.md
│           └── CONFIG.md
├── phase-2/
│   ├── run_phase_2.py
│   ├── validate_phase_2.py
│   ├── prompts/
│   │   ├── class_logic_with_data.prompt.md
│   │   └── class_logic_repair.prompt.md
│   └── output/
│       ├── manifest.json
│       └── modules/{module_name}/classes/{ClassName}.logic.md
├── phase-3/
│   ├── run_phase_3.py
│   ├── validate_phase_3.py
│   ├── prompts/
│   │   ├── data_code_linkage.prompt.md
│   │   └── implicit_relationship.prompt.md
│   └── output/
│       ├── manifest.json
│       ├── data_links/
│       │   ├── oracle.{TABLE}.link.md
│       │   └── gemfire.{REGION}.link.md
│       └── edges/
│           ├── data_drives_branch.json
│           ├── code_reads_data.json
│           ├── code_writes_data.json
│           ├── implicit_relationships.json
│           └── chained_lookups.json
├── phase-4/
│   ├── run_phase_4.py
│   ├── validate_phase_4.py
│   ├── prompts/
│   │   ├── kafka_contract.prompt.md
│   │   ├── mq_contract.prompt.md
│   │   ├── rest_contract.prompt.md
│   │   └── trace_flow.prompt.md
│   └── output/
│       ├── manifest.json
│       ├── contracts/
│       │   ├── kafka/{topic_name}.md
│       │   ├── mq/{queue_name}.md
│       │   └── rest/{endpoint_name}.md
│       └── flows/{flow_name}.flow.md
├── phase-5/
│   ├── run_phase_5.py
│   ├── validate_phase_5.py
│   ├── prompts/
│   │   └── deep_verify.prompt.md
│   └── output/
│       ├── manifest.json
│       ├── verification_report.md
│       └── gap_closure_log.json
├── phase-6/
│   ├── run_phase_6.py
│   ├── validate_phase_6.py
│   ├── prompts/
│   │   ├── impact_analysis.prompt.md
│   │   ├── enhancement_guide.prompt.md
│   │   └── skill_generation.prompt.md
│   └── output/
│       ├── manifest.json
│       ├── IMPACT_ANALYSIS_GUIDE.md
│       ├── ENHANCEMENT_GUIDE.md
│       ├── COMMON_PATTERNS.md
│       ├── GOTCHAS.md
│       └── SKILL.md
└── weekly/
    ├── run_weekly_update.py
    └── output/
        └── update_logs/{date}.json
```

## EXECUTION COMMANDS

```bash
# Step 0: Create config.yml (manually)
# Step 1: Generate utils.py from FILE 01

# Step 2: Run phases sequentially
cd {PROJECT_ROOT}/.knowledge-base

python phase-0/run_phase_0.py --config config.yml    # Night 1
python phase-1/run_phase_1.py --config config.yml    # Night 1-2
python phase-2/run_phase_2.py --config config.yml    # Night 2-6
python phase-3/run_phase_3.py --config config.yml    # Night 6-7
python phase-4/run_phase_4.py --config config.yml    # Night 7-8
python phase-5/run_phase_5.py --config config.yml    # Night 8-9
python phase-6/run_phase_6.py --config config.yml    # Night 10

# Weekly thereafter:
python weekly/run_weekly_update.py --config config.yml
```

## PHASE DEPENDENCY MATRIX

```
Phase │ Reads From                    │ Writes To                     │ Connects To
──────┼───────────────────────────────┼───────────────────────────────┼──────────────
  0   │ Source code, config files     │ phase-0/output/*.json         │ Oracle, GemFire
  1   │ phase-0/output/               │ phase-1/output/modules/       │ (LLM only)
  2   │ phase-0/output/, phase-1/out/ │ phase-2/output/modules/       │ Oracle, GemFire
  3   │ phase-0/output/, phase-2/out/ │ phase-3/output/edges/         │ Oracle, GemFire
  4   │ phase-0/ thru phase-3/output/ │ phase-4/output/contracts/     │ Oracle, GemFire
  5   │ ALL phase outputs             │ phase-5/output/               │ Oracle, GemFire
  6   │ ALL phase outputs             │ phase-6/output/               │ Oracle, GemFire
  W   │ git diff + ALL phase outputs  │ Updates all affected phases   │ Oracle, GemFire
```

## IMPORTANT RULES FOR SCRIPT GENERATION

1. Every function that does I/O (file read/write, DB query, LLM call) MUST have try/except. A single failure must NOT crash the pipeline. Log the error and continue.
2. Every script takes `--config config.yml` as a CLI argument.
3. Every script uses the shared `utils.py` for Oracle/GemFire connections, LLM calls, config loading, and common helpers.
4. Every script writes a `manifest.json` at the end documenting what it did, coverage stats, and any gaps.
5. Every script supports `--resume` flag to skip already-completed items (for crash recovery).
6. All output files use UTF-8 encoding.
7. JSON output files must be pretty-printed with indent=2.
8. Markdown output files must use consistent heading structure.
9. Log files go to `{knowledge_base.log_dir}/phase-N-{timestamp}.log`.
10. Oracle connections must be pooled (not opened/closed per query).
11. GemFire REST API calls must have retry logic (3 retries with exponential backoff).
12. LLM calls must have retry logic (3 retries with 10-second delay).

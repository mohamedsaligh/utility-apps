# FILE 04 — PHASE 2: LOGIC EXTRACTION
# LLM depth-first class-by-class analysis. The heaviest phase (~70% of total work).
# Connects to Oracle + GemFire for live data context during extraction.

---

## INSTRUCTION TO AGENT

Generate Python scripts for Phase 2. Place in `{PROJECT_ROOT}/.knowledge-base/phase-2/`.
Also generate prompt templates in `phase-2/prompts/`.

Phase 2 documents EVERY method, EVERY branch, EVERY data access in EVERY class.

---

## SCRIPT 1: run_phase_2.py (Main Orchestrator)

```
PURPOSE: For each class in the project, use LLM to extract method-level logic
         with full data context (actual DB values mapped to code paths).

ALGORITHM:

1. Load config
2. Load Phase 0 outputs: class_index, method_signatures, access_map, call_graph,
                          oracle_profiles, gemfire_profiles, table_classification
3. Load Phase 1 outputs: module overviews, class maps
4. Initialize Oracle + GemFire connections (for live data queries during extraction)
5. Create output dir: phase-2/output/modules/

6. Build processing queue:
   - All Java classes from class_index, EXCLUDING:
     * Test classes (in test dirs)
     * Auto-generated classes (in generated-sources)
     * Simple POJOs with only getters/setters (< 5 methods, all are get/set/is)
   - Order: process shared/common modules first, then by module topological order
   - Within each module: process base classes/interfaces first, then implementations

7. For each class (with progress tracking):
   
   # Skip if already documented and --resume
   if resume and logic_doc_exists(class_name):
       continue
   
   # Read source code
   source = read_file(class_info['file_path'])
   
   # Build rich context
   context = build_class_context(
       class_name, source, class_info,
       module_overview,           # From Phase 1
       access_map,                # Which data this class accesses
       call_graph,                # What calls this, what this calls
       oracle_profiles,           # Table schemas + live data
       gemfire_profiles,          # Region data
       table_classification,      # LOOKUP vs TRANSACTIONAL
       oracle_conn,               # For fresh queries if needed
       gemfire_conn               # For fresh queries if needed
   )
   
   # Check if class is too large for single LLM call
   estimated_tokens = estimate_tokens(str(context))
   
   if estimated_tokens > config.llm.max_context_tokens * 0.7:
       # CHUNKED PROCESSING: split by method groups
       result = process_large_class(class_name, source, context, llm)
   else:
       # SINGLE CALL PROCESSING
       prompt = render_prompt('phase-2/prompts/class_logic_with_data.prompt.md', context)
       result = llm.call(prompt)
   
   # Validate response structure
   if not validate_logic_response(result, class_info):
       # Response seems incomplete — retry with repair prompt
       repair_prompt = render_prompt('phase-2/prompts/class_logic_repair.prompt.md', {
           'source': source,
           'existing_doc': result,
           'issues': get_response_issues(result, class_info),
           'data_context': context['data_context']
       })
       result = llm.call(repair_prompt)
   
   # Write output
   module = class_info['module']
   write_kb(f'phase-2/output/modules/{module}/classes/{class_name}.logic.md', result)

8. Close Oracle + GemFire connections

9. VALIDATION LOOP:
   iteration = 0
   while iteration < max_iterations:
       gaps = validate_phase_2(config, phase_0_output, phase_2_output, oracle_conn, gemfire_conn)
       if len(gaps) == 0:
           break
       
       iteration += 1
       # Reconnect to DB for gap fixing
       oracle_conn = OracleConnection(config.oracle)
       gemfire_conn = GemfireConnection(config.gemfire)
       
       # Group gaps by class for efficient re-processing
       gaps_by_class = group_gaps_by_class(gaps)
       
       for class_name, class_gaps in gaps_by_class.items():
           existing_doc = read_logic_doc(class_name)
           source = read_source(class_name)
           
           # Build TARGETED repair context
           fresh_data = {}
           for gap in class_gaps:
               if gap['type'] in ('missing_data_value', 'stale_data_value'):
                   table = gap.get('table')
                   if table:
                       fresh_data[table] = oracle_conn.get_distinct_values(table, gap.get('column', '*'))
               elif gap['type'] == 'missing_region_value':
                   region = gap.get('region')
                   if region:
                       fresh_data[region] = gemfire_conn.get_sample_entries(region)
           
           repair_prompt = render_prompt('phase-2/prompts/class_logic_repair.prompt.md', {
               'source': source,
               'existing_doc': existing_doc,
               'gaps': [g['description'] for g in class_gaps],
               'fresh_data': fresh_data,
               'instruction': 'Fix ONLY the gaps listed. Do not remove correct content. Merge fixes into existing doc.'
           })
           
           repaired = llm.call(repair_prompt)
           merge_into_logic_doc(class_name, repaired)
       
       oracle_conn.close()
       gemfire_conn.close()
   
   save_manifest(...)
```

### build_class_context() function specification:

```python
def build_class_context(class_name, source, class_info, module_overview,
                         access_map, call_graph, oracle_profiles, gemfire_profiles,
                         table_classification, oracle_conn, gemfire_conn):
    """
    Build comprehensive context for LLM analysis of one class.
    
    ALWAYS INCLUDE:
    1. SOURCE CODE: The complete Java source of this class
    2. MODULE CONTEXT: 2-3 sentence summary of the module this class belongs to
    3. CLASS ROLE: From Phase 1 CLASS_MAP (the one-line purpose)
    
    INCLUDE IF CLASS ACCESSES DATA:
    4. TABLE SCHEMAS: For each Oracle table this class accesses:
       - Column names, types, nullable
       - Primary key
       - Foreign keys
       - Classification (LOOKUP/CONFIG/TRANSACTIONAL)
       
    5. LIVE DATA VALUES: For each LOOKUP/CONFIG table this class accesses:
       - ALL distinct values for decision columns
       - Frequency distributions
       Example: "ROUTING_CONFIG.ROUTING_TYPE has values: RTGS (25), NETTING (15), BATCH (7)"
       
    6. GEMFIRE DATA: For each region this class accesses:
       - Region type, entry count
       - Sample entries (key-value pairs)
       - For REPLICATE regions: all keys if < 100
       - Source Oracle table mapping
    
    INCLUDE IF CLASS CALLS OTHER CLASSES:
    7. CALLERS: Which classes/methods call this class (from call_graph reverse edges)
       Include their brief description from Phase 1
    8. CALLEES: Which classes/methods this class calls (from call_graph forward edges)
       Include their brief description from Phase 1
    
    INCLUDE IF CLASS IS A LISTENER/CONSUMER:
    9. MESSAGE SCHEMA: For Kafka/MQ consumers, include the message structure
       (from the producer class's DTO or schema file)
    
    TOKEN MANAGEMENT:
    - Source code is MANDATORY (never truncate)
    - Data context is HIGH priority (truncate value lists before removing tables)
    - Call graph context is MEDIUM priority
    - Module context is LOW priority (can be summarized to 1 sentence)
    
    LIVE DATA REFRESH:
    - If oracle_conn is available and the class accesses LOOKUP/CONFIG tables:
      Re-query for the latest distinct values (they may have changed since Phase 0)
    - Store any newly discovered values in the context
    """
```

### process_large_class() function specification:

```python
def process_large_class(class_name, source, context, llm):
    """
    Handle classes too large for a single LLM call.
    
    Strategy:
    1. Split methods into groups of 3-5 methods each
    2. For each group:
       a. Include: full class declaration + fields + the method group source
       b. Include: data context ONLY for data accessed by these methods
       c. Call LLM
    3. Combine all group results into one logic doc
    4. Call LLM one more time with the combined doc to:
       a. Ensure consistency between method groups
       b. Add cross-method relationships
       c. Ensure nothing was lost in the chunking
    
    Returns: Complete logic doc string.
    """
```

---

## PROMPT TEMPLATE: class_logic_with_data.prompt.md

```markdown
# Class Logic Extraction Task

You are documenting the complete logic of a Java class in a payment processing system.
Your documentation must capture EVERY method, EVERY branch, EVERY data access point.
This documentation will be used by AI agents for impact analysis and code changes.

## Module: {module_name}
Module Purpose: {module_purpose}

## Class: {class_name}
Role: {class_role}

## Called By (who calls this class):
{callers}

## This Class Calls:
{callees}

## SOURCE CODE:
```java
{source_code}
```

## DATA CONTEXT — Tables This Class Accesses:

{for each table accessed:}
### Table: {table_name} (Classification: {classification})
Schema:
| Column | Type | Nullable | Purpose |
|--------|------|----------|---------|
{schema_rows}

{if LOOKUP or CONFIG:}
**LIVE DATA — Distinct Values:**
{for each decision column:}
- {column_name}: {value1} ({freq1}x), {value2} ({freq2}x), ...
{end for}
{end if}
{end for}

## DATA CONTEXT — GemFire Regions This Class Accesses:

{for each region:}
### Region: {region_name} (Type: {region_type}, Entries: {entry_count})
Source Table: {source_table}
Value Fields: {value_fields}
{if REPLICATE with full dump:}
**All Keys:** {all_keys}
{end if}
Sample Entry:
```json
{sample_entry}
```
{end for}

---

## YOUR TASK — Document EVERY method in this class:

For EACH method, produce:

### method_name(parameters)

**PURPOSE**: What does this method do? (2-3 sentences, specific)

**INPUTS**:
- Parameter: {name} ({type}) — what it represents
- Injected dependency reads: list any fields/DAOs/caches accessed

**LOGIC — Step by Step**:
1. [Line N] First thing that happens
2. [Line N] Second thing...
   - IF {condition}: [what happens] → goes to step X
   - ELSE IF {condition}: [what happens] → goes to step Y
   - ELSE: [what happens]
3. [Line N] Data access: reads {table_name}.{column} via {DAO.method()}
   - **Data-Driven Branch**: Based on value of {column}:
     * "{value1}" → {what code path activates, which method is called, what downstream effect}
     * "{value2}" → {what code path activates}
     * "{value3}" → {what code path activates}
     * (unknown/new value) → {what happens — default case, exception, etc.}
4. [Line N] ...continue for every line of logic...

**OUTPUTS**:
- Returns: {what is returned and when}
- Side effects: {DB writes, cache updates, message publishes, logs}

**ERROR HANDLING**:
- {ExceptionType}: caught at line N, handled by {what happens}
- Null safety: {which inputs can be null, what happens if they are}
- What happens if the DB call fails? If the cache is unavailable?

**BUSINESS RULES EMBEDDED**:
- Rule 1: {natural language description of the business rule}
- Rule 2: ...

---

CRITICAL REQUIREMENTS:
1. Document EVERY method. Do not skip private methods, constructors, or simple getters/setters.
   For simple getters/setters, a one-line entry is sufficient: "Returns the value of {field}."
2. Include LINE NUMBERS in your logic steps so they can be verified against source.
3. For EVERY data access (DB read, cache read, config lookup):
   - Name the exact table/region/config
   - List the actual values from the DATA CONTEXT above
   - Show which code path each value triggers
4. For EVERY branch (if/else, switch, try/catch):
   - Document BOTH/ALL paths
   - What triggers each path
5. For EVERY null check or absence thereof:
   - Note whether the code handles null
   - If not, note the risk: "⚠ No null check — NPE if {source} returns null"
6. Count your documented methods at the end. It MUST match the number of methods in the source.
   Format: "Total methods documented: X / X"
```

---

## PROMPT TEMPLATE: class_logic_repair.prompt.md

```markdown
# Logic Documentation Repair Task

The existing documentation for this class has gaps that need to be fixed.
Fix ONLY the listed gaps. Do NOT remove or change correct existing content.
Merge your fixes into the existing document.

## SOURCE CODE:
```java
{source_code}
```

## EXISTING DOCUMENTATION:
{existing_doc}

## GAPS TO FIX:
{for each gap:}
- {gap_description}
{end for}

## FRESH DATA (re-queried from live database):
{fresh_data}

---

## YOUR TASK:

For each gap listed above, produce the CORRECTED section.
Format each fix as:

### FIX FOR: {gap description}
{corrected content}

Do not reproduce the entire document. Only produce the fixes.
Include line numbers from the source code.
If a gap is about missing data values, map the new values to code paths using the FRESH DATA above.
```

---

## SCRIPT 2: validate_phase_2.py

```
PURPOSE: Validate Phase 2 — the most rigorous validation in the entire pipeline.
         Connects to Oracle + GemFire to verify data accuracy.

FUNCTION:

def validate(config, phase_0_output, phase_2_output, oracle_conn, gemfire_conn) -> List[Dict]:
    """
    THE 10 CHECKS:
    
    CHECK 1: Every non-trivial class has a logic doc
    - Load class_index.json → count non-trivial classes
      (exclude: simple POJOs < 5 methods, test classes, generated classes)
    - Check phase-2/output/modules/{module}/classes/{class}.logic.md exists
    - Missing → gap type: "class_not_documented"
    
    CHECK 2: Every method in source is documented
    - For each documented class:
      a. Read source file
      b. Extract method names using utils.extract_methods()
      c. Parse logic doc for documented method names
      d. Method in source but not in doc → gap type: "method_not_documented"
    - IMPORTANT: Match by method name. If overloaded, match by name + param count.
    
    CHECK 3: Branch count verification
    - For each documented class:
      a. For each method in source:
         - Count branches using utils.count_branches(source, method_name)
         - Count branches documented in logic doc (count lines with IF/ELSE/SWITCH/CATCH keywords)
         - If doc_branches < source_branches * 0.8 → gap type: "missing_branches"
    
    CHECK 4: Data access linkage
    - For each documented class:
      a. Extract all DAO/cache calls from source (using utils.extract_method_calls())
      b. Check each call appears in the logic doc
      c. Call in source but not linked in doc → gap type: "data_call_not_linked"
    
    CHECK 5: Live data accuracy (CONNECTS TO ORACLE)
    - For each LOOKUP/CONFIG table referenced in logic docs:
      a. Re-query Oracle for current distinct values
      b. Compare with values mentioned in logic doc
      c. Value in doc but not in live DB → gap type: "stale_data_value", severity: "warning"
      d. Value in live DB but not in doc → gap type: "missing_data_value", severity: "critical"
         (This means a code path for this value is not documented)
    
    CHECK 6: GemFire data accuracy (CONNECTS TO GEMFIRE)
    - Same as CHECK 5 but for GemFire regions
    - For REPLICATE regions: check all keys are covered
    - gap type: "missing_region_value"
    
    CHECK 7: Null path documentation
    - For each class that accesses data:
      a. Find all calls that can return null (DAO.findBy..., cache.get(), Optional usage)
      b. Check if logic doc mentions null handling for each
      c. No null coverage → gap type: "null_path_undocumented", severity: "warning"
    
    CHECK 8: Cross-class call consistency
    - For each logic doc that mentions calling another class's method:
      a. Verify the target class has a logic doc
      b. Verify the target method is documented in the target's logic doc
      c. Verify parameter/return types match
      d. Mismatch → gap type: "cross_class_inconsistency"
    
    CHECK 9: Line coverage estimate
    - For each class:
      a. Count logic lines in source (exclude blanks, imports, closing braces, comments)
      b. Count detail lines in logic doc (exclude headers, blank lines)
      c. If ratio < 0.3 (doc is very thin relative to source) → gap type: "thin_documentation"
         severity: "warning"
    
    CHECK 10: Method count match
    - For each documented class:
      a. Parse "Total methods documented: X / Y" line if present
      b. Verify X == Y
      c. If X < Y → gap type: "method_count_mismatch"
    
    Returns: List of gaps, sorted by severity (critical → warning → info).
    """
```

---

## END OF FILE 04 SPECIFICATION

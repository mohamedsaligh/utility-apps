# FILE 09 — WEEKLY INCREMENTAL UPDATE
# Detects code changes, re-profiles changed data, updates affected KB sections.
# Designed to run weekly on a schedule. Connects to Oracle + GemFire.

---

## INSTRUCTION TO AGENT

Generate Python scripts for the weekly update. Place in `{PROJECT_ROOT}/.knowledge-base/weekly/`.

This script keeps the knowledge base fresh without full re-extraction. It detects what
changed (code + data) and surgically updates only the affected KB sections.

---

## SCRIPT 1: run_weekly_update.py

```
PURPOSE: Incrementally update the knowledge base based on recent changes.

ALGORITHM:

1. Load config
2. Connect to Oracle + GemFire
3. Initialize LLM
4. Create update log: weekly/output/update_logs/{date}.json

5. STEP 1: DETECT CODE CHANGES
   ─────────────────────────────
   changed_files = git_changed_files(config.project.root, since_days=7)
   
   Categorize:
   new_java_files = [f for f in changed_files if f.endswith('.java') and is_new(f)]
   modified_java_files = [f for f in changed_files if f.endswith('.java') and is_modified(f)]
   deleted_java_files = [f for f in changed_files if f.endswith('.java') and is_deleted(f)]
   changed_configs = [f for f in changed_files if is_config_file(f)]
   changed_poms = [f for f in changed_files if f.endswith('pom.xml')]
   changed_sql = [f for f in changed_files if is_sql_or_liquibase(f)]
   
   Log: "Code changes: {len(new_java_files)} new, {len(modified_java_files)} modified, 
         {len(deleted_java_files)} deleted, {len(changed_configs)} config changes"

6. STEP 2: RE-PARSE CHANGED FILES (Phase 0 update)
   ─────────────────────────────────────────────────
   For each new_java_file:
     parsed = parse_single_file(file_path)
     update_class_index(parsed)
     update_method_signatures(parsed)
     update_annotation_scan(parsed)
     update_access_map(parsed)
     update_call_graph(parsed)
   
   For each modified_java_file:
     old_parsed = class_index[get_class_name(file)]
     new_parsed = parse_single_file(file_path)
     
     # Detect what changed:
     added_methods = new_methods - old_methods
     removed_methods = old_methods - new_methods
     modified_methods = methods_with_different_signatures_or_annotations
     
     update_class_index(new_parsed)
     update_method_signatures(new_parsed)
     update_annotation_scan(new_parsed)
     update_access_map(new_parsed)
     update_call_graph(new_parsed)
   
   For each deleted_java_file:
     mark_as_deleted_in_class_index(file)
     remove_from_call_graph(file)
     # Don't delete logic doc — mark as "SOURCE DELETED" for manual review
   
   For each changed_config:
     rescan_config(file_path)
     # Check for new topics, queues, table references
   
   For each changed_pom:
     reparse_pom(pom_path)
     update_module_graph()
   
   For each changed_sql (Liquibase/Flyway):
     # New migration means DB schema may have changed
     flag_table_for_reprofile(extract_tables_from_migration(file_path))

7. STEP 3: RE-PROFILE CHANGED DATA SOURCES (Phase 0 update)
   ────────────────────────────────────────────────────────
   
   # Re-profile tables that have new code access patterns
   tables_to_reprofile = set()
   
   for file in new_java_files + modified_java_files:
       tables = get_tables_accessed_by(file, access_map)
       tables_to_reprofile.update(tables)
   
   # Re-profile tables flagged by SQL changes
   tables_to_reprofile.update(tables_from_sql_changes)
   
   # ALWAYS re-check ALL LOOKUP/CONFIG tables for new values
   for table, classification in table_classification.items():
       if classification['classification'] in ('LOOKUP', 'CONFIG'):
           tables_to_reprofile.add(table)
   
   oracle_conn = OracleConnection(config.oracle)
   for table in tables_to_reprofile:
       old_profile = oracle_profiles.get(table, {})
       new_profile = profile_single_table(oracle_conn, table, config)
       
       # Detect changes:
       schema_changed = old_profile.get('schema') != new_profile.get('schema')
       row_count_changed = old_profile.get('row_count') != new_profile.get('row_count')
       
       if table in lookup_config_tables:
           old_values = old_profile.get('distinct_values', {})
           new_values = new_profile.get('distinct_values', {})
           values_changed = old_values != new_values
           
           if values_changed:
               # Log exactly what changed
               for col in set(list(old_values.keys()) + list(new_values.keys())):
                   old_set = set(v['value'] for v in old_values.get(col, []))
                   new_set = set(v['value'] for v in new_values.get(col, []))
                   added = new_set - old_set
                   removed = old_set - new_set
                   if added: log(f"NEW values in {table}.{col}: {added}")
                   if removed: log(f"REMOVED values in {table}.{col}: {removed}")
       
       oracle_profiles[table] = new_profile
   
   # Same for GemFire regions
   gemfire_conn = GemfireConnection(config.gemfire)
   for region in affected_regions:
       new_profile = profile_single_region(gemfire_conn, region, config)
       gemfire_profiles[region] = new_profile

8. STEP 4: RE-EXTRACT LOGIC FOR CHANGED CLASSES (Phase 2 update)
   ─────────────────────────────────────────────────────────────
   
   classes_to_reextract = set()
   
   # New files → need full extraction
   for file in new_java_files:
       classes_to_reextract.add(get_class_name(file))
   
   # Modified files → need re-extraction
   for file in modified_java_files:
       classes_to_reextract.add(get_class_name(file))
   
   # Classes affected by data changes → need re-extraction
   # (their data context has changed, so value→code mappings may differ)
   for table in tables_with_new_values:
       for access in access_map.get('table_access', {}).get(table, []):
           classes_to_reextract.add(access['class'])
   
   for class_name in classes_to_reextract:
       # Same process as Phase 2: build context, call LLM, write doc
       context = build_class_context(class_name, ...)
       prompt = render_prompt('phase-2/prompts/class_logic_with_data.prompt.md', context)
       result = llm.call(prompt)
       write_kb(f'phase-2/output/modules/{module}/classes/{class_name}.logic.md', result)

9. STEP 5: UPDATE EDGES (Phase 3 update)
   ──────────────────────────────────────
   
   # For tables with new/changed values:
   for table in tables_with_value_changes:
       for decision_col in get_decision_columns(table):
           # Re-run value→code mapping
           live_values = oracle_conn.get_distinct_values(table, decision_col)
           accessing_methods = find_methods_accessing_column(table, decision_col, access_map)
           
           prompt = render_prompt('phase-3/prompts/data_code_linkage.prompt.md', {
               'table': table,
               'column': decision_col,
               'distinct_values': live_values,
               'accessing_code': [...]
           })
           result = llm.call(prompt)
           
           # Update edges
           update_edge_file('data_drives_branch.json', table, decision_col, parse_edges(result))
   
   # Remove edges for deleted classes
   for deleted_class in deleted_classes:
       remove_edges_for_class(deleted_class)
   
   # Add edges for new classes
   for new_class in new_classes_with_data_access:
       add_edges_for_class(new_class)

10. STEP 6: UPDATE FLOWS (Phase 4 update)
    ──────────────────────────────────────
    
    # Identify flows affected by changes:
    affected_flows = set()
    
    for class_name in classes_to_reextract:
        # Find all flows that pass through this class
        for flow_doc in all_flow_docs:
            if class_referenced_in_flow(class_name, flow_doc):
                affected_flows.add(flow_doc)
    
    for flow in affected_flows:
        # Re-trace the flow with updated logic docs
        retrace_flow(flow, updated_logic_docs, updated_edges)

11. STEP 7: QUICK VALIDATION
    ─────────────────────────
    
    # Run a subset of Phase 5 checks on changed items only:
    for class_name in classes_to_reextract:
        verify_method_coverage(class_name)
        verify_data_linkage(class_name)
    
    for table in tables_with_value_changes:
        verify_edge_completeness(table)

12. STEP 8: UPDATE MANIFEST
    ───────────────────────
    
    update_log = {
        'date': today,
        'code_changes': {
            'new_files': len(new_java_files),
            'modified_files': len(modified_java_files),
            'deleted_files': len(deleted_java_files),
            'config_changes': len(changed_configs)
        },
        'data_changes': {
            'tables_reprofiled': len(tables_to_reprofile),
            'tables_with_new_values': list(tables_with_new_values),
            'regions_reprofiled': len(affected_regions)
        },
        'kb_updates': {
            'classes_reextracted': len(classes_to_reextract),
            'edges_updated': edge_update_count,
            'flows_retraced': len(affected_flows)
        },
        'validation': {
            'issues_found': len(validation_issues),
            'issues_resolved': len(resolved_issues)
        },
        'duration_seconds': elapsed
    }
    
    safe_json_dump(update_log, f'weekly/output/update_logs/{today}.json')
    
    # Update the master MANIFEST.md with new timestamps
    update_master_manifest(update_log)

13. Close connections. Log completion.

CLI:
    python run_weekly_update.py --config ../config.yml [--since-days N] [--dry-run] [--force-full-data-check]
    
    --since-days N: Override the default 7-day lookback
    --dry-run: Show what would be updated without making changes
    --force-full-data-check: Re-query ALL tables, not just LOOKUP/CONFIG
```

---

## CRON SETUP

```bash
# Run every Sunday at 1:00 AM
0 1 * * 0 cd /path/to/project/.knowledge-base && python weekly/run_weekly_update.py --config config.yml >> .logs/weekly-cron.log 2>&1
```

---

## END OF FILE 09 SPECIFICATION

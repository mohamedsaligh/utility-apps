$(function(){
	var w=$(window).width();
	var h=$(window).height();

	$(window).resize(function(){
		w=$(window).width();
		h=$(window).height();
	});

 	//fancybox
	if($(".fancybox").length){
		 $('.fancybox').fancybox();
	}
	var videoW = w<600?w*0.8:w*0.7;
	var videoH = h<550?h*0.85:h*0.75;
	if($(".fancyVideo").length){
		 $(".fancyVideo").fancybox({
			'width': videoW,
			'height': videoH,
			'autoScale': true,
			'transitionIn': 'none',
			'transitionOut': 'none',
			'type': 'iframe'
		});
	}

	$(window.document).find("textarea").each(function () {
	        bind($(this));
	        if($(this).val()!= ""){$(this).addClass("focusOn");}
	    });
	    $(window.document).find("input").each(function () {
	        bind($(this));
	        if($(this).val()!= ""){$(this).addClass("focusOn");}
	    });
		function bind(e) {
			var tempstr;
			e.bind({
				'focus': function () {
	                e.addClass("focusOn");
				},
				'blur': function () {
					if (e.val() == "") {
						e.removeClass("focusOn");
					}
					else if(e.val() != ""){
						e.addClass("focusOn");
						return;
					}
				}
			});
		}

	//表格响应
	var ieV=$.browser.msie&&$.browser.version;
	if(ieV<9){$("#container").css("min-width","1100px"); ieV=false;}
	else{ ieV=true;}

	if($(".footable").length && ieV){
		$(".footable").footable({
			breakpoints: {
				phone: 480,
				tablet: 600
			}
		});
	}
	//表格响应结束
 
	$(".footerBarPro").click(function(){
	$(".toolMask").addClass("moveLeft");
		$("body").addClass("clear");
	});
	
	$("#toolCloseBtn").click(function(){
			$(".toolMask").removeClass("moveLeft");
			$("body").removeClass("clear");
	});
	

	$(window).scroll(function(){
			if ($(window).scrollTop()>200){
				$("#goTop").fadeIn();
			}
		else{
			$("#goTop").fadeOut();
		}
	});
	
    //当点击跳转链接后，回到页面顶部位置
	$("#goTop").click(function(){
		$('body,html').animate({scrollTop:0},400);
		return false;
	});

	 $(".listStyle li").each(function(){
		var l=$(this).find("li").length;
		if(l){
			$(this).addClass("hasUl");
			$(this).find(">a").click(function(e){ 
				e.preventDefault();
				$(this).parent("li").toggleClass("selected").siblings(".listStyle>li").removeClass("selected").find("ul").slideUp();
				$(this).next("ul").slideToggle();
			});
		}
		else { $(this).find("ul").hide(); }
	});
       
  	$(".aside>li>a").click(function(e){
		if($(this).next("ul").length && w<880){
			e.preventDefault();
			$(this).next("ul").slideToggle().parent("li").siblings().find("ul").slideUp();
		}
		if($(this).next("ul").length && isMobile.any){
			e.preventDefault();	
		}	
	});

 	$('#menu').click(function(){
 		$(this).toggleClass('shat');
 		$('#nav').slideToggle();
 	});

});

(function(i){var e=/iPhone/i,n=/iPod/i,o=/iPad/i,t=/(?=.*\bAndroid\b)(?=.*\bMobile\b)/i,r=/Android/i,d=/BlackBerry/i,s=/Opera Mini/i,a=/IEMobile/i,b=/(?=.*\bFirefox\b)(?=.*\bMobile\b)/i,h=RegExp("(?:Nexus 7|BNTV250|Kindle Fire|Silk|GT-P1000)","i"),c=function(i,e){return i.test(e)},l=function(i){var l=i||navigator.userAgent;this.apple={phone:c(e,l),ipod:c(n,l),tablet:c(o,l),device:c(e,l)||c(n,l)||c(o,l)},this.android={phone:c(t,l),tablet:!c(t,l)&&c(r,l),device:c(t,l)||c(r,l)},this.other={blackberry:c(d,l),opera:c(s,l),windows:c(a,l),firefox:c(b,l),device:c(d,l)||c(s,l)||c(a,l)||c(b,l)},this.seven_inch=c(h,l),this.any=this.apple.device||this.android.device||this.other.device||this.seven_inch},v=i.isMobile=new l;v.Class=l})(window);
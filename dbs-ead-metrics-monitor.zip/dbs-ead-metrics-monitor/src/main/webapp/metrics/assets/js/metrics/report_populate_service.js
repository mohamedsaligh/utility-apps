$(function() {

		// default update interval
		var updateInterval = 30000;
		// a custom formatter for displaying the latency axis
		function msFormatter(times) {
			return function(v, axis) {
				return (v * times).toFixed(0) + "MS";
			}
		}
		// hook up text box changes
		$('#connectUrl3').on('change', function() {
			var hosts = $("#connectUrl3").val().split(",");
			json2flot3.setMetricURLs(hosts);
		});
		$('#connectUrl4').on('change', function() {
			var hosts = $("#connectUrl4").val().split(",");
			json2flot4.setMetricURLs(hosts);
		});
		$("#updateInterval2").val(updateInterval).change(function() {
			var v = $(this).val();
			json2flot3.setUpdateInterval(v);
			$(this).val("" + json2flot3.getUpdateInterval());
			
			json2flot4.setUpdateInterval(v);
			$(this).val("" + json2flot4.getUpdateInterval());
		});
		// flot options object to set up the axes
		var options = {
			lines : {
				show : true
			},
			points : {
				show : false
			},
			xaxes : [ {
				mode : "time",
				timeformat : "%H:%M:%S",
				minTickSize : [ 1, "second" ]
			} ],
			yaxes : [ {
				min : 0,
				position : "left"
			}, {
				min : 0,
				position : "right",
				tickFormatter : msFormatter(1000)
			} ],
			legend : {
				position : "sw",
				hideable : true
			},
			grid : {
				hoverable : true
			}
		};
		// a tooltip function for the graph
		function tooltipFunc(times) {
			return function(event, pos, item) {
				if (item) {
					var axis = item.series.yaxis.n;
					if (axis == 2) {
						var y = (item.datapoint[1] * times).toFixed(2);
						$("#tooltip").html(item.series.label + ": " + y + " MS").css({
							top : item.pageY + 5,
							left : item.pageX + 5
						}).fadeIn(200);
					} else {
						var y = (item.datapoint[1]).toFixed(2);
						$("#tooltip").html(item.series.label + ": " + y).css({
							top : item.pageY + 5,
							left : item.pageX + 5
						}).fadeIn(200);
					}
				} else {
					$("#tooltip").hide();
				}
			}
		}
		// the tooltip style
		$("<div id='tooltip'></div>").css({
			position : "absolute",
			display : "none",
			border : "1px solid #fdd",
			padding : "2px",
			"background-color" : "#fee",
			opacity : 0.80
		}).appendTo("body");
		// hook up the tooltips
		$("#server1ServiceCount").bind("plothover", tooltipFunc(1000));
		$("#server2ServiceCount").bind("plothover", tooltipFunc(1000));
		

		
		// initialize json2flot with the urls
		var hosts1 = $("#connectUrl3").val().split(",");
		json2flot3.setMetricURLs(hosts1);
		
		var hosts2 = $("#connectUrl4").val().split(",");
		json2flot4.setMetricURLs(hosts2);
		
		// initialize json2flot with the update interval 
		var v = $("#updateInterval2").val();
		json2flot3.setUpdateInterval(v);
		json2flot4.setUpdateInterval(v);
		// the total number of points to keep in the graph
		var totalPoints = 500;

		drawTable("#server1TbServiceCount");
		drawTable("#server2TbServiceCount");
		
		addSGraph1("#server1ServiceCount", "server1Timers");
		addSGraph2("#server2ServiceCount", "server1Timers");
		
		addBatchTable1("#server1TbBatchServiceCount","batch1Timers");
		addBatchTable2("#server2TbBatchServiceCount","batch1Timers");
		/**
		 * init table and draw
		 * 
		 * */
		function drawTable(id){
			var div = $(id);
			
			var table = $('<table id="status-table" border=1></table>');
			table.width("700").find("tr").width(100).find("tr").width(100);
			var tbody = $('<tbody></tbody>');
			
			//Init TH
			var tr = $('<tr></tr>');
			var th_tr = $('<th>Service Name</th>');
			tr.append(th_tr);
			
			th_tr = $('<th>Last update time</th>');
			tr.append(th_tr);
			
			th_tr = $('<th>Count</th>');
			tr.append(th_tr);
			
			tbody.append(tr);
			table.append(tbody);
			div.empty();
			div.append(table);
		}
		
		function addSGraph1(id, metricsName){
			// initialize the first graph
			json2flot3.addGraph(id, options, [ {
				path : [metricsName],
				metric : "count",
					label:"count"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				//keyRegex : /com.dbs.digital.mobility.good.notification.NotificationController.(.*)+/,
				keyRegex : /com.(.*)+/,
				// the metric field
				metric : "count",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 count",
				
				operation : "sum",
				
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : true
			}], totalPoints );
		}
		function addSGraph2(id, metricsName){
			// initialize the first graph
			json2flot4.addGraph(id, options, [ {
				path : [metricsName],
				metric : "count",
					label:"count"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				//keyRegex : /com.dbs.digital.mobility.good.notification.NotificationController.(.*)+/,
				keyRegex : /com.(.*)+/,
				// the metric field
				metric : "count",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 count",
				
				operation : "sum",
				
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : true
			}], totalPoints );
		}
		
		
		function addBatchTable1(id, metricsName){
			// initialize the first graph
			json2flot3.addTable(id, options, [ {
				path : [metricsName],
				metric : "count",
					label:"count"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				//keyRegex : /com.dbs.digital.mobility.good.notification.NotificationController.(.*)+/,
				keyRegex : /com.(.*)+/,
				// the metric field
				metric : "count",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 count",
				
				operation : "sum",
				
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : true
			}], totalPoints );
		}
		
		function addBatchTable2(id, metricsName){
			// initialize the first graph
			json2flot4.addTable(id, options, [ {
				path : [metricsName],
				metric : "count",
					label:"count"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				//keyRegex : /com.dbs.digital.mobility.good.notification.NotificationController.(.*)+/,
				keyRegex : /com.(.*)+/,
				// the metric field
				metric : "count",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 count",
				
				operation : "sum",
				
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : true
			}], totalPoints );
		}
		
		json2flot3.setDataType("jsonp");
		json2flot4.setDataType("jsonp");
		//startUpdate();
		
		$('#startUpdate3').on('click', function() {
			startUpdate1();
		});
		$('#stopUpdate3').on('click', function() {
			stopUpdate1();
		});
		
		function startUpdate1() {
			var hosts = $("#connectUrl3").val().split(",");
			json2flot3.setMetricURLs(hosts);
			json2flot3.startUpdate();
			$('#startUpdate3')[0].style.color = "gray";
			$('#stopUpdate3')[0].style.color = null;
		}
		function stopUpdate1() {
			json2flot3.stopUpdate();
			$('#startUpdate3')[0].style.color = null;
			$('#stopUpdate3')[0].style.color = "gray";
		}
		
		$('#startUpdate4').on('click', function() {
			startUpdate2();
		});
		$('#stopUpdate4').on('click', function() {
			stopUpdate2();
		});
		
		function startUpdate2() {
			var hosts = $("#connectUrl4").val().split(",");
			json2flot4.setMetricURLs(hosts);
			json2flot4.startUpdate();
			$('#startUpdate4')[0].style.color = "gray";
			$('#stopUpdate4')[0].style.color = null;
		}
		function stopUpdate2() {
			json2flot4.stopUpdate();
			$('#startUpdate4')[0].style.color = null;
			$('#stopUpdate4')[0].style.color = "gray";
		}
	});
$(function() {
	
	
		// default update interval
		var updateInterval = 30000;
		// a custom formatter for displaying the latency axis
		function msFormatter(times) {
			return function(v, axis) {
				return (v * times).toFixed(0) + "MS";
			}
		}
		// hook up text box1 changes
		$('#connectUrl1').on('change', function() {
			var hosts = $("#connectUrl1").val().split(",");
			json2flot1.setMetricURLs(hosts);
		});
		// hook up text box2 changes
		$('#connectUrl2').on('change', function() {
			var hosts = $("#connectUrl2").val().split(",");
			json2flot2.setMetricURLs(hosts);
		});
		
		$("#updateInterval1").val(updateInterval).change(function() {
			var v = $(this).val();
			json2flot1.setUpdateInterval(v);
			$(this).val("" + json2flot1.getUpdateInterval());
			
			json2flot2.setUpdateInterval(v);
			$(this).val("" + json2flot2.getUpdateInterval());
		});
		// flot options object to set up the axes
		var options = {
			lines : {
				show : true
			},
			points : {
				show : false
			},
			xaxes : [ {
				mode : "time",
				timeformat : "%H:%M:%S",
				minTickSize : [ 1, "second" ]
			} ],
			yaxes : [ {
				min : 0,
				position : "left"
			}, {
				min : 0,
				position : "right",
				tickFormatter : msFormatter(1000)
			} ],
			legend : {
				position : "sw",
				hideable : true
			},
			grid : {
				hoverable : true
			}
		};
		
		// a tooltip function for the graph
		function tooltipFunc(times) {
			return function(event, pos, item) {
				if (item) {
					var axis = item.series.yaxis.n;
					if (axis == 2) {
						var y = (item.datapoint[1] * times).toFixed(2);
						$("#tooltip").html(item.series.label + ": " + y + " MS").css({
							top : item.pageY + 5,
							left : item.pageX + 5
						}).fadeIn(200);
					} else {
						var y = (item.datapoint[1]).toFixed(2);
						$("#tooltip").html(item.series.label + ": " + y).css({
							top : item.pageY + 5,
							left : item.pageX + 5
						}).fadeIn(200);
					}
				} else {
					$("#tooltip").hide();
				}
			}
		}
		// the tooltip style
		$("<div id='tooltip'></div>").css({
			position : "absolute",
			display : "none",
			border : "1px solid #fdd",
			padding : "2px",
			"background-color" : "#fee",
			opacity : 0.80
		}).appendTo("body");
		// hook up the tooltips

		$("#server1ThreadDeatils").bind("plothover", tooltipFunc(1000));
		$("#server2ThreadDeatils").bind("plothover", tooltipFunc(1000));
		$("#server1HeapDeatils").bind("plothover", tooltipFunc(1000));
		$("#server2HeapDeatils").bind("plothover", tooltipFunc(1000));
		
//		$("#server1TbProcessCount").bind("plothover", tooltipFunc(1000));
//		$("#server2TbProcessCount").bind("plothover", tooltipFunc(1000));
		// initialize json2flot with the urls
	
		
		var hosts1 = $("#connectUrl1").val().split(",");
		json2flot1.setMetricURLs(hosts1);
		// initialize json2flot with the update interval 
		
		var hosts2 = $("#connectUrl2").val().split(",");
		json2flot2.setMetricURLs(hosts2);
		// initialize json2flot with the update interval 
		
		
		var v = $("#updateInterval1").val();
		json2flot1.setUpdateInterval(v);
		json2flot2.setUpdateInterval(v);
		
		// the total number of points to keep in the graph
		var totalPoints = 500;
		


		addSThreadGraph1("#server1ThreadDeatils", "server1Gauges");
		addSHeapGraph1("#server1HeapDeatils", "server1Gauges");
		addSGraph1("#server1TbProcessCount", "server1BackgroundProcessTimers");
		addJbossSGraph1("#serverJboss1TbProcessCount", "server1JbossProcessTimers");
		
		addSThreadGraph2("#server2ThreadDeatils", "server1Gauges");
		addSHeapGraph2("#server2HeapDeatils", "server1Gauges");
		addSGraph2("#server2TbProcessCount", "server1BackgroundProcessTimers");
		addJbossSGraph2("#serverJboss2TbProcessCount", "server1JbossProcessTimers");
		
		function addJbossSGraph1(id, metricsName){
			// initialize the first graph
			json2flot1.addTable(id, options, [ {
				path : [metricsName],
				metric : "count",
					label:"count"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				//keyRegex : /com.dbs.digital.mobility.good.notification.NotificationController.(.*)+/,
				keyRegex : /jboss.(.*)+/,
				// the metric field
				metric : "count",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 count",
				
				operation : "sum",
				
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : false
			}], totalPoints );
		}
		
		function addJbossSGraph2(id, metricsName){
			// initialize the first graph
			json2flot2.addTable(id, options, [ {
				path : [metricsName],
				metric : "count",
					label:"count"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				//keyRegex : /com.dbs.digital.mobility.good.notification.NotificationController.(.*)+/,
				keyRegex : /jboss.(.*)+/,
				// the metric field
				metric : "count",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 count",
				
				operation : "sum",
				
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : false
			}], totalPoints );
		}

		function addSGraph1(id, metricsName){
			// initialize the first graph
			json2flot1.addTable(id, options, [ {
				path : [metricsName],
				metric : "count",
					label:"count"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				//keyRegex : /com.dbs.digital.mobility.good.notification.NotificationController.(.*)+/,
				keyRegex : /process.(.*)+/,
				// the metric field
				metric : "count",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 count",
				
				operation : "sum",
				
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : false
			}], totalPoints );
		}
		
		function addSGraph2(id, metricsName){
			// initialize the first graph
			json2flot2.addTable(id, options, [ {
				path : [metricsName],
				metric : "count",
					label:"count"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				//keyRegex : /com.dbs.digital.mobility.good.notification.NotificationController.(.*)+/,
				keyRegex : /process.(.*)+/,
				// the metric field
				metric : "count",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 count",
				
				operation : "sum",
				
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : false
			}], totalPoints );
		}
		
		function addInstrumentedFilterGraph(id){
			// initialize the first graph
			json2flot.addGraph(id, options, [ {
				path : ["meters"],
				metric : "count",
					label:"count"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : ["meters"],
				// the regex to match child nodes with
				keyRegex : /com.codahale.metrics.servlet.InstrumentedFilter.responseCodes.(.*)+/,
				// the metric field
				metric : "m15_rate",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 m15",
				
				operation : "sum",
				
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : true
			}], totalPoints );
		}

		
		function addSThreadGraph1(id, metricsName){
			// initialize the first graph
			json2flot1.addGraph(id, options, [ {
				path : [metricsName],
				metric : "value",
				label:"value"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				keyRegex : /threads.(.*)+/,
				// the metric field
				metric : "value",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 value",
				
				operation : "sum",
				// show only the top 5 (according to the last metric value)
				showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : true
			}], totalPoints );
		}
		
		function addSThreadGraph2(id, metricsName){
			// initialize the first graph
			json2flot2.addGraph(id, options, [ {
				path : [metricsName],
				metric : "value",
				label:"value"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				keyRegex : /threads.(.*)+/,
				// the metric field
				metric : "value",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 value",
				
				operation : "sum",
				// show only the top 5 (according to the last metric value)
				showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : true
			}], totalPoints );
		}
		
		function addSHeapGraph1(id, metricsName){
			// initialize the first graph
			json2flot1.addGraph(id, options, [ {
				path : [metricsName],
				metric : "value",
				label:"value"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				keyRegex : /memory.heap.(.*)+/,
				// the metric field
				metric : "value",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 value",
				
				operation : "sum",
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : true
			}], totalPoints );
		}
		
		function addSHeapGraph2(id, metricsName){
			// initialize the first graph
			json2flot2.addGraph(id, options, [ {
				path : [metricsName],
				metric : "value",
				label:"value"
			},{
				// gets a metric from multiple nodes where the key matches the given regex
				// the root node path
				path : [metricsName],
				// the regex to match child nodes with
				keyRegex : /memory.heap.(.*)+/,
				// the metric field
				metric : "value",
				// the label in the graph. you can use a match group from the key regex
				label : "$1 value",
				
				operation : "sum",
				// show only the top 5 (according to the last metric value)
				//showTop : 5,
				// ignore metrics with zero value
				ignoreZeros : true
			}], totalPoints );
		}
		
		json2flot1.setDataType("jsonp");
		json2flot2.setDataType("jsonp");
		//startUpdate();
		//button 1
		$('#startUpdate1').on('click', function() {
			startUpdate1();
		});
		$('#stopUpdate1').on('click', function() {
			stopUpdate1();
		});
		
		function startUpdate1() {
			var hosts = $("#connectUrl1").val().split(",");
			json2flot1.setMetricURLs(hosts);
			json2flot1.startUpdate();
			$('#startUpdate1')[0].style.color = "gray";
			$('#stopUpdate1')[0].style.color = null;
		}
		function stopUpdate1() {
			json2flot1.stopUpdate();
			$('#startUpdate1')[0].style.color = null;
			$('#stopUpdate1')[0].style.color = "gray";
		}
		
		//button 2
		$('#startUpdate2').on('click', function() {
			startUpdate2();
		});
		$('#stopUpdate2').on('click', function() {
			stopUpdate2();
		});
		
		function startUpdate2() {
			var hosts = $("#connectUrl2").val().split(",");
			json2flot2.setMetricURLs(hosts);
			json2flot2.startUpdate();
			$('#startUpdate2')[0].style.color = "gray";
			$('#stopUpdate2')[0].style.color = null;
		}
		function stopUpdate2() {
			json2flot2.stopUpdate();
			$('#startUpdate2')[0].style.color = null;
			$('#stopUpdate2')[0].style.color = "gray";
		}
	});
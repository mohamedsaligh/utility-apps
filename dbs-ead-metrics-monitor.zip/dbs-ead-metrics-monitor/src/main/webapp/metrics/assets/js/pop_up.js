// JavaScript Document
function showWindow1(){
	document.getElementById('light1').style.display='block';
	document.getElementById('light1').style.left=($(window).width()-600)/2 + "px";
	document.getElementById('light1').style.top=($(window).height()-500)/2 + "px";
	document.getElementById('fade').style.height=document.body.scrollHeight +"px";
	document.getElementById('fade').style.display='block';
}
function closeWindow1(){
	document.getElementById('light1').style.display='none';
	document.getElementById('fade').style.display='none';
}

function showWindow2(){
	document.getElementById('light2').style.display='block';
	document.getElementById('light2').style.left=($(window).width()-800)/2 + "px";
	document.getElementById('light2').style.top=($(window).height()-400)/2 + "px";
	document.getElementById('fade').style.height=document.body.scrollHeight +"px";
	document.getElementById('fade').style.display='block';
}
function closeWindow2(){
	document.getElementById('light2').style.display='none';
	document.getElementById('fade').style.display='none';
}

function showWindow3(){
	document.getElementById('light3').style.display='block';
	document.getElementById('light3').style.left=($(window).width()-800)/2 + "px";
	document.getElementById('light3').style.top=($(window).height()-400)/2 + "px";
	document.getElementById('fade').style.height=document.body.scrollHeight +"px";
	document.getElementById('fade').style.display='block';
}
function closeWindow3(){
	document.getElementById('light3').style.display='none';
	document.getElementById('fade').style.display='none';
}

function showWindow4(){
	document.getElementById('light4').style.display='block';
	document.getElementById('light4').style.left=($(window).width()-800)/2 + "px";
	document.getElementById('light4').style.top=($(window).height()-400)/2 + "px";
	document.getElementById('fade').style.height=document.body.scrollHeight +"px";
	document.getElementById('fade').style.display='block';
}
function closeWindow4(){
	document.getElementById('light4').style.display='none';
	document.getElementById('fade').style.display='none';
}
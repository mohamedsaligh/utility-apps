package com.dbs.eadv;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dbs.eadv.to.ChildPropertyTO;
import com.dbs.eadv.to.JsonResponseTO;
import com.dbs.eadv.to.ParentPropertyTO;
import com.dbs.eadv.util.Constants;
import com.dbs.eadv.util.MetricsUtils;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

/**
 * Created by mohamedj on 10/11/15.
 */
public class HelloServlet extends HttpServlet {

    public void doGet(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        PrintWriter out = null;

        List<Map<?, ?>> resultdata;
        List<ParentPropertyTO> parentJson = new ArrayList<ParentPropertyTO>();
        List<ChildPropertyTO> childTimers = new ArrayList<ChildPropertyTO>();
        List<ChildPropertyTO> childGauges = new ArrayList<ChildPropertyTO>();
        JsonResponseTO jsonResponseTO = new JsonResponseTO();

        try {
            List<File> files = getFiles(MetricsUtils.getProperty(Constants.METRICS_CURRENT_SERVER_APP_CSV_PATH));
            for (File file : files) {
                ChildPropertyTO child = new ChildPropertyTO();
                child.setProperty(file.getName().replaceAll(".csv$", ""));
                resultdata = readObjectsFromCsv(file);
                ObjectMapper mapper = new ObjectMapper();
                String result = mapper.writeValueAsString(resultdata.get(resultdata.size() - 1));
                child.setData(result);

                if (file.getName().contains("Timer")) {
                    childTimers.add(child);
                } else {
                    childGauges.add(child);
                }
            }

            ParentPropertyTO parentTimers = new ParentPropertyTO();
            parentTimers.setProperty("timers");
            parentTimers.setChildPropertyTOList(childTimers);

            ParentPropertyTO parentGauges = new ParentPropertyTO();
            parentGauges.setProperty("gauges");
            parentGauges.setChildPropertyTOList(childGauges);

            parentJson.add(parentGauges);
            parentJson.add(parentTimers);

            jsonResponseTO.setParentPropertyTOList(parentJson);

            //System.out.println(jsonResponseTO.toString());

            httpServletResponse.setContentType("application/json");
            out = httpServletResponse.getWriter();
            out.print(jsonResponseTO.toString());
            out.flush();
        } catch (IOException e) {
            System.out.print(e.getMessage());
        } finally {
            resultdata = null;
            jsonResponseTO = null;
            parentJson = null;
            childTimers = null;
            childGauges = null;
            try {
                out.close();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public static List<Map<?, ?>> readObjectsFromCsv(File file) throws IOException {
        CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
        CsvMapper csvMapper = new CsvMapper();
        MappingIterator<Map<?, ?>> mappingIterator = csvMapper.reader(Map.class).with(bootstrap).readValues(file);
        return mappingIterator.readAll();
    }

   /* public static void main(String args[]) {
        File folder = new File("D:\\logs\\eadv\\metrics\\");
        File[] fileList = folder.listFiles();

        for(File file: fileList) {
            System.out.println(file.getAbsolutePath());
            System.out.println("\t\t" + file.getName().replaceAll(".csv$", ""));
        }
    }*/

    public List<File> getFiles(String path) {
        File folder = new File(path);
        return Arrays.asList(folder.listFiles());
    }
}

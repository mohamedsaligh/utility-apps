package com.dbs.eadv.util;

public interface Constants {
	
	public static final String PROPERTY_FILE_NAME = "/dbs-eadv-metrics.properties";
	
	public static final String METRICS_CURRENT_SERVER_APP_CSV_PATH = "dbs.eadv.metrics.csv.app.path";
	
	public static final String METRICS_SERVER1_PROCESS_CSV_PATH = "dbs.eadv.metrics.csv.process.path";
	
	public static final String METRICS_SERVER1_SERVICE_CSV_PATH = "dbs.eadv.metrics.csv.service.path";
	
	public static final String METRICS_SERVER1_DATA_PATH = "dbs.eadv.metrics.csv.data.path";
	
	public static final String METRICS_SERVER1_BACKUP_PATH = "dbs.eadv.metrics.csv.backup.path";
	
	public static final String METRICS_SERVER1_PROCESS_URL = "dbs.eadv.metrics.process.url1";
	
	public static final String METRICS_SERVER2_PROCESS_URL = "dbs.eadv.metrics.process.url2";
	
	public static final String METRICS_SERVER3_PROCESS_URL = "dbs.eadv.metrics.process.url3";
	
	public static final String METRICS_SERVER4_PROCESS_URL = "dbs.eadv.metrics.process.url4";
	
	public static final String METRICS_SERVER1_SERVICE_URL = "dbs.eadv.metrics.service.url1";

	public static final String METRICS_SERVER2_SERVICE_URL = "dbs.eadv.metrics.service.url2";
	
	public static final String METRICS_SERVER3_SERVICE_URL = "dbs.eadv.metrics.service.url3";

	public static final String METRICS_SERVER4_SERVICE_URL = "dbs.eadv.metrics.service.url4";
	
	public static final String METRICS_SERVER1_DESCRIPTION = "dbs.eadv.metrics.desc.server1";

	public static final String METRICS_SERVER2_DESCRIPTION = "dbs.eadv.metrics.desc.server2";
	
	public static final String METRICS_SERVER3_DESCRIPTION = "dbs.eadv.metrics.desc.server3";

	public static final String METRICS_SERVER4_DESCRIPTION = "dbs.eadv.metrics.desc.server4";
	
	public static final String METRICS_BACKUP_TIME_HOUR = "dbs.eadv.metrics.backup.time.hour";
	
	public static final String METRICS_BACKUP_TIME_MINUTE = "dbs.eadv.metrics.backup.time.minute";
	
	public static final String METRICS_BACKUP_TIME_SECOND = "dbs.eadv.metrics.backup.time.second";
	
	public static final String SERVER1_NAME = "dbs.eadv.metrics.server1.name";
	
	public static final String SERVER2_NAME = "dbs.eadv.metrics.server2.name";
	
	public static final String SERVER3_NAME = "dbs.eadv.metrics.server3.name";
	
	public static final String SERVER4_NAME = "dbs.eadv.metrics.server4.name";
}

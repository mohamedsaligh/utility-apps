package com.dbs.eadv.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.dbs.eadv.to.ChildPropertyTO;
import com.dbs.eadv.to.JsonResponseTO;
import com.dbs.eadv.to.ParentPropertyTO;
import com.dbs.eadv.util.Constants;
import com.dbs.eadv.util.MetricsUtils;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

/**
 * Created by mohamedj on 10/11/15.
 */
public class ProcessServlet extends HttpServlet {
	
	private static final Logger logger = Logger.getLogger(ProcessServlet.class);

    public void doGet(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        PrintWriter out = null;
        List<File> files = null;

        List<ParentPropertyTO> parentJson = new ArrayList<ParentPropertyTO>();
        List<ChildPropertyTO> childBackgroundTimers = new ArrayList<ChildPropertyTO>();
        List<ChildPropertyTO> childJbossTimers = new ArrayList<ChildPropertyTO>();
        List<ChildPropertyTO> childGauges = new ArrayList<ChildPropertyTO>();
        JsonResponseTO jsonResponseTO = new JsonResponseTO();

        try {
        	//Get CSV files from Server1
        	//1 Background process data prepare on server1
            files = getFiles(MetricsUtils.getProperty(Constants.METRICS_SERVER1_PROCESS_CSV_PATH));
            getChilds(files, childJbossTimers,childBackgroundTimers, childGauges);
            
            ParentPropertyTO parentBackgroundTimersS1 = new ParentPropertyTO();
            parentBackgroundTimersS1.setProperty("server1BackgroundProcessTimers");
            parentBackgroundTimersS1.setChildPropertyTOList(childBackgroundTimers);
            
            files = null;
            
            //2 Joss process data prepare on server1
            files = getFiles(MetricsUtils.getProperty(Constants.METRICS_SERVER1_PROCESS_CSV_PATH));
            getChilds(files, childJbossTimers,childBackgroundTimers, childGauges);
            
            ParentPropertyTO parentJbossTimersS1 = new ParentPropertyTO();
            parentJbossTimersS1.setProperty("server1JbossProcessTimers");
            parentJbossTimersS1.setChildPropertyTOList(childJbossTimers);
            
            //3 APP info data prepare on server1
            files = getFiles(MetricsUtils.getProperty(Constants.METRICS_CURRENT_SERVER_APP_CSV_PATH));
            getChilds(files, childJbossTimers,childBackgroundTimers, childGauges);
            
            ParentPropertyTO parentGaugesS1 = new ParentPropertyTO();
            parentGaugesS1.setProperty("server1Gauges");
            parentGaugesS1.setChildPropertyTOList(childGauges);
            
            
            //====
//            childBackgroundTimers = new ArrayList<ChildPropertyTO>();
//            childJbossTimers = new ArrayList<ChildPropertyTO>();
//            childGauges = new ArrayList<ChildPropertyTO>();;
//            
//            
//            //Get CSV files from Server1
//            //4 Background process data prepare on server2
//            files = getFiles(MetricsUtils.getProperty(Constants.METRICS_SERVER2_PROCESS_CSV_PATH));
//            getChilds(files, childJbossTimers,childBackgroundTimers, childGauges);
//            
//            ParentPropertyTO parentBackgroundTimersS2 = new ParentPropertyTO();
//            parentBackgroundTimersS2.setProperty("server2BackgroundProcessTimers");
//            parentBackgroundTimersS2.setChildPropertyTOList(childBackgroundTimers);
//            
//            files = null;
//            
//            //5 Joss process data prepare on server2
//            files = getFiles(MetricsUtils.getProperty(Constants.METRICS_SERVER2_PROCESS_CSV_PATH));
//            getChilds(files, childJbossTimers,childBackgroundTimers, childGauges);
//         
//            ParentPropertyTO parentJbossTimersS2 = new ParentPropertyTO();
//            parentJbossTimersS2.setProperty("server2JbossProcessTimers");
//            parentJbossTimersS2.setChildPropertyTOList(childJbossTimers);
//            
//            
//            //6 APP info data prepare on server1
//            files = getFiles(MetricsUtils.getProperty(Constants.METRICS_SERVER2_APP_CSV_PATH));
//            getChilds(files, childJbossTimers,childBackgroundTimers, childGauges);
//            
//            ParentPropertyTO parentGaugesS2 = new ParentPropertyTO();
//            parentGaugesS2.setProperty("server2Gauges");
//            parentGaugesS2.setChildPropertyTOList(childGauges);

            parentJson.add(parentGaugesS1);
//            parentJson.add(parentGaugesS2);
            parentJson.add(parentJbossTimersS1);
//            parentJson.add(parentJbossTimersS2);
            parentJson.add(parentBackgroundTimersS1);
//            parentJson.add(parentBackgroundTimersS2);
            
            jsonResponseTO.setParentPropertyTOList(parentJson);

            //System.out.println(jsonResponseTO.toString());

            httpServletResponse.setContentType("application/json");
            out = httpServletResponse.getWriter();
            out.print(jsonResponseTO.toString());
            out.flush();
        } catch (IOException e) {
        	logger.error(e.getMessage(), e);
        } finally {
            jsonResponseTO = null;
            parentJson = null;
            childBackgroundTimers = null;
            childJbossTimers = null;
            childGauges = null;
            try {
            	if(out != null){
            		out.close();
            	}
            } catch (Exception e) {
            	logger.error(e.getMessage(), e);
            }
        }
    }

    public static List<Map<?, ?>> readObjectsFromCsv(File file) throws IOException {
        CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
        CsvMapper csvMapper = new CsvMapper();
        MappingIterator<Map<?, ?>> mappingIterator = csvMapper.reader(Map.class).with(bootstrap).readValues(file);
        return mappingIterator.readAll();
    }

    public List<File> getFiles(String path) {
        File folder = new File(path);
        return Arrays.asList(folder.listFiles());
    }
    
    public void getChilds(List<File> files, List<ChildPropertyTO> childJbossTimers,List<ChildPropertyTO> childBackgroundTimers, List<ChildPropertyTO> childGauges){
    	List<Map<?, ?>> resultdata;
    	try {
	    	for (File file : files) {
	            ChildPropertyTO child = new ChildPropertyTO();
	            child.setProperty(file.getName().replaceAll(".csv$", ""));
	            
				resultdata = readObjectsFromCsv(file);
				
	            ObjectMapper mapper = new ObjectMapper();
	            String result = mapper.writeValueAsString(resultdata.get(resultdata.size() - 1));
	            child.setData(result);
	
	            if (file.getName().contains("jboss")) {
	            	childJbossTimers.add(child);
	            }else if (file.getName().contains("process")) {
	            	childBackgroundTimers.add(child);
	            }else {
	                childGauges.add(child);
	            }
	        }
    	} catch (IOException e) {
    		logger.error(e.getMessage(), e);
		} finally{
			resultdata = null;
		}
    }
}

package com.dbs.eadv.batch;

import com.codahale.metrics.MetricSet;
import com.codahale.metrics.annotation.Timed;
import io.astefanutti.metrics.aspectj.Metrics;

/**
 * Created by mohamedj on 4/12/2015.
 */
@Metrics(registry = "EadvPlatformRegistry")
public final class TestClass {

    @Timed(name = "printSomethingTimer")
    public void printSomething() {
        System.out.println("Printing Something!");
    }
}

package com.dbs.eadv.metrics;

import com.codahale.metrics.Metric;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.MetricSet;
import com.codahale.metrics.SharedMetricRegistries;
import com.codahale.metrics.jvm.GarbageCollectorMetricSet;
import com.codahale.metrics.jvm.MemoryUsageGaugeSet;
import com.codahale.metrics.jvm.ThreadStatesGaugeSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import java.util.Map.Entry;

/**
 * Created by Srikanth Allamneni in Aug/2015.
 * To register JVM metrics
 * @author prakashkrishnan
 *
 */
public class JvmMetrics extends HttpServlet  {

	private static final long serialVersionUID = 1L;
	private static final MetricRegistry REGISTRY = SharedMetricRegistries.getOrCreate("EadvPlatformRegistry");

	/**
	 * Register GC, Memory and Threads for Metrics
	 */
	@Override
	public void init() throws ServletException {
		registerAll("gc", new GarbageCollectorMetricSet(), REGISTRY);
		registerAll("memory", new MemoryUsageGaugeSet(), REGISTRY);
		registerAll("threads", new ThreadStatesGaugeSet(), REGISTRY);
	}
/*
	@Override
	protected void service(final HttpServletRequest arg0, final HttpServletResponse arg1) throws ServletException, IOException {
		for (String metricName : REGISTRY.getGauges().keySet()) {
	        printMetric(metricName);
	    }
	}

	private void printMetric(final String metricName) {
	    Object value = REGISTRY.getGauges().get(metricName).getValue();
	    System.out.println("name=" + metricName + ", value=" + value);
	}*/

	private void registerAll(final String prefix, final MetricSet metricSet, final MetricRegistry registry) {
	    for (Entry<String, Metric> entry : metricSet.getMetrics().entrySet()) {
	        if (entry.getValue() instanceof MetricSet) {
	            registerAll(prefix + "." + entry.getKey(), (MetricSet) entry.getValue(), registry);
	        } else {
	            registry.register(prefix + "." + entry.getKey(), entry.getValue());
	        }
	    }
	}

}

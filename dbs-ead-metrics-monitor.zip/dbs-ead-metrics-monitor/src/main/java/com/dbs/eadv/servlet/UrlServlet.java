package com.dbs.eadv.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.dbs.eadv.to.JsonResponseTO;
import com.dbs.eadv.to.MetricsUrlTo;
import com.dbs.eadv.util.Constants;
import com.dbs.eadv.util.MetricsUtils;
import com.opensymphony.oscache.util.StringUtil;

public class UrlServlet extends HttpServlet{

	private static final Logger logger = Logger.getLogger(UrlServlet.class);


    public void doGet(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        PrintWriter out = null;

        List<MetricsUrlTo> parentJson = new ArrayList<MetricsUrlTo>();
        JsonResponseTO jsonResponseTO = new JsonResponseTO();

        try {
            logger.info("Begin to process CSV files.");
        	//Get CSV files from Server1
            parentJson = getUrlList();
            String json_data = list2Json(parentJson);
            httpServletResponse.setContentType("application/json");
            out = httpServletResponse.getWriter();
            out.print(json_data);
            out.flush();
        } catch (IOException e) {
        	logger.error(e.getMessage(), e);
        } finally {
            jsonResponseTO = null;
            parentJson = null;
            try {
            	if(out != null){
            		out.close();
            	}
            } catch (Exception e) {
            	logger.error(e.getMessage(), e);
            }
        }
    }
    private static List<MetricsUrlTo> getUrlList() throws UnknownHostException{
    	List<MetricsUrlTo> urls = new ArrayList<MetricsUrlTo>();
    	String serverName = InetAddress.getLocalHost().getHostName();
    	String[] arr = new String[0];
    	String server1Name = MetricsUtils.getProperty(Constants.SERVER1_NAME);
    	String server2Name = MetricsUtils.getProperty(Constants.SERVER2_NAME);
    	String server3Name = MetricsUtils.getProperty(Constants.SERVER3_NAME);
    	String server4Name = MetricsUtils.getProperty(Constants.SERVER4_NAME);
    	if(StringUtil.isEmpty(serverName)){
    		logger.error("Can't get serverName.");
    	}
    	else if(serverName.equalsIgnoreCase(server1Name)||serverName.equalsIgnoreCase(server2Name)){
    	    arr = new String[]{
    			Constants.METRICS_SERVER1_PROCESS_URL,Constants.METRICS_SERVER2_PROCESS_URL,
    			Constants.METRICS_SERVER1_SERVICE_URL,Constants.METRICS_SERVER2_SERVICE_URL,
    			Constants.METRICS_SERVER1_DESCRIPTION,Constants.METRICS_SERVER2_DESCRIPTION
    	    };
    	}
    	else if(serverName.equalsIgnoreCase(server3Name)||serverName.equalsIgnoreCase(server4Name)){
    		arr = new String[]{
        			Constants.METRICS_SERVER3_PROCESS_URL,Constants.METRICS_SERVER4_PROCESS_URL,
        			Constants.METRICS_SERVER3_SERVICE_URL,Constants.METRICS_SERVER4_SERVICE_URL,
        			Constants.METRICS_SERVER3_DESCRIPTION,Constants.METRICS_SERVER4_DESCRIPTION
        	};
        }
    	else{
    		logger.info("No server name compared right.");
    	}
    	for(int i=0; i < arr.length; i++){
    		String url_id = arr[i];
    		String url = MetricsUtils.getProperty(url_id);
    		
    		urls.add(new MetricsUrlTo(url_id,url));
    	}
    	
		return urls;
    }
    
    private String list2Json(List<MetricsUrlTo> urls){
        String response =  "[";

        for(MetricsUrlTo url: urls) {
            response = response + url.toString() + ",";
        }
        response = response.replaceAll(",$", "");
        response = response + "]";

        return response;
    }
    
}

package com.dbs.eadv.to;

import java.util.List;

/**
 * Created by mohamedj on 2/12/2015.
 */
public class ParentPropertyTO {

    private String property;
    private List<ChildPropertyTO> childPropertyTOList;

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public List<ChildPropertyTO> getChildPropertyTOList() {
        return childPropertyTOList;
    }

    public void setChildPropertyTOList(List<ChildPropertyTO> childPropertyTOList) {
        this.childPropertyTOList = childPropertyTOList;
    }

    @Override
    public String toString() {
        String parent =  "\"" + this.getProperty() + "\":" + "{";

        for(ChildPropertyTO child: this.getChildPropertyTOList()) {
            parent = parent + child.toString() + ",";
        }
        parent = parent.replaceAll(",$", "");
        parent = parent + "}";

        return  parent;
    }

}

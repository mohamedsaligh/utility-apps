package com.dbs.eadv.metrics;

import com.codahale.metrics.CsvReporter;
import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.SharedMetricRegistries;
import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.ncs.iframe.commons.logging.Logger;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;

/**
 * Created by Srikanth Allamneni in August 2015.
 * This will report metrics to console and CSV file
 */
public class MetricsMeters {

	private static final Logger logger = Logger.getLogger(MetricsMeters.class);

	private static final MetricRegistry metrics = SharedMetricRegistries.getOrCreate("EadvPlatformRegistry");

	//private static ConsoleReporter console = null;
	private static CsvReporter csvReporter = null;

	/**
	 *This will start report metrics in console and CSV files
	 */
	public static void startReport(final String folderPath) {
		/*console = ConsoleReporter.forRegistry(metrics).convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS).build();
		console.start(10, TimeUnit.MINUTES);*/
		csvReporter = CsvReporter.forRegistry(metrics).convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS)
				.build(new File(folderPath));
		csvReporter.start(1, TimeUnit.MINUTES);
        logger.info("********Metrics Report Started**************");
	}

	/**
	 *This will stop report metrics in console and CSV files
	 */
	public static void stopReport() {
		//console.stop();
		csvReporter.stop();
		logger.info("********Stopped Metrics Report**************");
	}

}
package com.dbs.eadv.batch;

import com.codahale.metrics.*;
import com.dbs.eadv.metrics.JsonMetricsReporter;
import com.dbs.eadv.metrics.MetricsMeters;
import com.dbs.eadv.metrics.MetricsServlet;
import com.dbs.eadv.metrics.ReportMetricsServletContextListener;
import io.astefanutti.metrics.aspectj.MetricStaticAspect;
import io.astefanutti.metrics.aspectj.Metrics;
import org.springframework.beans.factory.BeanFactoryUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.servlet.ServletException;
import java.io.File;
import java.util.SortedMap;
import java.util.concurrent.TimeUnit;

/**
 * Created by mohamedj on 4/12/2015.
 */
public class BatchMain {

    private static final String LOGS = "D:\\logs\\eadv\\metrics";
    private static final MetricRegistry REGISTRY = SharedMetricRegistries.getOrCreate("EadvPlatformRegistry");

    public static void main(String[] args) throws ServletException {
        System.out.println("Start");

        REGISTRY.timer("printSomethingTimer");
        CsvReporter csvReporter = CsvReporter.forRegistry(REGISTRY).convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS)
                .build(new File(LOGS));
        csvReporter.start(1, TimeUnit.NANOSECONDS);

        TestClass test = new TestClass();
        test.printSomething();

        csvReporter.stop();
        System.out.println("End");
    }
}

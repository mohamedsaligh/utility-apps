package com.dbs.eadv.to;

public class MetricsUrlTo {
	private String url_id;
	private String url;

	public String getUrl_id() {
		return url_id;
	}

	public void setUrl_id(String url_id) {
		this.url_id = url_id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public MetricsUrlTo(String url_id, String url) {
		super();
		this.url_id = url_id;
		this.url = url;
	}

	public MetricsUrlTo() {
		super();
	}

	@Override
	public String toString() {
		String url = "{\"id\":\"" + this.getUrl_id() + "\",";

		url = url + "\"url\":\"" + getUrl() + "\"},";
		url = url.replaceAll(",$", "");

		return url;
	}
}

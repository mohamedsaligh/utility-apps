package com.dbs.eadv.metrics;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import com.dbs.eadv.util.Constants;
import com.dbs.eadv.util.MetricsUtils;

/**
 * Created by Srikanth Allamneni in August 2015.
 * This will start/stop the reports when the application starts/stop
 */
public class MetricsServlet extends HttpServlet {

	private static final String LOGS = MetricsUtils.getProperty(Constants.METRICS_CURRENT_SERVER_APP_CSV_PATH);

	private static final long serialVersionUID = 1L;

	/**
	 *This is to Start the Metrics report when the application is started
	 */
	@Override
	public void init(final ServletConfig config) throws ServletException {
		MetricsMeters.startReport(LOGS);
	}

	/**
	 *This is to Stop the Metrics report when the application is stopped
	 */
	@Override
	public void destroy() {
		MetricsMeters.stopReport();
	}
}

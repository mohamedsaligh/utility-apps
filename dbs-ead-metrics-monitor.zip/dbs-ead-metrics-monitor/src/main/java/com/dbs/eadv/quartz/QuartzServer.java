package com.dbs.eadv.quartz;

import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerUtils;
import org.quartz.impl.StdSchedulerFactory;

import com.dbs.eadv.util.Constants;
import com.dbs.eadv.util.MetricsUtils;

public class QuartzServer {
	
	private static int hour;
	private static int minute;

	static {
		hour = Integer.parseInt(MetricsUtils
				.getProperty(Constants.METRICS_BACKUP_TIME_HOUR));
		minute = Integer.parseInt(MetricsUtils
				.getProperty(Constants.METRICS_BACKUP_TIME_MINUTE));
	}
	
	public static void main(String[] args) {
		QuartzServer qs = new QuartzServer();
		try {
			qs.startScheduler();
		} catch (SchedulerException e) {
			e.printStackTrace();
		}
	}
	
	public void startScheduler() throws SchedulerException{
		Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
		JobDetail jobDetail = new JobDetail("QuartzJob",Scheduler.DEFAULT_GROUP,QuartzJob.class);
		
//		Trigger trigger = TriggerUtils.makeSecondlyTrigger(1);
		Trigger trigger = TriggerUtils.makeDailyTrigger(hour, minute);
		trigger.setName("metrics-quartz-trigger");
		scheduler.scheduleJob(jobDetail,trigger);
		
		scheduler.start();
	}
}

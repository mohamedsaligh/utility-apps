package com.dbs.eadv.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

public class BackUpUtil {
	
	private static final Logger logger = Logger.getLogger(BackUpUtil.class);
	static String parent_path = null;
	static String backup_path = null;
	/**
	 * This method to finish backup CSV files The csv file exist three folder
	 * 
	 * */
	public static void backUpFile() {
		parent_path = MetricsUtils.getProperty(Constants.METRICS_SERVER1_DATA_PATH);
		backup_path = MetricsUtils.getProperty(Constants.METRICS_SERVER1_BACKUP_PATH);
		String[] path_arr = new String[] { "app/","process/", "service/" };
		
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		String current_date = df.format(new Date());
		boolean isMakeDir = makeDirs(backup_path);
		isMakeDir = makeDirs(backup_path + current_date + "/");
		
		logger.info("BackUp File Make Dir Status: " + current_date + "--" +isMakeDir);
		for (int i = 0; i < path_arr.length; i++) {
			String tmp = parent_path + path_arr[i];
			List<File> list = getFileNameList(tmp);
			logger.info("===========================");
			logger.info(tmp + "Total file size: "+list.size());
			logger.info("---------------------------");
			File source_file = null;
			String object_path = null;
			
			for(File file : list){
				source_file = file;
				if(file.getName().endsWith(".csv")){
					object_path = backup_path + current_date + "/" + path_arr[i];
					isMakeDir = makeDirs(object_path);
					logger.info("BackUp File Make Dir Status:"+ object_path +"--" + isMakeDir);
					object_path = object_path + source_file.getName();
					try {
						if(source_file.renameTo(new File(object_path))){
							logger.debug(source_file + " ----> " + object_path);
						}else{
							logger.error("error");
						}
					} catch (Exception e) {
						logger.error("When move file, has problem.",e);
					}
					object_path = null;
				}
				
			}
			logger.info("===========================");
		}

	}

	public static List<File> getFileNameList(String folder_name) {
		File folder = null;
		try {
			folder = new File(folder_name);
			return Arrays.asList(folder.listFiles());
		} catch (Exception e) {
			logger.info("When get File List : ",e);
		}
		return null;
	}
	
	public static boolean makeDirs(String filePath){
		File folder = new File(filePath);
		return (folder.exists() && folder.isDirectory()) ? true : folder.mkdir();
	}
	
}

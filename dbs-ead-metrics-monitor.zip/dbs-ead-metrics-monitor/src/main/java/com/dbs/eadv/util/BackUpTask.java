package com.dbs.eadv.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.log4j.Logger;

public class BackUpTask {
	private static final Logger logger = Logger.getLogger(BackUpTask.class);
	static Timer timer;
	private static int hour;
	private static int minute;
	private static int second;

	public static Timer getTimer() {
		return timer;
	}

	static {
		hour = Integer.parseInt(MetricsUtils
				.getProperty(Constants.METRICS_BACKUP_TIME_HOUR));
		minute = Integer.parseInt(MetricsUtils
				.getProperty(Constants.METRICS_BACKUP_TIME_MINUTE));
		second = Integer.parseInt(MetricsUtils
				.getProperty(Constants.METRICS_BACKUP_TIME_SECOND));
	}

	public BackUpTask(boolean status) {
		Date time = getTime(status);
		logger.debug("Get need time :: "+time);
		timer = new Timer();
		timer.schedule(new myTask(), time);
	}

	public Date getTime(boolean status) {
		Date date = new Date();
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
			String nowDate = df.format(date);
			logger.info("get current date: "+nowDate);
			
			Calendar calendar = Calendar.getInstance();

			calendar.setTime(df.parse(nowDate));
			if(!status){
				calendar.add(Calendar.DAY_OF_YEAR, +1);
				String next_date = df.format(calendar.getTime());
				logger.info("get next date: "+next_date);
				
				calendar.set(Calendar.DAY_OF_YEAR, Integer.parseInt(next_date.substring(0,4)));
				calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(next_date.substring(4,6)));
				calendar.set(Calendar.DATE, Integer.parseInt(next_date.substring(6)));
			}
			calendar.set(Calendar.HOUR_OF_DAY, hour);
			calendar.set(Calendar.MINUTE, minute);
			calendar.set(Calendar.SECOND, second);
			Date time = calendar.getTime();
			return time;
		} catch (ParseException e) {
			e.printStackTrace();
			logger.error("Get Time ERROR",e);
		}
		return null;
	}

	public static void main(String[] args) {
		new BackUpTask(true);
	}
}

class myTask extends TimerTask {
	Timer timer;

	@Override
	public void run() {

		BackUpUtil.backUpFile();
		timer = BackUpTask.getTimer();
		timer.cancel();
		new BackUpTask(false);
	}
}

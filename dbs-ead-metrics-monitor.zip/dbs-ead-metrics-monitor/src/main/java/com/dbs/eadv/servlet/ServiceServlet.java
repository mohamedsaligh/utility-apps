package com.dbs.eadv.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.dbs.eadv.to.ChildPropertyTO;
import com.dbs.eadv.to.JsonResponseTO;
import com.dbs.eadv.to.ParentPropertyTO;
import com.dbs.eadv.util.Constants;
import com.dbs.eadv.util.MetricsUtils;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

/**
 * Created by mohamedj on 10/11/15.
 */
public class ServiceServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(ServiceServlet.class);

	public void doGet(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {
		PrintWriter out = null;

		List<ParentPropertyTO> parentJson = new ArrayList<ParentPropertyTO>();
		List<ChildPropertyTO> childTimers = new ArrayList<ChildPropertyTO>();
		List<ChildPropertyTO> emailTimers = new ArrayList<ChildPropertyTO>();
		List<ChildPropertyTO> faxTimers = new ArrayList<ChildPropertyTO>();
		List<ChildPropertyTO> smsTimers = new ArrayList<ChildPropertyTO>();
		List<ChildPropertyTO> batchTimers = new ArrayList<ChildPropertyTO>();
		JsonResponseTO jsonResponseTO = new JsonResponseTO();

		try {
			logger.info("Begin to process CSV files.");
			// Get CSV files from Server1
			List<File> files = getFiles(MetricsUtils
					.getProperty(Constants.METRICS_SERVER1_SERVICE_CSV_PATH));
			getChilds(files, childTimers, emailTimers, faxTimers, smsTimers,
					batchTimers);

			ParentPropertyTO parentTimersS1 = new ParentPropertyTO();
			parentTimersS1.setProperty("server1Timers");
			parentTimersS1.setChildPropertyTOList(childTimers);

			ParentPropertyTO parentTimersEmail = new ParentPropertyTO();
			parentTimersEmail.setProperty("emailTimers");
			parentTimersEmail.setChildPropertyTOList(emailTimers);

			ParentPropertyTO parentTimersFax = new ParentPropertyTO();
			parentTimersFax.setProperty("faxTimers");
			parentTimersFax.setChildPropertyTOList(faxTimers);

			ParentPropertyTO parentTimersSms = new ParentPropertyTO();
			parentTimersSms.setProperty("smsTimers");
			parentTimersSms.setChildPropertyTOList(smsTimers);

			ParentPropertyTO parentTimersS2 = new ParentPropertyTO();
			parentTimersS2.setProperty("batch1Timers");
			parentTimersS2.setChildPropertyTOList(batchTimers);

			// childTimers = new ArrayList<ChildPropertyTO>();
			//
			// files =
			// getFiles(MetricsUtils.getProperty(Constants.METRICS_SERVER2_SERVICE_CSV_PATH));
			// getChilds(files, childTimers);
			//
			// ParentPropertyTO parentTimersS2 = new ParentPropertyTO();
			// parentTimersS2.setProperty("server2Timers");
			// parentTimersS2.setChildPropertyTOList(childTimers);

			parentJson.add(parentTimersS1);
			parentJson.add(parentTimersS2);
			parentJson.add(parentTimersEmail);
			parentJson.add(parentTimersFax);
			parentJson.add(parentTimersSms);
			// parentJson.add(parentTimersS2);

			jsonResponseTO.setParentPropertyTOList(parentJson);

			// System.out.println(jsonResponseTO.toString());

			httpServletResponse.setContentType("application/json");
			out = httpServletResponse.getWriter();
			out.print(jsonResponseTO.toString());
			out.flush();
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		} finally {
			jsonResponseTO = null;
			parentJson = null;
			childTimers = null;
			batchTimers = null;
			emailTimers = null;
			smsTimers = null;
			faxTimers = null;
			try {
				if (out != null) {
					out.close();
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	public static List<Map<?, ?>> readObjectsFromCsv(File file)
			throws IOException {
		CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
		CsvMapper csvMapper = new CsvMapper();
		MappingIterator<Map<?, ?>> mappingIterator = csvMapper
				.reader(Map.class).with(bootstrap).readValues(file);
		return mappingIterator.readAll();
	}

	public List<File> getFiles(String path) {
		File folder = new File(path);
		return Arrays.asList(folder.listFiles());
	}

	public void getChilds(List<File> files, List<ChildPropertyTO> childTimers,
			List<ChildPropertyTO> emailTimers, List<ChildPropertyTO> faxTimers,
			List<ChildPropertyTO> smsTimers, List<ChildPropertyTO> batchTimers)
			throws IOException {
		List<Map<?, ?>> resultdata;

		try {
			for (File file : files) {

				ChildPropertyTO child = new ChildPropertyTO();
				child.setProperty(file.getName().replaceAll(".csv$", ""));

				resultdata = readObjectsFromCsv(file);

				ObjectMapper mapper = new ObjectMapper();
				String result = mapper.writeValueAsString(resultdata
						.get(resultdata.size() - 1));
				child.setData(result);
				if (file.getName().contains("Timer")) {
					childTimers.add(child);
					if (file.getName().contains("GenerateEmail")) {
						emailTimers.add(child);
					} else if (file.getName().contains("DeliveryEmail")
							&& !file.getName().contains("ReDeliveryEmail")) {
						emailTimers.add(child);
					}
					if (file.getName().contains("GenerateSms")) {
						smsTimers.add(child);
					} else if (file.getName().contains("DeliverySms")
							&& !file.getName().contains("ReDeliverySms")) {
						smsTimers.add(child);
					}
					if (file.getName().contains("GenerateFax")) {
						faxTimers.add(child);
					} else if (file.getName().contains("DeliveryFax")
							&& !file.getName().contains("ReDeliveryFax")) {
						faxTimers.add(child);
					}
				} else if (file.getName().contains("Batch")) {
					batchTimers.add(child);
				}

			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			throw e;
		} finally {
			resultdata = null;
		}
	}
}

package com.dbs.eadv.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.quartz.SchedulerException;

import com.dbs.eadv.quartz.QuartzServer;
import com.dbs.eadv.util.BackUpTask;

public class BackupServlet extends HttpServlet{
	private static final Logger logger = Logger.getLogger(BackupServlet.class);
	
	@Override
	public void init() throws ServletException {
		logger.info("Servlet Start...");
		QuartzServer qs = new QuartzServer();
		try {
			qs.startScheduler();
		} catch (SchedulerException e) {
			logger.info("When Servlet Quartz has Problem",e);
		}
		logger.info("Servlet end...");
	}
	
}

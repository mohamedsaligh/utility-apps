package com.dbs.eadv.metrics;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.SharedMetricRegistries;

/**
 * Created by Srikanth Allamneni in August 2015.
 * This listener is for REST service calls to log metrics
 */
public class ReportMetricsServletContextListener extends  com.codahale.metrics.servlets.MetricsServlet.ContextListener  {

	private static final MetricRegistry REGISTRY = SharedMetricRegistries.getOrCreate("EadvPlatformRegistry");

	@Override
	protected MetricRegistry getMetricRegistry() {
		return REGISTRY;
	}

}
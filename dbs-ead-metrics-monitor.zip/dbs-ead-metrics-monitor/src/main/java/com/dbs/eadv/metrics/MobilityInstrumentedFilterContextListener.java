package com.dbs.eadv.metrics;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.SharedMetricRegistries;
import com.codahale.metrics.servlet.InstrumentedFilterContextListener;

/**
 * Created by Srikanth Allamneni in August 2015.
 * This will log(console/CSV file) the HTTP requests like Ok, created, not found and etc.
 */
public class MobilityInstrumentedFilterContextListener extends	InstrumentedFilterContextListener {

	private static final MetricRegistry REGISTRY = SharedMetricRegistries.getOrCreate("EadvPlatformRegistry");

	@Override
	protected MetricRegistry getMetricRegistry() {
		return REGISTRY;
	}
}
package com.dbs.eadv.to;

import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by mohamedj on 2/12/2015.
 */
public class JsonResponseTO {

    private List<ParentPropertyTO> parentPropertyTOList;

    public List<ParentPropertyTO> getParentPropertyTOList() {
        return parentPropertyTOList;
    }

    public void setParentPropertyTOList(List<ParentPropertyTO> parentPropertyTOList) {
        this.parentPropertyTOList = parentPropertyTOList;
    }

    @Override
    public String toString() {
        String response =  "{";

        for(ParentPropertyTO parent: this.getParentPropertyTOList()) {
            response = response + parent.toString() + ",";
        }
        response = response.replaceAll(",$", "");
        response = response + "}";

        return  response;
    }
}

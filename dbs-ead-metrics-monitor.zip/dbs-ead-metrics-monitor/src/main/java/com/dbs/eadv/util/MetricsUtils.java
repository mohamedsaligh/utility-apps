package com.dbs.eadv.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class MetricsUtils {
	
	private static final Logger logger = Logger.getLogger(MetricsUtils.class);

	public static Properties prop = new Properties();
	
	public static String getProperty(String key){
		String value = "";
		InputStream in = null;
		
		try {
			in = MetricsUtils.class.getResourceAsStream(Constants.PROPERTY_FILE_NAME);
			prop.load(in);
			value = prop.getProperty(key);
		} catch (Exception e) {
			logger.error("Encounter errors when get properties from file.", e);
		} finally{
			try {
				if(in != null){
					in.close();
				}
			} catch (IOException e) {
				logger.error("Encounter errors when close InputStream.", e);
			}
		}
		
		return value;
	}
	
}

package com.dbs.eadv.quartz;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.dbs.eadv.util.BackUpUtil;

public class QuartzJob implements Job{

	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		BackUpUtil backupUtil = new BackUpUtil();
		backupUtil.backUpFile();
	}

}

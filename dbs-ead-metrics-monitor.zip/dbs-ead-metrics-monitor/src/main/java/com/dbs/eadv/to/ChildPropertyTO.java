package com.dbs.eadv.to;

/**
 * Created by mohamedj on 2/12/2015.
 */
public class ChildPropertyTO {

    private String property;
    private String data;

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "\"" + this.getProperty() + "\":" + this.getData();
    }
}

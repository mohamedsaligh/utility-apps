# Operations — CI/CD, Deployment, and Local Dev

The user's request: *"deployment scripts specific projects, local developer setup scripts, start restart, manage and so on with proper guides"*. This document covers both — production deploys and dev-loop ergonomics.

Bad operational practices show up as: 2am pages, slow dev loops, fear of deploying, fear of refactoring. Good ones make all of these go away.

---

## CI/CD pipeline shape

A standard pipeline has these stages, in order. Each is a gate; failing any stops the pipeline.

```
[1] Lint / format check          (~30s)
[2] Unit tests                   (~1-5 min)
[3] Build                        (~1-3 min)
[4] Integration tests            (~3-15 min)
[5] Security/dependency scan     (~1-2 min)
[6] Deploy to staging            (~1-3 min)
[7] Smoke tests on staging       (~1-2 min)
[8] [Manual approval gate]       (deploy to prod)
[9] Deploy to prod (canary first) (~5-30 min)
[10] Monitor canary metrics, rollback or proceed
```

### Rules

- **Fast feedback first.** Lint and unit tests run before slow integration tests. A typo shouldn't wait 15 minutes for the integration suite.
- **Parallelize what you can.** Lint, unit tests, build, security scan can all run in parallel. The pipeline's wall-clock time is the longest path.
- **Every commit to main runs the full pipeline.** No "we'll run it later." Broken main is everyone's problem.
- **Required for merge:** pipeline green. Branch protection enforces this.
- **Rollback is automated.** A button (or auto-rollback on metric degradation), not a runbook of manual steps.

### Pipeline anti-patterns

- **Manual deploy steps in the pipeline.** Manual = forgotten under pressure. Automate or remove.
- **Skipping tests with `[skip ci]`** under deadline pressure. The bug you skipped finding will be found in prod.
- **No staging environment.** Or worse, "staging is prod's database with a different frontend". Staging needs its own data.

A working `scripts/deployment.yml.template` (GitHub Actions skeleton) is bundled with this skill — adapt it to your stack.

---

## Release strategy

How code reaches users. Pick one per service; document it.

| Strategy | How | Best for |
|---|---|---|
| **Rolling** | Replace pods/instances one by one with the new version | Default for most services |
| **Blue/green** | Bring up entire new environment; switch traffic; tear down old | Apps where partial-version-mix is risky (DB schema changes, stateful) |
| **Canary** | Send small % of traffic to new version; monitor; ramp up | High-risk changes; large user base |
| **Feature flags** | Deploy code dark; enable behind a flag; ramp by user/percentage | Long-lived experiments, complex rollouts |

**Most teams should default to rolling + canary.** Blue/green's "everything at once" is rarely worth the resource cost. Feature flags are a Phase-2 capability — useful when warranted, overkill before.

### Rollback discipline

- **Automated rollback** triggered by SLO violations during canary. Don't make humans decide under stress.
- **Database migrations are forward-only in prod** (see `03-data-layer.md`). A "roll back the migration" plan is theoretical at best.
- **Test rollback regularly.** A rollback you've never executed is a rollback that won't work the one time you need it.

---

## Environment management

Three environments are the minimum: **dev** (developer machines), **staging** (prod-like), **prod**.

### Parity

- Dev / staging / prod should run the **same code** with **different configuration**. Configuration → environment variables / config service. Code changes should never be needed to switch environments.
- Staging should mimic prod: same OS, same DB engine version, same major library versions, similar data shape (anonymized prod data dumps where compliance allows).
- Local dev can diverge in scale (single-node DB instead of cluster) but not in behavior.

### Configuration

- **Environment variables** for the deploy-time config (DB connection strings, API endpoints, feature flag defaults).
- **Secret manager** for credentials (see `07-security.md`).
- **Config service / dynamic config** for feature flags and runtime tuning that should change without redeploy.
- **Don't** store environment-specific config in code (`if env == "prod"` branches). Configuration belongs in configuration.

---

## Local developer setup

The user explicitly requested: *"local developer setup scripts, start restart, manage and so on with proper guides"*.

### One-command bootstrap

A new engineer should clone the repo, run **one command**, and have a working local dev environment within 10 minutes. The bundled template (`scripts/local-setup.sh.template`) is structured around this goal.

```
./scripts/dev setup     # idempotent: install deps, copy env, init DB, seed
./scripts/dev start     # start all services (DB, app, frontend, queue)
./scripts/dev stop      # stop all services
./scripts/dev restart   # stop + start
./scripts/dev doctor    # check the environment for common issues
./scripts/dev test      # run the test suite
./scripts/dev clean     # nuke local state (with confirmation)
./scripts/dev --help    # show all commands
```

### Properties of a good `setup` script

- **Idempotent.** Running it twice doesn't break anything. (`mkdir -p`, `git clone || git pull`, etc.)
- **Detects existing state.** "DB already exists, skipping init."
- **Fails loudly with actionable errors.** "Postgres not installed. Run: `brew install postgresql@16`."
- **Works on the team's primary OSes.** macOS + Linux for most teams; Windows via WSL.
- **No interactive prompts.** Use flags or env vars for choices.

### Properties of a good `doctor` script

Diagnoses common dev environment issues before they become "it works on my machine":

- Required tools installed and at the right version.
- Required services running (DB, cache, queue).
- `.env` file exists with required keys.
- Migrations are up to date.
- Disk space sufficient.
- Ports not blocked / in use by something else.

The `doctor` script is the first thing to suggest when an engineer says "my dev env is broken".

### Service orchestration locally

**Three viable approaches:**

1. **Docker Compose** — everything in containers. Cross-platform, isolated, reproducible. Slower disk I/O on macOS (use volume optimizations or named volumes).
2. **Native install + Compose for dependencies** — DB/cache/queue in containers; app runs natively for fast hot-reload and easy debugging. Most popular setup.
3. **Devcontainers / Codespaces** — fully containerized dev env including the IDE. Eliminates "works on my machine" entirely; trades local resource usage.

Pick one per project. Don't make people choose at runtime.

---

## README structure for onboarding

The README should answer the new engineer's first 10 minutes of questions:

```
# Project Name

What this is. One paragraph.

## Quick Start

1. Prerequisites (`./scripts/dev doctor` for the canonical check)
2. `./scripts/dev setup`
3. `./scripts/dev start`
4. Open http://localhost:3000

## Architecture

One sentence + link to ADRs.

## Common tasks

- Run tests: `./scripts/dev test`
- Lint: `./scripts/dev lint`
- Run a migration: `./scripts/dev migrate`
- Reset local DB: `./scripts/dev db reset`

## Where things live

- Backend: `src/server/`
- Frontend: `src/web/`
- DB migrations: `migrations/`
- ADRs: `docs/adr/`

## Where to ask for help

- Slack channel
- On-call rotation
```

A README that doesn't get a new engineer running in 10 minutes is a README that needs work.

---

## Operational runbooks

For every alert that pages a human, there should be a runbook:

```
# Alert: API P99 latency > 1s for 5 minutes

## What it means
Some endpoint is slow. May be one endpoint or all.

## First steps
1. Check the latency-by-endpoint dashboard. Identify which endpoints.
2. Check error rate (correlated cause).
3. Check downstream dependency latency (DB, cache, third-party APIs).

## Common causes
- DB slow query / missing index → check slow query log
- Cache cluster issue → check cache hit rate
- Third-party API outage → check status pages

## Mitigation
- If a deploy was recent (< 30 min): rollback first, investigate after.
- If a specific endpoint is slow and non-critical: feature-flag it off.
- If overload: scale horizontally; check rate limits at edge.

## Escalation
If unresolved in 30 minutes, page secondary on-call.
```

Runbooks live in the repo, not a wiki. Updated as part of normal PRs.

---

## What good ops looks like

- Deploys happen multiple times a day with no drama.
- Rollback is one click and tested.
- New engineers ship code their first week.
- Pages have runbooks; runbooks resolve incidents.
- The on-call rotation is shared, fairly distributed, not one person's permanent burden.

---

## Cross-references

- **CI test strategy** → `09-testing-strategy.md`.
- **Self-healing patterns** → `06-resilience-observability.md`.
- **Secrets in deploy pipelines** → `07-security.md`.
- **Migration discipline** → `03-data-layer.md`.
- **Karpathy hook**: before adopting a heavyweight CI/CD platform or service-mesh tooling, invoke `andrej-karpathy-skills:karpathy-guidelines`. Most teams' actual ops needs are met by GitHub Actions + a simple deploy script + a managed orchestrator. Adopt heavier tooling only when the simpler thing has demonstrably broken.

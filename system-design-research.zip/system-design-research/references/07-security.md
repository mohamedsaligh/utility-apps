# Security

Security is the design dimension where the cost of getting it wrong is asymmetric: years of correct decisions can be erased by one mistake. **It must be designed in**, not added later.

This document covers the architectural side of security — authN, authZ, secrets, OWASP top 10, threat modeling. It does not cover specific cryptographic algorithm choices (delegate to current standards bodies — research via Phase 0 if needed) or pen-testing.

---

## Authentication (AuthN) — proving who someone is

**Pick one model per system; don't mix.** Mixed auth models cause subtle bugs.

### Common models

| Model | Use when | Watch out for |
|---|---|---|
| **Server-side sessions** (cookie + session store) | Traditional web app, single domain, server-rendered pages | Session-store HA; CSRF (use SameSite cookies + tokens); session fixation |
| **JWT (stateless tokens)** | API for SPAs/mobile, distributed systems | Revocation is hard (use short TTLs + refresh tokens); store secrets safely; signature algorithm pinning |
| **OAuth 2.0 / OIDC** | "Sign in with Google/etc."; delegating identity to a provider | Provider lock-in; understand authorization-code-with-PKCE for SPAs/mobile |
| **API keys** | Service-to-service, internal automation | Rotation strategy; per-key rate limit; never in URLs (logged) |
| **mTLS** | High-trust service-to-service; zero-trust networks | Certificate lifecycle automation (cert-manager, Vault) |

### Required for every model

- **Strong password requirements** if you do password auth — but don't enforce arbitrary complexity rules (NIST guidance: length + breached-password check beats "must have one symbol").
- **Rate limit auth endpoints**. Login, password reset, MFA — all aggressive rate-limited per IP and per account.
- **MFA for sensitive actions** at minimum (admin login, payment changes). Ideally for all logins.
- **Session/token expiry**. Short access tokens (15-60 min) + longer refresh tokens with rotation.
- **Logout invalidates server-side state** (sessions: delete; JWT: add to revocation list or use short TTLs).
- **Secure cookie flags**: `Secure`, `HttpOnly`, `SameSite=Lax` (or `Strict`).

---

## Authorization (AuthZ) — what someone can do

**AuthN ≠ AuthZ.** A logged-in user is not authorized to do everything; authorization is per resource, per action.

### Models

- **RBAC (Role-Based Access Control)**. Users have roles; roles have permissions. Simple, common.
- **ABAC (Attribute-Based Access Control)**. Permissions evaluated from attributes (user, resource, environment). Flexible; harder to reason about.
- **ReBAC (Relationship-Based Access Control)**. Permissions follow relationships (Google Zanzibar model: user X has access to doc Y because X is in group Z, and Z has access to Y). Powerful for collaborative apps.

**Default to RBAC** until you have a concrete reason for ABAC/ReBAC.

### Required practices

- **Authorization at the data layer, not just the controller.** Controller checks are bypassed when someone introduces a new endpoint and forgets the check. Repository-level filters (e.g., `WHERE org_id = :current_org_id`) make data isolation a baseline, not an option.
- **Default deny.** Anything not explicitly allowed is denied. Whitelisting beats blacklisting.
- **Principle of least privilege.** Give users / services only the permissions they need. Audit periodically.
- **Test the authorization rules.** A test that asserts "user A cannot access user B's order" is more important than a test that asserts the happy path. Permission tests are the most under-written tests in most codebases.

### Multi-tenancy

In multi-tenant systems, **tenant isolation is the most important invariant**. Patterns:
- **Row-level**: every table has a `tenant_id` column; every query is filtered. Repository wrapper enforces.
- **Schema-level**: each tenant gets a schema. Cleaner isolation; harder to operate.
- **DB-level**: each tenant gets a database. Strongest isolation; most ops overhead.

Pick one. Hybrid models invariably leak.

---

## Secret management

Secrets are credentials, API keys, signing keys, encryption keys. Mishandled secrets are the #1 source of breach blowback.

### Rules

- **Never commit secrets to git.** Use `.gitignore` for `.env*`, scan history with tools like `git-secrets` or `trufflehog`. Once committed, treat as compromised — rotate immediately, even if force-pushed away (caches retain).
- **Use a secret manager.** AWS Secrets Manager, GCP Secret Manager, Azure Key Vault, HashiCorp Vault, 1Password Secrets, Doppler. Apps fetch secrets at runtime (or sidecar / init container injects).
- **Rotate secrets.** Have a rotation procedure for every secret class (DB passwords, API keys, signing keys). Automate where possible. **A secret that hasn't been rotated in years is functionally as good as compromised.**
- **Different secrets per environment.** Dev / staging / prod must NOT share secrets. A leaked dev key shouldn't grant prod access.
- **Audit secret access.** Who fetched what when. Anomaly detection on access patterns.

### Encryption

- **At rest**: enabled by default on managed databases and storage. Verify it's on. Manage keys via KMS.
- **In transit**: TLS everywhere. Internal service-to-service traffic too — "internal network is trusted" is a 2005 assumption.
- **In application**: encrypt sensitive fields (PII, tokens) at the application layer too if they're high-value. Layered defense.

---

## OWASP Top 10 — minimum baseline

The OWASP Top 10 changes periodically. Research the **current** edition (Phase 0 web search if uncertain). The categories below are durable; specifics shift.

| Category | Mitigation |
|---|---|
| **Injection** (SQL, command, LDAP) | Parameterized queries everywhere. ORMs help when used correctly; raw SQL needs prepared statements. Never string-concatenate user input into queries / shell commands. |
| **Broken authentication** | See AuthN section above. Rate limit, MFA, session expiry, no credentials in URLs/logs. |
| **Sensitive data exposure** | Encryption at rest + in transit. Don't log PII. Mask sensitive fields in API responses unless needed. |
| **XML External Entities (XXE)** | Disable XML external entity processing in parsers. Most modern stacks have it disabled by default — verify. |
| **Broken access control** | Authorization at data layer. Default deny. Test authorization. |
| **Security misconfiguration** | Don't run debug mode in prod. Default credentials changed. CORS configured tightly. Headers set (CSP, HSTS, X-Frame-Options). Automated config scanning. |
| **XSS (Cross-Site Scripting)** | Output encoding by default in templates. CSP headers. Sanitize HTML if you accept it. Avoid `innerHTML` / `dangerouslySetInnerHTML` with user content. |
| **Insecure deserialization** | Avoid deserializing untrusted data into language-native objects. Use safe formats (JSON with schema validation). |
| **Vulnerable components** | Dependency scanning (Dependabot, Snyk, Renovate). Update on a cadence. Pin versions; don't rely on floating tags. |
| **Insufficient logging & monitoring** | Audit logs for sensitive operations. Alert on auth anomalies (failed login bursts, geo-impossible logins). See `06-resilience-observability.md`. |

---

## Threat modeling — STRIDE

For non-trivial features, do a 30-minute STRIDE pass before designing:

- **S**poofing — can an attacker pretend to be someone else?
- **T**ampering — can data be modified in transit / at rest by an attacker?
- **R**epudiation — can a user deny doing something they did? (audit logs counter)
- **I**nformation disclosure — what sensitive data could leak?
- **D**enial of service — what overloads the system?
- **E**levation of privilege — can a user gain privileges they shouldn't have?

Per STRIDE category, identify the worst-case scenario and the mitigation. Document in the ADR.

**This isn't a one-time exercise.** Re-do STRIDE when adding features that touch auth, data flow, or trust boundaries.

---

## Input validation as security boundary

**Validate at the system boundary** (where untrusted input enters), not deep in business logic. The boundary is your trust line; past it, code can assume input is well-formed.

- API requests: schema validation on entry (JSON Schema, Pydantic, Zod, validators in Spring/etc.).
- File uploads: type check, size limit, content scan, store outside web root, never execute.
- URLs / query parameters: validate types and ranges.
- Webhook payloads: verify signatures from the sender.

**Don't trust:**
- Client-side validation alone — clients can be modified. Always re-validate server-side.
- The fact that a field "shouldn't be" a certain shape because the UI doesn't allow it.
- IP-based authorization without other factors (IPs are spoofable in some contexts).

---

## CORS and CSRF

**CORS** (Cross-Origin Resource Sharing) — controls which origins can call your API from a browser. **Configure tightly.** `Access-Control-Allow-Origin: *` on a credentialed API is a giveaway. Maintain an allowlist of known frontends.

**CSRF** (Cross-Site Request Forgery) — an attacker tricks a logged-in user's browser into making a state-changing request to your site. Mitigations:
- `SameSite=Lax` or `Strict` on session cookies (modern default; covers most cases).
- CSRF tokens on state-changing forms (legacy pattern, still useful for high-risk flows).
- Don't accept GET for state-changing operations.

For APIs called from SPAs with JWT in `Authorization` header (not cookies), CSRF is mostly moot — attackers can't read the user's token from another origin.

---

## Cross-references

- **AuthZ at the data layer** → `03-data-layer.md` (repository-level filtering).
- **Audit log retention and purge policy** → `03-data-layer.md` (audit logs are typically transactional with longer retention).
- **Observability / detection** → `06-resilience-observability.md`.
- **Karpathy hook** — security frameworks are heavy; before adopting one, ask: *can the simpler thing solve this?* Most security needs are handled by sensible defaults (well-known auth library + ORM + framework's built-in protections), not custom security infrastructure.

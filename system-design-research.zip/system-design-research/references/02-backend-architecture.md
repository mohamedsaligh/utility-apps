# Backend Architecture

Package structure, OOP fundamentals, SOLID, layered architecture, dependency injection, and API design — all language-agnostic.

The user's request explicitly listed: *"package structure, inheritance, abstraction, all OOPs concepts, solid design guidelines"*. This document covers each, with examples of when the textbook answer is **wrong**.

---

## Package / module structure

There are two viable layouts. Pick one per project; don't mix.

### Layout A — Layered (by technical role)

```
src/
├── controllers/    # HTTP / RPC handlers
├── services/       # Business logic
├── repositories/   # DB access
├── models/         # Domain objects
└── infrastructure/ # Cache, queue, external clients
```

Best for **small teams, single bounded context, simple domains**. Easy to navigate when the system is small. Becomes painful at scale because changing one feature touches every directory.

### Layout B — Feature / domain-oriented (by business capability)

```
src/
├── orders/
│   ├── controller.ts
│   ├── service.ts
│   ├── repository.ts
│   ├── model.ts
│   └── events.ts
├── inventory/
│   └── ...
└── shared/
    ├── auth/
    └── observability/
```

Best for **larger teams, multiple bounded contexts, microservice trajectory**. A change to "orders" lives in one folder. The `shared/` directory is reserved for genuinely cross-cutting concerns — fight to keep it small. If `shared/` grows fast, that's a smell that boundaries are wrong.

### Which to pick

- Codebase < 50k LOC, single team → Layout A.
- Codebase > 50k LOC, multiple teams or planned splits → Layout B.
- Migrating from A to B is harder than starting with B if you suspect you'll grow.

**Avoid:** mixing the two ("we have `controllers/` AND `orders/`"). It's the worst of both — code lives in two places depending on whoever wrote it.

---

## OOP fundamentals (briefly, with the honest version)

These are the canonical four. Each gets a one-line definition and a one-line caveat.

- **Encapsulation** — bundle data with the operations on it; hide internals. *Caveat:* don't write getters/setters for every field by reflex — fields you didn't intend to expose end up exposed.
- **Inheritance** — model "is-a" relationships; share behavior via class hierarchy. *Caveat:* prefer composition. Inheritance is appropriate maybe 10% of the time; composition is the better default.
- **Polymorphism** — multiple types implement a common interface, callers don't need to know which. *Caveat:* polymorphism without a stable interface is just casting in disguise.
- **Abstraction** — expose what callers need; hide what they don't. *Caveat:* premature abstraction is one of the costliest mistakes in software. See "When abstraction is wrong" below.

### When abstraction is wrong

Abstraction has a cost: every layer is one more thing to learn, one more place a bug can hide, one more file to navigate. The wins compound when the abstraction is used in many places with stable semantics. The costs compound when:

- The abstraction has one user.
- The semantics aren't actually shared (every implementation is a special case).
- The abstraction is "in case we need it later" — see Karpathy's principle: *don't design for hypothetical future requirements*.

**Rule of three:** introduce a shared abstraction the third time you see the pattern, not the first. The first time you have one example. The second time you have an opinion. The third time you have a pattern.

---

## SOLID — and when SOLID is wrong

SOLID is a useful default. It's also misapplied constantly. Each principle gets its honest treatment.

### S — Single Responsibility

*"A class should have one reason to change."*

**Useful when:** a module is doing two things that change for different reasons (e.g., user authentication AND user profile editing). Splitting them makes both easier to evolve.

**Wrong when:** applied to the level of "every method on its own class." The result is a graph of one-method classes that hides the actual behavior in 30 files. Granularity matters; "single responsibility" doesn't mean "single method".

### O — Open / Closed

*"Open for extension, closed for modification."*

**Useful when:** you have a known axis of variation (e.g., new payment providers added regularly) and a stable interface to extend along.

**Wrong when:** applied speculatively. A class "open for extension" along an axis you don't actually extend is just bloated. Don't predesign extension points; add them when the second concrete extension exists.

### L — Liskov Substitution

*"Subtypes must be substitutable for their base types."*

**Useful as a check:** if your `Square extends Rectangle` requires the `setWidth` method to also set the height, you've broken Liskov — and the inheritance was wrong.

**Wrong when:** treated as a mandate to never narrow. Sometimes a subtype legitimately doesn't support all base operations; the right answer is to fix the type hierarchy (extract a smaller interface), not to force-fit the base contract.

### I — Interface Segregation

*"Clients shouldn't depend on methods they don't use."*

**Useful when:** a fat interface forces every client to mock methods they don't care about. Split the interface.

**Wrong when:** taken to extremes (one method per interface). A handful of cohesive methods on one interface is fine. Single-method interfaces multiply for no gain.

### D — Dependency Inversion

*"Depend on abstractions, not concretions."*

**Useful when:** the dependency varies (test fakes, multiple implementations). Inject a port; receive an adapter.

**Wrong when:** applied to dependencies that don't vary. A `Logger` interface with one implementation is overhead unless you're testing without a logger or planning to swap loggers.

---

## Layered architecture (controller / service / repository)

```
┌──────────────┐  HTTP/RPC entry. No business logic. Translate
│  Controller  │  request → call service → translate response.
└──────┬───────┘
       │
┌──────▼───────┐  Business logic. Orchestrates repos, publishes events,
│   Service    │  enforces invariants. Knows the domain. Knows nothing
└──────┬───────┘  about HTTP, ORM details, or specific DB.
       │
┌──────▼───────┐  DB access. Returns domain objects (not rows). Owns
│  Repository  │  transactions. Publishes invalidation tags on writes.
└──────────────┘
```

### Rules for the layers

- **Controllers** translate, validate input shape, return responses. No domain logic. Thin.
- **Services** are the heart. They know the domain. They orchestrate repositories. They publish domain events. They do NOT call other services' DB layers; service-to-service is via the other service's API.
- **Repositories** return domain objects. They own transactions. They don't return ORM query objects (those let callers bypass the repo's contract by chaining).
- **Cross-cutting** (auth, logging, tracing, error envelopes) lives in middleware, not duplicated in each layer.

### When the layers collapse

In small projects (< 5k LOC, prototype phase), it's fine to have a controller that talks directly to an ORM. Premature layering is also a sin. Add layers when the layer earns its keep — typically when:
- A service method is called from more than one controller.
- A repository is called from more than one service.
- Transaction boundaries span multiple operations.

---

## Dependency injection

DI is how layers stay testable and swappable. Three flavors:

1. **Constructor injection** (preferred): dependencies are constructor parameters. Fails loudly at construction if missing. Easy to test.
2. **Setter injection:** dependencies set via setters after construction. Use when the dependency is genuinely optional or replaced after construction.
3. **Container-based injection** (Spring, Nest, etc.): a framework wires the graph for you. Powerful at scale; hides too much in small projects.

**Default to constructor injection.** Reach for a container only when the dependency graph is unwieldy by hand.

**Avoid:** service locator patterns (`Locator.get<UserRepo>()`) — they hide dependencies, making test setup and refactoring brittle.

---

## API design

Three styles. Pick deliberately.

### REST

- Resource-oriented. HTTP verbs map to operations (GET, POST, PUT, DELETE, PATCH).
- Best for **CRUD-shaped domains** with clear resources.
- Versioning: prefix the URL (`/v1/orders`) or use a header. Prefix is more visible; header is cleaner. Pick one per project.
- Pagination: cursor-based for large or unbounded lists; offset for small bounded lists.
- Idempotency keys for write endpoints — a client retry shouldn't double-charge.

### GraphQL

- Client picks fields and shapes. Reduces over-fetching, lets the FE iterate without BE changes per shape.
- Best for **complex client-driven UIs** with diverse data needs (mobile app + web app + dashboards from one API).
- Costs: caching is harder, n+1 query risks (use DataLoader), authorization gets complex per-field.
- Don't pick GraphQL for "REST is annoying". Pick it because the client diversity warrants it.

### RPC (gRPC, JSON-RPC)

- Function-call shape. Strongly typed (gRPC) or schema-light (JSON-RPC).
- Best for **service-to-service** communication where both sides ship together and types matter.
- Less discoverable than REST/GraphQL; not a great choice for public APIs.

### Cross-cutting API rules

- **Idempotency.** Every mutating endpoint accepts an `Idempotency-Key` header. The server stores the result keyed on the idempotency key for some window; a retry returns the stored result instead of re-executing.
- **Error envelopes.** Use a consistent shape for errors (`{error: {code, message, details}}`). Don't return string error messages to clients — they break i18n and version stability.
- **Versioning.** When you can't make a backward-compatible change, version. Don't quietly break clients.
- **Pagination defaults.** All list endpoints paginate. Default page size cap. No "fetch everything" endpoints in prod.
- **Rate limit.** Public endpoints rate-limited per credential, with consistent `429` + `Retry-After`.

---

## Cross-references

- **Persistence layer in depth** → `03-data-layer.md`.
- **Auth, secret handling, OWASP** → `07-security.md`.
- **Resilience patterns at API boundaries** → `06-resilience-observability.md`.
- **Karpathy hooks for abstraction decisions** → invoke `andrej-karpathy-skills:karpathy-guidelines` whenever you're about to introduce a new abstraction or adopt a framework.

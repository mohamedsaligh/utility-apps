# Testing Strategy

Tests exist to make change safe. Tests that don't make change safer are waste.

A good test suite catches regressions, runs fast, fails clearly, and doesn't break when implementation changes. A bad test suite is a tax on every PR.

---

## The test pyramid (as a rough guide, not gospel)

```
            ┌─────────┐
            │   E2E   │   Few. Slow. Brittle. Real value but expensive.
           ┌┴─────────┴┐
           │ Integration│  Some. Medium speed. Real DB, real services.
          ┌┴───────────┴┐
          │   Component   │  More. Fast. Test one module with collaborators.
         ┌┴───────────────┴┐
         │      Unit         │  Many. Very fast. Pure functions, isolated logic.
         └───────────────────┘
```

The pyramid is **directional** — more cheap tests at the bottom, fewer expensive tests at the top. The exact ratios depend on the system.

**Don't:** invert the pyramid (lots of slow E2E, few unit). The signal-to-pain ratio gets terrible. Don't: skip a layer because the next layer "covers it" — they catch different things.

---

## What each layer is for

### Unit tests

- **Goal:** verify a small piece of logic in isolation.
- **Speed:** milliseconds per test.
- **Test:** pure functions, business logic, edge cases, error handling.
- **Mock:** sparingly — mostly when the dependency is expensive or non-deterministic.
- **Skip:** trivial getters/setters; framework code you didn't write.

### Component / integration tests

- **Goal:** verify a module works correctly with its real collaborators (real DB, real cache, real HTTP).
- **Speed:** seconds per test, not milliseconds.
- **Test:** repository methods (against a real DB), service methods (against real repos), API endpoints (against real services).
- **Mock:** external systems you don't own (third-party APIs). Use real fakes or recorded responses (VCR-style).
- **Skip:** combinations that the unit tests already cover thoroughly.

### Contract tests

- **Goal:** verify that a service consumer and producer agree on the API shape.
- **When:** between services in a microservices architecture, or between FE and BE.
- **Tools:** Pact, Spring Cloud Contract, or hand-rolled JSON Schema validation in CI.
- **Why it matters:** integration tests run inside one service. Contract tests catch the case where Service A's update breaks Service B without anyone running the cross-service tests.

### End-to-end (E2E) tests

- **Goal:** verify a full user journey works across the whole system.
- **Speed:** seconds-to-minutes per test.
- **Test:** the 5-10 most critical user flows (sign up, login, the primary value-creating action, payment, etc.).
- **Skip:** edge cases (the cheaper layers should catch those). Visual regression unless you have a deliberate visual budget.
- **Tools:** Playwright, Cypress for web; Detox/Maestro for mobile.
- **Watch out for:** flakiness. Flaky E2E tests are worse than no E2E tests because they teach the team to ignore failures.

---

## Where to draw the unit/integration boundary

This is the most-debated question in testing. Two viable schools:

### School A — Sociable units

A "unit" is a *behavior*, tested through the public API of a small slice. Real collaborators are used by default; mocks only at the I/O boundary (DB, network).

- Tests are coupled to *behavior*, not *implementation* — refactoring within a unit doesn't break tests.
- Catches integration bugs the solitary-unit school misses.
- Slightly slower because of real collaborators.

### School B — Solitary units

A "unit" is a *class/function*, tested with all collaborators mocked. Each unit is isolated.

- Maximum speed, maximum isolation.
- Tests are coupled to *implementation* — refactoring breaks tests.
- Misses integration bugs (the integration tests must catch them).

**Recommendation:** lean School A for business logic; mock at the I/O boundary. Reach for solitary units only when collaborator setup is genuinely heavy.

The honest version: *most teams have too many solitary unit tests and too few sociable ones*. The result is high coverage that breaks on every refactor and misses real bugs.

---

## What to test (and what not to)

### Always test

- **Business logic** with edge cases (boundary conditions, off-by-one, empty/null/malformed inputs).
- **Error paths.** Code that handles failure gets less testing than code that handles success — and breaks more often.
- **Authorization rules.** "User A cannot access user B's data" tests are gold.
- **Data invariants.** "Order total = sum of line items + tax." Catches bugs that hand-edit history.
- **Critical user flows** (E2E).
- **Bug fixes.** Every fixed bug gets a regression test.

### Don't bother testing

- **Trivial code** — getters that just return a field, simple constructors.
- **Framework behavior** — you're testing the framework, not your code.
- **External libraries** — assume they work; trust the library's tests.
- **Implementation details** — e.g., "this method calls that method." Tests like this break on every refactor and tell you nothing about correctness.

### Karpathy hook

Before writing a test, ask: *what does this test let me change without fear?* If the answer is "nothing important", maybe don't write it.

---

## Test organization

### Naming

- **Describe behavior, not method names.** `test_user_cannot_login_with_wrong_password` beats `test_login()`.
- **Group by feature, not by class.** A test file per feature reads better than a test file per class. Mirror your source layout.

### Arrange / Act / Assert (AAA)

```
def test_order_total_includes_tax():
    # Arrange
    order = Order.create(items=[Item(price=100)], tax_rate=0.1)
    # Act
    total = order.total
    # Assert
    assert total == 110
```

Always identifiable A/A/A blocks. If a test is hard to write this way, the production code is probably tangled.

### Test data

- **Builders / factories** for complex objects. `OrderBuilder().with_item(price=100).with_tax(0.1).build()`.
- **No shared global state** between tests. Each test sets up and tears down what it needs.
- **Per-test DB fixtures**, not "shared seed data". Shared data leaks state and makes tests order-dependent.
- **Time / randomness control.** Inject a clock; inject a random source. Tests that fail at midnight are real bugs in the test, not the code.

---

## Mutation testing — a quality gate beyond coverage

**Code coverage is a poor metric.** "100% covered" doesn't mean "well tested" — a test that exercises code without asserting anything covers it perfectly.

**Mutation testing** mutates your code (e.g., flips `<` to `<=`, deletes lines) and checks if any test fails. If no test catches the mutation, the test suite has a gap.

Tools: Stryker (JS/TS), PIT (Java), mutmut (Python), Cargo Mutants (Rust).

**Use as a periodic check, not a gate per PR** — mutation testing is slow. Run weekly; track the score.

---

## Performance and load tests

These are tests too, just different.

- **Load tests** — sustained traffic at expected peak. Tools: k6, Locust, Gatling. Run before launch and before major changes.
- **Stress tests** — push past expected peak; observe how the system degrades. Look for graceful failure (rate limiting kicks in, latency increases linearly) vs. cliff failure (everything dies at once).
- **Soak tests** — sustained load for hours/days. Catches memory leaks, connection-pool exhaustion, slow degradations.

These are expensive; run them on a cadence (per release, weekly), not per PR.

---

## CI integration

- **Unit + component tests** run on every PR. Block merge if failing.
- **Integration tests** run on every PR if practical (< 15 min); otherwise on every merge to main.
- **E2E tests** run on every merge to main, post-deploy on staging.
- **Mutation, load, soak tests** run on a cadence (weekly, pre-release).
- **Required:** test results visible in PR. Failing tests show what failed, not just "build failed".

### Flake handling

A flaky test is **a bug**, not an inconvenience. Quarantine the flake immediately (skip with a tracking issue). Root-cause it within a sprint. Suite-wide flakes erode trust in the whole CI signal.

---

## Cross-references

- **Domain logic placement (what to unit-test)** → `02-backend-architecture.md`.
- **Repository tests against real DB** → `03-data-layer.md`.
- **Component tests at the seam** (FE) → `04-frontend-architecture.md`.
- **CI pipeline shape** → `08-ops.md`.
- **Karpathy hook** for test design — before adding a complex test framework or fixture system, ask whether the simpler thing solves the problem.

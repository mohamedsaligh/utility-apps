# Performance — Backend, Middleware, Frontend

Performance is mostly about **not doing unnecessary work**, not about clever tricks. Profile before optimizing; the bottleneck is rarely where intuition says.

The user explicitly listed: *"performance boosting from backend, middleware, frontend include best UX with users actions reactive response, preload, prefetch the UI data for smooth experience"*. This document covers each layer.

---

## Methodology — measure first

**Three-rule sequence:**

1. **Establish a budget.** Page load < 1.5s. API P95 < 200ms. Whatever the actual numbers are, write them down. Optimizations without budgets never end.
2. **Measure where you actually are.** Browser DevTools (Network, Performance, Lighthouse), backend tracing (OpenTelemetry, APM), DB query plans. Skip profiling, and you'll spend a week optimizing the wrong thing.
3. **Optimize the hot path, ignore the cold path.** A 10x improvement in code that runs once at startup is worth nothing. A 2x improvement in code that runs per request is worth everything.

**Common measurement mistakes:**
- Profiling on dev data (which is 1000x smaller than prod).
- Measuring in a clean cache state when prod has warm caches (or vice versa).
- Optimizing latency for a single request when the bottleneck is concurrency.

---

## Backend performance

### Database is almost always the bottleneck

In most apps, > 50% of request time is spent in the DB. Optimizations that don't touch the DB rarely move the needle.

**Big wins (in order of typical impact):**

1. **Fix N+1 queries.** Pattern: code loops over results from query A, issuing query B per row. 1 query becomes 101. Detect via query log + ORM `EXPLAIN`. Fix via eager loading (`include`, `joinedload`, GraphQL DataLoader).
2. **Add the missing index.** Run `EXPLAIN ANALYZE` on slow queries. If you see a `Seq Scan` on a large table with a filter, you need an index on the filter column.
3. **Reduce the data fetched.** `SELECT *` returns columns you don't need; pick the columns. Limit row count with pagination. Don't materialize the whole result set when you only need the first 10.
4. **Move work to the DB when it belongs there.** Aggregations, joins, sorting in SQL beat fetching everything and sorting in app code. The DB is built for it.
5. **Move work OUT of the DB when it doesn't.** Heavy text processing, complex business logic — keep it in app code where you can debug, test, and scale horizontally.
6. **Use connection pooling.** Every request opening a new DB connection is wasted handshake time. Use the pool sized for the DB's connection limit, not for the app's request rate.
7. **Read replicas for read-heavy workloads.** Route reads to replicas, writes to primary. Watch for replica lag in read-after-write scenarios.

### Async I/O

Synchronous I/O blocks the request thread. For I/O-bound code (most web apps), use async / non-blocking primitives. Concrete impact: a synchronous server handles ~hundreds of concurrent requests; an async one handles thousands.

**But:** if your language's ecosystem is synchronous (Ruby/Rails, traditional Python), forcing async on it half-way is worse than embracing the sync model and scaling horizontally. Pick one and commit.

### Caching is a Phase-2 decision, not a Phase-1 one

See `03-data-layer.md` for the cache decision tree. **Don't reach for caching until you've fixed the underlying queries.** A cached slow query is still a slow query on miss; on cache invalidation; on cold start. Fix the query first; cache for the second-order win.

---

## Middleware performance

Middleware runs on **every** request. A 5ms middleware sounds harmless until it's the difference between 100 and 200 RPS per server.

### Common wins

- **Compression** (gzip, brotli) for responses over a few KB. Saves bandwidth and TTFB on the client. Cheap.
- **Response batching** for chatty endpoints. If the client makes 5 requests per page, expose a batch endpoint or use HTTP/2 multiplexing efficiently.
- **Debouncing on the server side** for client-driven write-heavy endpoints (autosave, typing indicators). A 200ms debounce on the client cuts traffic 90%+ for typing.
- **Rate limiting at the edge** (CDN, API gateway), not in the app. The cheapest request to handle is the one rejected before it hits your code.
- **Caching headers** (`Cache-Control`, `ETag`, `Last-Modified`) on static-ish responses. Browsers respect them; a 304 Not Modified is ~free vs. recomputing.

### Common mistakes

- **Middleware that runs sync I/O on every request.** A "log to database" middleware that synchronously writes per request will tank throughput. Make it async, batch it, or send to a log shipper.
- **Stacking middleware indiscriminately.** Each one is overhead. Audit the chain; remove what isn't earning its keep.
- **JSON parsing twice.** Parse once at the entry, pass the parsed object through.

---

## Frontend performance

Frontend perf is about **perceived performance** as much as raw speed. A 2-second load that shows progress feels faster than a 1-second load that's blank for 1 second then suddenly appears.

### The reactive UX requirements (from the user's brief)

These are the patterns that produce a snappy feel:

#### 1. Optimistic UI

When the user does something with high success probability (toggle a like, mark a todo done, send a message), update the UI **immediately** as if it succeeded. Roll back only if the server says otherwise.

Pattern:
```
onClick:
  1. Update local state to "done"
  2. Render immediately (UI feels instant)
  3. Send mutation to server
  4. On success: keep local state (optionally reconcile with server)
  5. On failure: revert local state, show error toast
```

**Where it works:** likes, votes, simple state toggles, draft saves, sends.
**Where it doesn't:** financial transactions, irreversible actions, anything where showing "succeeded" then "actually failed" is worse than waiting.

#### 2. Preload critical assets

Critical CSS and JS for above-the-fold content should ship inline or with `<link rel="preload">` so the browser fetches them before parsing finds them.

```
<link rel="preload" href="/fonts/main.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/critical.css" as="style">
```

Below-the-fold and route-specific assets can wait.

#### 3. Prefetch likely-next data

When the user **probably** will navigate next (hovering a link, scrolling toward a viewport edge, typing in search), fetch the data they'll need before they ask.

Patterns:
- **`<link rel="prefetch">`** for likely-next routes. Browser fetches at low priority during idle.
- **Hover prefetch** — on link hover, fire the data fetch. By the time the user clicks, the data is already in cache.
- **Viewport prefetch** — IntersectionObserver triggers fetches when content nears viewport.
- **Server-state libraries** (TanStack Query) have built-in prefetch APIs.

**Don't:** prefetch everything. Bandwidth and battery cost is real on mobile. Prefetch only on strong intent signals.

#### 4. Skeleton states (not spinners)

For loads > ~200ms, show a **skeleton** of the content (gray boxes shaped like the eventual content), not a spinner. Skeletons:
- Tell the user what's coming.
- Reduce perceived wait time.
- Avoid layout shift when the content loads.

Spinners are a fallback for ambiguous loads. Use skeletons everywhere you know the shape.

#### 5. Code splitting

Don't ship the whole app on first load. Split by route; load each route's code on demand. Modern bundlers (Vite, Next, Webpack 5+) do this with dynamic imports:

```
const OrderPage = lazy(() => import('./OrderPage'));
```

The initial bundle should be small and contain only what the first paint needs. Time-to-interactive on mobile is dominated by JS parse/execute time; less code = faster.

#### 6. Debounce input, throttle scroll

- **Debounce** (wait until user stops): search input, autosave, validation. 200-300ms typical.
- **Throttle** (cap rate): scroll handlers, resize handlers, mousemove. 16-50ms typical.

Don't debounce scroll; don't throttle search-input.

#### 7. Cancel in-flight requests on navigation

User clicks "next page" while page A is still loading. The fetch for page A is now wasted bandwidth and may resolve over the new page's content. Cancel it.

Modern fetch APIs support `AbortController`. Server-state libraries handle this automatically.

### Frontend metrics that matter

- **LCP (Largest Contentful Paint)** — when the main content is visible. Budget < 2.5s.
- **INP (Interaction to Next Paint)** — how quickly the UI responds to a click/tap. Budget < 200ms.
- **CLS (Cumulative Layout Shift)** — how much content jumps around as the page loads. Budget < 0.1.
- **TTFB (Time to First Byte)** — backend / network latency. Budget < 800ms.

Lighthouse scores roll these up. Track them in CI; fail builds that regress.

### Bundle size discipline

- Add a bundle-size budget to CI (e.g., `bundlesize`, Next.js bundle analyzer). Fail PRs that bust it.
- Audit dependencies before adding. A 200kB date library for one date format is a regression.
- Tree-shake-friendly imports (`import { foo } from 'lib'` not `import lib from 'lib'`).
- Lazy-load heavy components (charts, rich-text editors) on demand.

---

## Cross-references

- **Caching at the data layer** → `03-data-layer.md`.
- **Resilience and observability** (necessary to know what's actually slow) → `06-resilience-observability.md`.
- **Frontend architecture decisions** → `04-frontend-architecture.md`.
- **UX-level decisions** (loading patterns, accessibility) → `ui-ux-pro-max:ui-ux-pro-max`.

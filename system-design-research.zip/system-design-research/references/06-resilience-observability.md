# Resilience & Observability

The user's request: *"robust, resilient, fault tolerant, self healing"*. This document covers the patterns that make systems survive partial failures, recover automatically when possible, and tell humans when something needs attention.

Resilience without observability is invisible — you don't know whether the patterns are working until something fails badly. **Treat them as one concern.**

---

## Failure modes to design for

Systems fail in patterns. Designing for the **categories** is more useful than designing for specific failures.

| Failure category | Example | Pattern to use |
|---|---|---|
| Slow / unresponsive dependency | Downstream API takes 30s | Timeout + circuit breaker |
| Transient failure | DB connection refused once | Retry with backoff |
| Overload / cascading failure | Sudden traffic spike crashes upstream | Rate limit + load shedding |
| Bad input / poison message | Malformed event in queue | Dead-letter queue |
| Network partition | Replica unreachable | Quorum / fallback to primary |
| Bug in code | Specific input crashes a handler | Crash-only design + restart |
| Resource exhaustion | OOM, file descriptors | Bulkheads, quotas |

The patterns below are the toolkit.

---

## Timeouts (the most under-applied pattern)

**Every external call needs a timeout.** This includes DB queries, HTTP requests to other services, queue operations, file I/O. Without timeouts, one slow dependency can hang every thread/coroutine in your service, taking it down.

**Defaults to set:**
- HTTP client timeouts: connect (1-2s), read (5-30s depending on endpoint).
- DB query timeouts: app-level deadline + DB-level statement timeout.
- Queue operations: read deadline.

**Rule:** if you can't articulate why this call needs more than 30 seconds, it doesn't.

---

## Retry with backoff

Transient failures (network blip, brief overload) succeed on retry. Permanent failures (bad request, missing resource) don't — and retrying them just amplifies the load.

**Retry:**
- Network errors (connection refused, timeout, DNS).
- 5xx responses on idempotent operations.
- Specific recoverable errors documented by the dependency.

**Don't retry:**
- 4xx responses (client errors — they won't get better).
- Non-idempotent operations without an idempotency key.
- Repeatedly with no upper bound.

**Backoff algorithm — exponential with jitter:**
```
delay = min(base * 2^attempt, cap) + random(0, base)
```
Jitter prevents the thundering herd when many clients retry simultaneously after a shared failure.

**Maximum attempts:** typically 3-5. Beyond that, you're either making the problem worse or the dependency genuinely won't recover and you should fail.

---

## Idempotency keys

A retry that creates a duplicate is worse than a failure. **Every mutating operation needs an idempotency key** — a client-generated unique ID per logical operation. The server stores `(idempotency_key → result)` for some window (24h is typical). Repeated requests with the same key return the stored result without re-executing.

This lets clients retry safely. Without it, every retry is a russian-roulette double-write.

Where to enforce:
- HTTP API: `Idempotency-Key` header.
- Message queue handlers: dedupe by message ID (most queues provide this).
- Background jobs: the job's natural ID (e.g., `process-order-{order_id}`) acts as the idempotency key.

---

## Circuit breaker

When a downstream is failing, retrying every request adds load to the failing system, making recovery harder. The **circuit breaker** wraps the call:

- **Closed** state: requests flow normally. Track recent failure rate.
- **Open** state: failure rate exceeded threshold. **Reject requests immediately** (return cached / fallback / error) without calling the downstream. Gives the downstream room to recover.
- **Half-open** state: after a cooldown, let one request through. If it succeeds, close the breaker. If it fails, re-open.

**Use circuit breakers** for every external dependency call. Most languages have libraries (resilience4j, polly, gobreaker, opossum).

**Pair with fallbacks** — when the breaker is open, what does the caller do? Return cached data? Degraded response? Different code path? Decide at design time.

---

## Bulkheads

Isolate resources so a failure in one area can't drain everything.

**Examples:**
- Separate thread pools / connection pools per dependency. A slow database doesn't starve the queue consumer.
- Separate process or pod per domain (microservices, when warranted).
- Quota per tenant in multi-tenant systems. One noisy tenant can't take down the others.

The metaphor: ship hulls have bulkheads so one breach doesn't sink the whole ship.

---

## Rate limiting and load shedding

When demand exceeds capacity, you have two choices: degrade gracefully or crash. Pick degrade.

**Rate limiting** — cap requests per credential, per tenant, per IP. Reject excess with `429 Too Many Requests` + `Retry-After`. Apply at the **edge** (CDN / API gateway), not in the app, so rejected requests never consume app resources.

**Load shedding** — when the system is overloaded, drop low-priority traffic. Examples: skip analytics events, pause background jobs, return cached responses. The system stays up for high-priority traffic; low-priority takes the hit.

**Adaptive concurrency limits** — algorithms (Netflix's concurrency-limits library, AIMD) that dynamically adjust the in-flight request cap based on observed latency. Keeps the system at the knee of its capacity curve without manual tuning.

---

## Dead-letter queues

A poison message (malformed, triggers a bug) will fail forever if you keep retrying. After N retries, **move it to a dead-letter queue** for human inspection.

Pattern:
- Main queue handler retries N times with backoff.
- After N failures, publish the message + error history to the dead-letter queue.
- Alarm on dead-letter queue depth > 0.
- Build a small UI / runbook for inspecting and replaying dead-letter messages.

Without a dead-letter queue, a single poison message can consume your retry budget and starve good messages behind it.

---

## Health checks and self-healing

The user explicitly wants **self-healing**. Self-healing comes from:
1. **Health checks** that distinguish "alive" from "ready" from "broken".
2. **An orchestrator** (Kubernetes, ECS, systemd) that acts on the health checks.

### Three kinds of health checks

| Check | Question | Action on failure |
|---|---|---|
| **Liveness** | Is the process still running coherently? (Not deadlocked, not OOM) | Kill and restart |
| **Readiness** | Can the process serve traffic right now? (Dependencies up, warm caches loaded) | Remove from load balancer; keep process running |
| **Startup** | Has the process finished initializing? | Suppress liveness/readiness checks until passing |

Conflating these is a common bug. A liveness check that hits the database **fails when the database is down**, killing all your healthy app processes for a database outage. **Liveness checks should be local-only.**

### Self-healing patterns

- **Crash-only design.** Code that handles "shutdown gracefully" is rarely tested. Code that handles "restart from any state" is exercised on every deploy. Bias toward crash-only — let restart be the recovery mechanism for unrecoverable states.
- **Auto-restart on crash.** Process supervisor (systemd, Kubernetes, etc.) restarts crashed processes. Combine with liveness checks for the case where the process is alive but stuck.
- **Auto-scaling on load.** Horizontal pod autoscaler scales replicas based on CPU/memory/custom metrics. Pair with rate limiting so scale-out isn't required to absorb a malicious spike.
- **Auto-failover for stateful systems.** DB primary fails → replica is promoted. Cache cluster node fails → ring rebalances. Most managed systems do this; verify the failover actually works (test it, don't just trust the docs).

---

## Observability — the triad

You can't operate what you can't see. Three pillars; each answers different questions.

### 1. Structured logs

Logs answer "what happened, in what order, with what details, for this specific request?"

**Rules:**
- **Structured (JSON), not strings.** Searchable, indexable, machine-parseable.
- **Include correlation IDs** (trace ID, request ID, user ID, tenant ID) on every log line. Lets you stitch a request's full story across services.
- **Levels**: ERROR (something needs attention), WARN (suspicious but handled), INFO (normal events worth recording), DEBUG (diagnostic detail, off in prod by default).
- **Don't log secrets.** Tokens, passwords, PII. Audit your log shipping for accidental capture.
- **Sample noisy logs.** A `INFO request received` per request is noise; sample at 1% in prod and keep the structured fields for the rest.

### 2. Metrics

Metrics answer "how is the system behaving in aggregate, over time?"

**Two useful frameworks:**

- **RED** (for request-driven services): **R**ate, **E**rrors, **D**uration. Per endpoint.
- **USE** (for resources): **U**tilization, **S**aturation, **E**rrors. Per CPU, disk, queue, connection pool.

**Per-endpoint metrics to always have:**
- Request rate (per second).
- Error rate (per second, by class).
- Latency (P50, P95, P99 — never just average).

**Cardinality discipline.** Don't include high-cardinality labels (user ID, request ID) in metrics — they explode the time-series database. Those belong in logs/traces.

### 3. Distributed traces

Traces answer "where did the time go in this specific request?"

A trace is a tree of spans. Each span is a unit of work (HTTP call, DB query, function call) with start/end timestamps and metadata. Spans have parent-child relationships.

Use OpenTelemetry — vendor-agnostic, the de facto standard. Wire trace context propagation through every service so a request's trace stitches together end-to-end.

**Sampling.** 100% trace ingestion is too expensive at scale. Sample (e.g., 1%) but always sample errors fully — when something goes wrong, you want the trace.

### When to use which

- *"Why did THIS request fail?"* → Trace + logs.
- *"Is the error rate up?"* → Metrics.
- *"What's the P99 latency right now?"* → Metrics.
- *"Walk me through what happened from request entry to response"* → Trace.
- *"What did the code log when it processed this user's order?"* → Logs.

---

## Alerting

Metrics without alerts don't wake anyone. Alerts without thresholds wake everyone.

**Rules:**
- **Alert on symptoms, not causes.** "Error rate > 1%" is a symptom; "CPU > 80%" is a cause. Alerting on causes pages people for things that may not matter; alerting on symptoms catches what does.
- **Alerts must be actionable.** Every alert needs a runbook: "this happens when X; check Y; do Z." Alerts that wake people up without action are alarm fatigue.
- **Page on customer pain.** SLO-based alerting (error budget burn rate) is the modern best practice — see Google's SRE book.
- **Suppress dependent alerts.** If "service A is down" fires, don't also page on "service B can't reach A" — group them.

---

## Cross-references

- **Performance metrics** → `05-performance.md` (LCP, INP, CLS, etc.).
- **Security observability** → `07-security.md` (audit logs, intrusion detection signals).
- **CI/CD and deployment safety** → `08-ops.md` (canary analysis, rollback triggers).
- **Karpathy hook** for "should we add this resilience pattern?" — invoke `andrej-karpathy-skills:karpathy-guidelines` before adopting heavy frameworks (service mesh, sidecars). Most resilience patterns are doable with simple libraries.

# Frontend Architecture

This document covers **architecture** — how frontend code is organized, how components compose, where state lives, how to design for known and unknown future requirements.

It does **not** cover aesthetics, color, typography, layout aesthetics, or accessibility decisions. **Delegate those to:**
- `ui-ux-pro-max:ui-ux-pro-max` for UI/UX decisions, color palettes, font pairings, accessibility rules, design-system patterns.
- `frontend-design` for distinctive aesthetic implementation, breaking out of generic AI defaults.

The split is deliberate: this skill owns *structure*; the specialist skills own *taste and rules*.

---

## Component hierarchy

Frontend has converged on a layered component model. Two well-known framings:

### Atomic design (Brad Frost)

```
Atoms     → Button, Input, Label, Icon — smallest, no business meaning
Molecules → SearchBar (Input + Button), FormField (Label + Input + ErrorText)
Organisms → Header, ProductCard, OrderSummary — complex, often domain-aware
Templates → Page-level layout skeletons with placeholder content
Pages     → Templates + real data
```

### Container / Presentational

```
Presentational → Pure UI. Receives props, renders. No data fetching.
Container      → Owns state, fetches data, passes down to presentational.
```

Both are useful framings, not religious doctrine. **Real codebases mix.** What matters is the principle behind both: **separate "what data" from "how it looks"**, so you can change one without the other.

### Practical rules

1. **Reusable components have no domain knowledge.** A `Button` doesn't know about orders. A `Card` doesn't know about users.
2. **Domain components compose reusable ones.** An `OrderCard` is built from `Card`, `Badge`, `Button`. It owns the order-shape; the primitives don't.
3. **Pages compose domain components.** A page knows the route, fetches the page-level data, and lays out the domain components.
4. **Avoid:** domain knowledge leaking into primitives. If `Button` has a `variant: "checkout"` prop, you've leaked. Make a `CheckoutButton` that wraps `Button` with that variant set.

---

## Composition over inheritance

Frontend frameworks have largely rejected inheritance. **Compose components by passing children, render-props, or hooks.** Inheritance hierarchies for components age badly — the parent class becomes a junk drawer of "things that are sometimes needed".

```
// Composition (good)
<Card>
  <Card.Header>...</Card.Header>
  <Card.Body>...</Card.Body>
  <Card.Footer>...</Card.Footer>
</Card>

// Or render-prop / slot
<Modal trigger={<Button>Open</Button>}>
  ...modal body...
</Modal>
```

Reach for inheritance only when:
- The framework genuinely uses class components (rare in modern stacks).
- A library you're extending ships base classes that work well.

---

## State management

State lives at the **lowest level it's needed at and the highest level it's shared from**. This is the lift-state-up principle.

### Decision tree

```
Is the state used by ONE component only?
  → Local component state. No further question.

Is it shared between a component and its direct parent?
  → Lift to parent. Pass down via props.

Is it shared across siblings or distant cousins?
  → Lift to nearest common ancestor. If too high, use context.

Does it span unrelated trees? (e.g., user auth, theme)
  → Application-level: context, atom-based store (Jotai/Recoil),
    or Redux/Zustand. Pick one; don't mix in one app.

Is it server-derived data?
  → Server-state library (TanStack Query, SWR, Apollo).
    These solve caching, revalidation, deduplication. Don't reinvent.
```

### Anti-patterns

- **Putting everything in global state.** Most state is local. A search input value doesn't need to be in Redux.
- **Mixing two state libraries** (Redux + Zustand + Context for the same concerns) — pick one per concern.
- **Storing derived state.** If `fullName = firstName + lastName`, don't store `fullName`. Compute it. Cached derivations get stale; computed ones don't.
- **Using context for high-frequency updates** — context re-renders all consumers. For scroll position or mouse coords, use a ref or external store.

### Server state vs. client state

These are fundamentally different. Conflating them is the #1 frontend complexity source.

| Server state | Client state |
|---|---|
| Owned by the backend | Owned by the user's session |
| Cached locally (with invalidation) | Lives in component / store |
| Asynchronous, can fail, can be stale | Synchronous, always fresh |
| Examples: user list, orders | Examples: form input, modal open/closed, theme |

Use a **server-state library** (TanStack Query, SWR, Apollo) for server state. Use **local state, lifted state, or a small client-state store** for client state. Don't put server data in Redux unless you have a deliberate reason — server-state libraries solve caching, revalidation, and deduplication that Redux doesn't.

---

## Reusable component contracts

A reusable component is a contract. The contract has four parts:

1. **Props** — what the caller provides. Be strict; reject ambiguous shapes.
2. **Children / slots** — what the caller composes inside.
3. **Events** — what the component emits (callbacks, custom events).
4. **Imperative handle** (rare) — methods callable via ref.

### Rules for the contract

- **Props are required when meaningful, optional when there's a sensible default.** Don't make everything optional "for flexibility" — flexibility hides ambiguity.
- **Don't take 15 boolean props.** If `<Button isPrimary isLarge isDisabled isLoading isFullWidth />`, refactor to a `variant` enum. Boolean props compose multiplicatively; enums don't.
- **Forward refs and props through.** A reusable `Input` should accept `ref` and arbitrary HTML attributes — caller may need them for label-association, ARIA, third-party libraries.
- **Accessibility is not optional.** If `Button` doesn't render a `<button>` element with a focus state, it's not a Button. Delegate accessibility specifics to `ui-ux-pro-max:ui-ux-pro-max`.

### Component documentation

Every reusable component needs:
- One-line description of what it is.
- Prop table with types and defaults.
- 2-3 usage examples (default, common variant, edge case).
- Accessibility notes (focus order, ARIA roles).

Storybook (or similar) makes this routine. If you're not building reusable components frequently, a `README.md` per component folder works.

---

## Knowns and unknowns — designing extension points without YAGNI

The user's request: design for "knowns and unknowns". This is a subtle problem — design for too much unknown and you over-engineer; design for too little and the unknown breaks you.

### The honest framing

You **cannot** predict unknown future requirements accurately enough to design generic abstractions for them. Every "we'll need this someday" abstraction is a coin flip on whether the actual future requirement matches the imagined one. Karpathy's discipline applies: *don't design for hypothetical future requirements*.

What you **can** do:
1. **Design for the known** with clean boundaries.
2. **Make change cheap** by keeping modules small, dependencies few, and contracts explicit.
3. **Defer the unknown** — when an actual new requirement arrives, you'll have a real shape to design against.

### Concrete tactics

**Component slots.** Instead of `<Card title={...} subtitle={...} action={...} avatar={...} icon={...} />` (anticipating every variation), expose slots: `<Card><CardHeader>...</CardHeader><CardBody>...</CardBody></Card>`. Slots accept anything; future variations are additive without prop bloat.

**Composition over configuration.** A component that takes `config={...}` is a kitchen sink. A component you compose is open-ended.

**Variant enums (not 15 booleans).** As above.

**Theming via CSS variables / tokens.** Not via per-component prop drilling. Token changes ripple; per-component overrides ossify.

**Adapter layer for external dependencies.** If you wrap (e.g.) the date library you use, swapping libraries is one file change. **But:** wrap only when there's a real chance of swapping. Wrapping every dependency speculatively is itself over-engineering.

**Don't:**
- Pre-build "extensible" plugin systems for code that has zero plugin needs today.
- Add `meta: any` props "for the future" — they become the dumping ground for unrelated features.
- Generalize a pattern from one observed case (Karpathy hook).

---

## Folder structure

Mirror the backend's layout choice (layered vs. feature-oriented) for consistency where it makes sense, but FE often differs because of route-based organization.

### Route-driven layout (most common)

```
src/
├── app/                   # routes (Next.js / Remix / etc.)
│   ├── orders/
│   │   ├── page.tsx
│   │   ├── [id]/page.tsx
│   │   └── components/    # route-local components
│   └── ...
├── components/            # cross-route reusable components
│   ├── ui/                # primitives (Button, Card, Input)
│   └── domain/            # cross-route domain components
├── lib/                   # utilities, API client, hooks
└── styles/                # tokens, global styles
```

Route-local components live with the route. Cross-route components are promoted to `components/`. Don't reach for promotion until a component is actually used in two places (rule of three applies — the third use is the trigger to extract).

---

## Cross-references

- **Performance** (preload, prefetch, code-splitting, optimistic UI, skeletons) → `05-performance.md`.
- **UX/UI decisions** → `ui-ux-pro-max:ui-ux-pro-max`.
- **Aesthetic distinctiveness** → `frontend-design`.
- **Backend layout choice** → `02-backend-architecture.md`.
- **Karpathy hook** for component abstractions → `andrej-karpathy-skills:karpathy-guidelines`.

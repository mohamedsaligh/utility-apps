# Discovery & Diagnosis

This reference branches at the top. **Greenfield** projects need *discovery*: what should we build? **Revamp** projects need *diagnosis*: what's actually there and where can we cut?

Skipping the right path produces a design for a system that doesn't exist (greenfield masquerading as revamp = "rewrite from scratch" recommendations that ignore the existing system's load-bearing complexity) or a design that ignores reality (revamp masquerading as greenfield = a beautiful spec the team can't actually migrate to).

---

## Path A — Greenfield discovery

You're starting fresh. There's no code yet, or only a sketch. Your job is to surface constraints **before** picking technologies.

### 1. Functional requirements

Capture what the system must do. Use MoSCoW (Must / Should / Could / Won't) to force prioritization. Beware of "must" inflation — if everything is must, nothing is.

Format each requirement as a verb + object + outcome: *"Members can submit time-off requests that route to their manager for approval within 2 business days."* Avoid noun-only requirements like "Time-off management" — they hide assumptions.

### 2. Non-functional requirements (NFRs)

These are the constraints that actually drive architecture. Ask explicitly:

- **Scale.** Expected users, requests/sec at peak, data volume per year, growth rate. If unknown, ask for the order of magnitude (10? 1k? 1M?).
- **Latency.** P50, P95, P99 budgets per critical path. "Fast" is not an answer.
- **Durability.** Acceptable data loss window (RPO). Acceptable downtime per year (RTO / SLA).
- **Concurrency.** Multi-user write contention model. Optimistic vs. pessimistic locking. Idempotency requirements.
- **Compliance.** GDPR, HIPAA, SOC2, PCI? These shape data residency, encryption, logging, retention.
- **Team.** Size, seniority, language fluency. Two senior backend engineers can't run 12 microservices.
- **Deploy cadence.** Daily? Weekly? Quarterly? Drives CI/CD complexity.

If the user can't answer these, **ask before designing**. Designing without NFRs produces over-engineered solutions for problems no one has.

### 3. Stakeholders & decision-makers

Who signs off? Who pays? Who's on call when it breaks? These often diverge. The architecture is constrained by the person who owns "page-when-it-fails", not just the person writing the spec.

### 4. Hard constraints

- Cloud provider locked? (Vendor relationship, existing investment.)
- Language/framework locked? (Team skills, existing tooling.)
- Deadline imposed externally? (Regulatory, contractual.)
- Budget ceiling? (Drives managed-vs-self-hosted decisions.)

These are non-negotiable inputs to the design.

### 5. Output of discovery

Before moving to Phase 2 (design), produce a **brief**:

```
SYSTEM: <name>
PURPOSE: <one sentence>

MUST DO:
  - <requirement>
  - <requirement>

NFRs:
  - Scale: <numbers>
  - Latency: <P95 budget>
  - Durability: <RPO/RTO>
  - Compliance: <regimes>
  - Team: <size + seniority>
  - Deploy cadence: <frequency>

CONSTRAINTS:
  - <hard constraint>

OPEN QUESTIONS:
  - <thing the user couldn't answer; flag for follow-up>
```

This brief is the input to every subsequent design decision. If a decision can't be traced back to it, you're designing for fiction.

---

## Path B — Revamp diagnosis

You're modernizing an existing system. The code exists. Read it before designing.

### 1. Inventory existing modules

Walk the repo. For each top-level module / service / package, note:
- Stated responsibility (from name or README).
- **Actual responsibility** (from reading the code). These often diverge — `UserService` that also handles billing because of a 2019 hotfix.
- Lines of code, last-modified date, commit frequency. Frequently-changed modules are change hotspots; rarely-changed ones are either stable or abandoned.

The output of this step is an honest module map — what exists, what each piece actually does, what's hot, what's dead.

### 2. Classify every database table

This is **required** for safe purge operations later (see `03-data-layer.md`). Every table must be classified as:
- **Transactional** — fast-changing data eligible for retention purges (orders, sessions, audit logs).
- **Static / reference** — slow-changing domain data (countries, roles, product categories). Frozen against purges.

Produce a manifest. New tables added during the revamp must be classified at the time they're added, not later.

### 3. Identify pain points (with concrete symptoms)

Don't accept "it's slow" or "it's hard to maintain". Ask:
- Latency spikes — when, how often, what triggers them?
- On-call burden — what wakes someone up?
- Merge-conflict hotspots — which files cause repeated conflicts?
- Customer complaints — top 3 by frequency.
- Dev velocity — how long does a typical change take from spec to prod?

Each pain point becomes a candidate seam for the revamp. Without concrete symptoms, you'll design solutions for imaginary pain.

### 4. Identify seams

A seam is a place where you can change something without rewriting the world. Look for:

- **Module boundaries with stable contracts.** A module that exposes a clean API can be reimplemented behind that API.
- **Data boundaries.** A table that only one module owns can be migrated independently.
- **Process boundaries.** A queue or event boundary lets you replace producers and consumers separately.
- **Adapter layers.** Existing code that wraps a third-party API can be redirected.

Seams are where the **strangler fig** pattern (see "Migration tactics" below) becomes possible. **No seams = no incremental migration possible** — you're stuck with all-or-nothing rewrites.

If you can't find seams, **create one before doing anything else**. Introducing a clean boundary around a messy module is itself a valuable revamp step, even if the module behind it stays unchanged.

#### Seam-discovery techniques (when nothing obvious presents itself)

Tangled legacy code rarely volunteers its seams. Use these tactics:

- **Characterization tests** (Michael Feathers, *Working Effectively with Legacy Code*). Pin the *current observable behavior* of a tangled function with tests, even if you don't understand why it does what it does. Once pinned, you can refactor with the safety net of "did I change anything visible?"
- **Dependency graph analysis.** Tools like `madge` (JS), `pydeps` (Python), `jdeps` (Java), `go list -deps`, or `dep-tree` (cross-language) generate import/call graphs. Look for thin connections between dense subgraphs — those are candidate seam locations.
- **Call-site analysis.** For a function suspected of being a tangle hub, count its call sites with grep / IDE-find-usages. Functions called from few sites are easier to extract; functions called from everywhere need a seam *introduced* (e.g., a facade) before they can move.
- **Co-change analysis.** Mine git history: which files change together in the same commit, often? High co-change with low logical relationship signals hidden coupling. Tools: `git log --pretty=format` parsed for file pairs, or `code-maat`.
- **Boundary by feature flag.** Even before refactoring, gate the suspected seam behind a flag. The act of forcing all callers through the flag-check surfaces every call path — and lets you dark-launch the new implementation.
- **Database schema as seam.** If two modules talk through tables, the schema *is* the contract. Lock it (no schema changes during the seam-introduction window) and you can replace either side independently.

If after these tactics the answer is "the code has no seams and no obvious place to introduce one", that's load-bearing information. The honest recommendation may be a longer-running rebuild project (with explicit executive support and feature freeze), or scoping the revamp narrower than originally framed.

### 5. Migration tactics (always prefer over big-bang rewrites)

- **Strangler fig** — wrap the old system, route progressively more traffic to the new implementation, retire old code piece by piece.
- **Parallel run** — new code runs alongside old, results compared, old remains source of truth until comparison shows N consecutive matches.
- **Branch by abstraction** — introduce an abstraction layer over the old code, then implement the new code behind that abstraction, swap, remove old.
- **Contract tests at the seam** — pin the seam's behavior with tests so both sides can be modified independently.

**Avoid** big-bang rewrites unless:
- The system is small enough to rewrite in days, not months.
- The new and old can run side-by-side with data-sync until cutover.
- You have explicit, documented executive support for an extended freeze on new features.

The default failure mode of big-bang rewrites: 18 months in, the old system has accumulated 18 months of new requirements, the new system doesn't have them, and you ship a downgrade.

### 6. Stop the bleeding (parallel to diagnosis, when production pain is active)

If diagnosis surfaces an *ongoing* customer-affecting issue (login outages, recurring 5xx storms, EOM batch jobs locking core tables, weekly deploy failures), **don't let designing the right thing block fixing the wrong thing burning down today**.

Run a tactical-fix track in parallel with the diagnosis:

- **Identify the smallest reversible change** that stops the immediate bleeding. Move reporting reads to a replica. Add a per-tenant rate limit. Increase a connection pool. Restart a process on a cron.
- **Time-box the tactical fix.** A few days, not weeks. If the tactical fix is itself a multi-week project, it's not tactical — it's a parallel design problem.
- **Document it as technical debt explicitly.** A tactical fix without an owner and a follow-up date becomes the new "load-bearing hack" no one dares touch.
- **Don't let the tactical fix become the design.** The whole point is to buy time for the proper restructure. Track that restructure as a discrete deliverable; "we'll get back to it" is how revamps die.

The cost of not running this track: customers churn while you're producing the perfect ADR.

### 7. Output of diagnosis

```
SYSTEM: <name>
CURRENT STATE: <one paragraph honest summary>

MODULES:
  - <name>: stated=<>, actual=<>, hotness=<>
  - ...

TABLE CLASSIFICATION:
  transactional: [...]
  static: [...]
  unclassified-needs-decision: [...]

PAIN POINTS (with concrete symptoms):
  1. <symptom> → <suspected cause>
  2. ...

CANDIDATE SEAMS:
  1. <module/data/process boundary> → <what we could change behind it>
  2. ...

PROPOSED MIGRATION TACTIC: <strangler/parallel/branch-by-abstraction>

RISKS:
  - <thing that could derail this>
```

---

## Common to both paths

### What to do with "we'll figure it out later"

Sometimes the user genuinely doesn't know an NFR or constraint. That's fine. **Mark it explicitly** in the brief as `OPEN QUESTION` — don't silently assume a value. Designs built on silent assumptions break exactly when the assumption turns out to be wrong.

### Karpathy hook

Before recommending any new technology, library, or framework — even one mentioned by the user — invoke `andrej-karpathy-skills:karpathy-guidelines`. The discipline check: *can the simpler thing solve this?* If the user said "we need Kafka", but a Postgres LISTEN/NOTIFY would handle their volume, surface that.

### When to push back

If discovery surfaces that the project is fundamentally misframed (e.g., "we want a new microservices architecture" but the team is two engineers and the load is 100 RPS), **say so**. Tactfully. Don't design what was asked for if what was asked for is the wrong shape. Frame it as "here's what the constraints suggest — does that match how you're thinking about it?"

---

## Cross-references

- **Once discovery is done** → load `02-backend-architecture.md`, `03-data-layer.md` for backend design.
- **Frontend design** → load `04-frontend-architecture.md` and delegate UX to `ui-ux-pro-max:ui-ux-pro-max`.
- **Migration tactics in depth** → see "Migration tactics" section above in this same document. (Strangler fig, parallel run, branch-by-abstraction, contract tests at the seam — fully covered here; no separate revamp-playbook reference needed.)

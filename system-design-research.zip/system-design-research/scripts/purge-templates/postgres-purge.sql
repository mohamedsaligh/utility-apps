-- =============================================================================
-- POSTGRES TRANSACTIONAL DATA PURGE TEMPLATE
-- =============================================================================
--
-- THIS SCRIPT WILL REFUSE TO RUN WITHOUT EXPLICIT CONFIGURATION TABLES.
-- Every table must be classified as either `transactional` (eligible for
-- purge, with its own retention field and days) or `static` (frozen, never
-- touched). New, unclassified tables cause a hard fail.
--
-- See: references/03-data-layer.md for the full execution model.
-- See: SKILL.md "Purge policy — NON-NEGOTIABLE" for the policy summary.
--
-- =============================================================================
-- USAGE
-- =============================================================================
-- The CALLER must populate two TEMP tables before invoking this script:
--
--   CREATE TEMP TABLE purge_config (
--       table_name      text NOT NULL,
--       retention_field text NOT NULL,
--       retention_days  int  NOT NULL CHECK (retention_days > 0),
--       PRIMARY KEY (table_name)
--   );
--   INSERT INTO purge_config (table_name, retention_field, retention_days) VALUES
--       ('orders',    'created_at',  90),
--       ('audit_log', 'occurred_at', 365),
--       ('sessions',  'last_seen_at', 7);
--
--   CREATE TEMP TABLE static_frozen (table_name text PRIMARY KEY);
--   INSERT INTO static_frozen VALUES ('countries'),('currencies'),('roles');
--
-- And set the following psql variables:
--
--   psql -v ON_ERROR_STOP=1 \
--        -v batch_size=1000 \
--        -v max_rows=100000 \
--        -v mode='dry-run' \
--        -v backup_age_hours=24 \
--        -f postgres-purge.sql
--
-- mode values:
--   'dry-run' (default) — counts only, no writes
--   'execute' — actually deletes; requires max_rows > 0 and verified backup
-- =============================================================================

\set ON_ERROR_STOP on

-- ---------------------------------------------------------------------------
-- 0. PARAMETER VALIDATION
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    IF :'mode' NOT IN ('dry-run', 'execute') THEN
        RAISE EXCEPTION 'mode must be dry-run or execute, got: %', :'mode';
    END IF;
    IF :'mode' = 'execute' AND (:max_rows IS NULL OR :max_rows <= 0) THEN
        RAISE EXCEPTION 'execute mode requires --max-rows > 0 (refusing unbounded delete)';
    END IF;
    IF :batch_size IS NULL OR :batch_size <= 0 THEN
        RAISE EXCEPTION 'batch_size must be > 0';
    END IF;

    -- Verify caller populated config tables
    PERFORM 1 FROM information_schema.tables
        WHERE table_schema LIKE 'pg_temp_%' AND table_name = 'purge_config';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'TEMP TABLE purge_config is missing. See header for required schema.';
    END IF;

    PERFORM 1 FROM information_schema.tables
        WHERE table_schema LIKE 'pg_temp_%' AND table_name = 'static_frozen';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'TEMP TABLE static_frozen is missing. See header for required schema.';
    END IF;

    IF (SELECT COUNT(*) FROM purge_config) = 0 THEN
        RAISE EXCEPTION 'purge_config is empty — refusing to run with no transactional tables.';
    END IF;

    RAISE NOTICE '[purge] mode=%, batch_size=%, max_rows=%', :'mode', :batch_size, :max_rows;
END $$;

-- ---------------------------------------------------------------------------
-- 1. CLASSIFICATION COMPLETENESS CHECK
--    Every user table must appear in EXACTLY ONE of purge_config or
--    static_frozen. Anything unclassified is a HARD FAIL.
-- ---------------------------------------------------------------------------
DO $$
DECLARE
    unclassified_count integer;
    unclassified_list text;
    overlap_count integer;
    overlap_list text;
BEGIN
    -- Unclassified
    SELECT COUNT(*), string_agg(table_name, ', ')
      INTO unclassified_count, unclassified_list
      FROM (
          SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
          EXCEPT
          SELECT table_name FROM purge_config
          EXCEPT
          SELECT table_name FROM static_frozen
      ) u;

    IF unclassified_count > 0 THEN
        RAISE EXCEPTION
            'Classification incomplete. % unclassified tables: %. Refusing to run.',
            unclassified_count, unclassified_list;
    END IF;

    -- Overlap (in both lists)
    SELECT COUNT(*), string_agg(table_name, ', ')
      INTO overlap_count, overlap_list
      FROM (
          SELECT table_name FROM purge_config
          INTERSECT
          SELECT table_name FROM static_frozen
      ) o;

    IF overlap_count > 0 THEN
        RAISE EXCEPTION
            '% tables appear in BOTH purge_config and static_frozen: %. Refusing.',
            overlap_count, overlap_list;
    END IF;

    RAISE NOTICE '[purge] classification check: all tables classified, no overlap';
END $$;

-- ---------------------------------------------------------------------------
-- 1b. RETENTION FIELD AUDIT
--    For each transactional table, verify the configured retention_field
--    actually exists as a column. Catches typos that would silently match
--    nothing (or worse, behave oddly under NULL semantics).
-- ---------------------------------------------------------------------------
DO $$
DECLARE
    bad record;
    bad_count integer := 0;
BEGIN
    FOR bad IN
        SELECT pc.table_name, pc.retention_field
          FROM purge_config pc
          LEFT JOIN information_schema.columns c
            ON c.table_schema = 'public'
           AND c.table_name   = pc.table_name
           AND c.column_name  = pc.retention_field
         WHERE c.column_name IS NULL
    LOOP
        RAISE WARNING '[purge] retention field FAIL: %.% does not exist',
            bad.table_name, bad.retention_field;
        bad_count := bad_count + 1;
    END LOOP;

    IF bad_count > 0 THEN
        RAISE EXCEPTION 'Retention field audit failed: % missing columns. Refusing.', bad_count;
    END IF;

    RAISE NOTICE '[purge] retention field audit passed';
END $$;

-- ---------------------------------------------------------------------------
-- 2. FOREIGN KEY AUDIT
--    Walk FKs outward from each transactional table. If any FK targets a
--    table not in either purge_config or static_frozen → HARD FAIL.
-- ---------------------------------------------------------------------------
DO $$
DECLARE
    bad_fk record;
    bad_count integer := 0;
BEGIN
    FOR bad_fk IN
        SELECT
            tc.table_name      AS source_table,
            kcu.column_name    AS source_column,
            ccu.table_name     AS target_table,
            tc.constraint_name AS fk_name
          FROM information_schema.table_constraints tc
          JOIN information_schema.key_column_usage kcu
            ON tc.constraint_name = kcu.constraint_name
           AND tc.table_schema    = kcu.table_schema
          JOIN information_schema.constraint_column_usage ccu
            ON ccu.constraint_name = tc.constraint_name
           AND ccu.table_schema    = tc.table_schema
         WHERE tc.constraint_type = 'FOREIGN KEY'
           AND tc.table_name IN (SELECT table_name FROM purge_config)
           AND ccu.table_name NOT IN (SELECT table_name FROM purge_config)
           AND ccu.table_name NOT IN (SELECT table_name FROM static_frozen)
    LOOP
        RAISE WARNING '[purge] FK audit FAIL: %.% -> % via %',
            bad_fk.source_table, bad_fk.source_column,
            bad_fk.target_table, bad_fk.fk_name;
        bad_count := bad_count + 1;
    END LOOP;

    IF bad_count > 0 THEN
        RAISE EXCEPTION 'FK audit failed: % FKs reference unclassified tables. Refusing.', bad_count;
    END IF;

    RAISE NOTICE '[purge] FK audit passed';
END $$;

-- ---------------------------------------------------------------------------
-- 3. BACKUP VERIFICATION (execute mode only)
--    Replace the placeholder query with your environment's backup-status
--    source. Default: refuses execute when uncertain.
-- ---------------------------------------------------------------------------
DO $$
DECLARE
    last_backup_age_hours numeric;
BEGIN
    IF :'mode' = 'dry-run' THEN
        RAISE NOTICE '[purge] backup check skipped (dry-run mode)';
        RETURN;
    END IF;

    -- TODO: replace with your actual source. Example:
    -- SELECT EXTRACT(EPOCH FROM (now() - last_verified_at)) / 3600
    --   INTO last_backup_age_hours
    --   FROM ops.backup_status
    --  WHERE status = 'verified'
    --  ORDER BY last_verified_at DESC LIMIT 1;
    last_backup_age_hours := NULL;

    IF last_backup_age_hours IS NULL THEN
        RAISE EXCEPTION 'No verified backup found. Wire up the backup check or run a backup. Refusing.';
    END IF;

    IF last_backup_age_hours > :backup_age_hours THEN
        RAISE EXCEPTION 'Last verified backup is % h old (limit: %). Refusing.',
            last_backup_age_hours, :backup_age_hours;
    END IF;

    RAISE NOTICE '[purge] backup verified (age: % h)', last_backup_age_hours;
END $$;

-- ---------------------------------------------------------------------------
-- 4. DRY-RUN COUNT (always)
-- ---------------------------------------------------------------------------
DO $$
DECLARE
    cfg record;
    row_count bigint;
    sql_count text;
BEGIN
    FOR cfg IN SELECT table_name, retention_field, retention_days FROM purge_config ORDER BY table_name LOOP
        sql_count := format(
            'SELECT COUNT(*) FROM %I WHERE %I < now() - ($1::text || '' days'')::interval',
            cfg.table_name, cfg.retention_field
        );
        EXECUTE sql_count INTO row_count USING cfg.retention_days;
        RAISE NOTICE '[purge] %: % rows older than % days would be deleted',
            cfg.table_name, row_count, cfg.retention_days;
    END LOOP;
END $$;

-- ---------------------------------------------------------------------------
-- 5. EXECUTION (only in execute mode)
--    Per-table batched DELETE with row-count assertions. Aborts entire run
--    on any assertion failure.
-- ---------------------------------------------------------------------------
DO $$
DECLARE
    cfg record;
    deleted_total bigint := 0;
    deleted_batch bigint;
    expected_batch bigint;
    sql_count text;
    sql_delete text;
BEGIN
    IF :'mode' = 'dry-run' THEN
        RAISE NOTICE '[purge] dry-run complete; no rows deleted';
        RETURN;
    END IF;

    FOR cfg IN SELECT table_name, retention_field, retention_days FROM purge_config ORDER BY table_name LOOP

        sql_count := format(
            'SELECT COUNT(*) FROM (SELECT 1 FROM %I WHERE %I < now() - ($1::text || '' days'')::interval LIMIT $2) s',
            cfg.table_name, cfg.retention_field
        );
        sql_delete := format(
            'WITH victims AS (SELECT ctid FROM %I WHERE %I < now() - ($1::text || '' days'')::interval LIMIT $2) ' ||
            'DELETE FROM %I WHERE ctid IN (SELECT ctid FROM victims)',
            cfg.table_name, cfg.retention_field, cfg.table_name
        );

        LOOP
            EXIT WHEN deleted_total >= :max_rows;

            EXECUTE sql_count
              INTO  expected_batch
              USING cfg.retention_days, :batch_size;

            EXIT WHEN expected_batch = 0;

            EXECUTE sql_delete
              USING cfg.retention_days, :batch_size;
            GET DIAGNOSTICS deleted_batch = ROW_COUNT;

            -- Assertion 1: deleted exactly what we expected
            IF deleted_batch <> expected_batch THEN
                RAISE EXCEPTION
                    '[purge] ASSERTION FAIL on %: expected %, deleted %. Aborting.',
                    cfg.table_name, expected_batch, deleted_batch;
            END IF;

            -- Assertion 2: never exceed batch size
            IF deleted_batch > :batch_size THEN
                RAISE EXCEPTION
                    '[purge] ASSERTION FAIL on %: deleted % > batch_size %.',
                    cfg.table_name, deleted_batch, :batch_size;
            END IF;

            deleted_total := deleted_total + deleted_batch;
            RAISE NOTICE '[purge] %: deleted % (running total: %)',
                cfg.table_name, deleted_batch, deleted_total;

            PERFORM pg_sleep(0.05);  -- brief pause for replicas
        END LOOP;
    END LOOP;

    RAISE NOTICE '[purge] execute complete; deleted % rows total', deleted_total;
END $$;

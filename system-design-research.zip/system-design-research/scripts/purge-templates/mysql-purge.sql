-- =============================================================================
-- MYSQL TRANSACTIONAL DATA PURGE TEMPLATE
-- =============================================================================
--
-- THIS SCRIPT WILL REFUSE TO RUN WITHOUT EXPLICIT CONFIGURATION.
-- Every table must be classified as `transactional` (eligible for purge,
-- with its own retention field and days) or `static` (frozen). New,
-- unclassified tables cause a hard fail.
--
-- See: references/03-data-layer.md
-- See: SKILL.md "Purge policy — NON-NEGOTIABLE"
--
-- Errors are raised via SIGNAL SQLSTATE '45000' so they propagate regardless
-- of the connection's sql_mode.
--
-- =============================================================================
-- USAGE
-- =============================================================================
-- The CALLER must populate two TEMPORARY tables before invoking this script:
--
--   CREATE TEMPORARY TABLE purge_config (
--       table_name      VARCHAR(64) NOT NULL PRIMARY KEY,
--       retention_field VARCHAR(64) NOT NULL,
--       retention_days  INT         NOT NULL CHECK (retention_days > 0)
--   );
--   INSERT INTO purge_config VALUES
--       ('orders',    'created_at',  90),
--       ('audit_log', 'occurred_at', 365),
--       ('sessions',  'last_seen_at', 7);
--
--   CREATE TEMPORARY TABLE static_frozen (
--       table_name VARCHAR(64) NOT NULL PRIMARY KEY
--   );
--   INSERT INTO static_frozen VALUES ('countries'),('currencies'),('roles');
--
-- And set session variables:
--   SET @batch_size       := 1000;
--   SET @max_rows         := 100000;          -- required if @mode = 'execute'
--   SET @mode             := 'dry-run';       -- 'dry-run' | 'execute'
--   SET @backup_age_limit := 24;              -- hours
--
-- Then: SOURCE mysql-purge.sql;
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Helper: raise an error with a message (works regardless of sql_mode)
-- ---------------------------------------------------------------------------
DELIMITER //

DROP PROCEDURE IF EXISTS _purge_raise //
CREATE PROCEDURE _purge_raise(IN msg TEXT)
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
END //

-- ---------------------------------------------------------------------------
-- 0. PARAMETER VALIDATION + CLASSIFICATION + FK AUDIT (preflight)
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS _purge_preflight //
CREATE PROCEDURE _purge_preflight()
BEGIN
    DECLARE v_count INT;
    DECLARE v_msg   TEXT;
    DECLARE v_last_backup_age INT;

    -- 0a. Param validation
    IF @mode IS NULL OR @mode NOT IN ('dry-run', 'execute') THEN
        CALL _purge_raise(CONCAT('mode must be dry-run or execute, got: ', IFNULL(@mode, 'NULL')));
    END IF;
    IF @mode = 'execute' AND (@max_rows IS NULL OR @max_rows <= 0) THEN
        CALL _purge_raise('execute mode requires @max_rows > 0 (refusing unbounded delete)');
    END IF;
    IF @batch_size IS NULL OR @batch_size <= 0 THEN
        CALL _purge_raise('@batch_size must be > 0');
    END IF;

    -- 0b. Config table existence
    SELECT COUNT(*) INTO v_count FROM information_schema.tables
       WHERE table_name = 'purge_config' AND table_schema = DATABASE();
    -- TEMPORARY tables don't appear in information_schema; verify via direct query instead
    BEGIN
        DECLARE CONTINUE HANDLER FOR SQLSTATE '42S02' BEGIN
            CALL _purge_raise('TEMPORARY TABLE purge_config missing. See header for required schema.');
        END;
        SELECT COUNT(*) INTO v_count FROM purge_config;
    END;
    IF v_count = 0 THEN
        CALL _purge_raise('purge_config is empty — refusing to run with no transactional tables.');
    END IF;
    BEGIN
        DECLARE CONTINUE HANDLER FOR SQLSTATE '42S02' BEGIN
            CALL _purge_raise('TEMPORARY TABLE static_frozen missing.');
        END;
        SELECT COUNT(*) INTO v_count FROM static_frozen;
    END;

    -- 1. Classification completeness — every base table in current schema must be
    --    in either purge_config or static_frozen.
    SELECT GROUP_CONCAT(table_name SEPARATOR ', ')
      INTO v_msg
      FROM information_schema.tables t
     WHERE t.table_schema = DATABASE()
       AND t.table_type   = 'BASE TABLE'
       AND t.table_name NOT IN (SELECT table_name FROM purge_config)
       AND t.table_name NOT IN (SELECT table_name FROM static_frozen);
    IF v_msg IS NOT NULL THEN
        CALL _purge_raise(CONCAT('Classification incomplete. Unclassified tables: ', v_msg));
    END IF;

    -- 1b. Overlap (in both lists)
    SELECT GROUP_CONCAT(pc.table_name SEPARATOR ', ')
      INTO v_msg
      FROM purge_config pc
      JOIN static_frozen sf ON pc.table_name = sf.table_name;
    IF v_msg IS NOT NULL THEN
        CALL _purge_raise(CONCAT('Tables in BOTH purge_config and static_frozen: ', v_msg));
    END IF;

    -- 1c. Retention field audit — column must exist
    SELECT GROUP_CONCAT(CONCAT(pc.table_name, '.', pc.retention_field) SEPARATOR ', ')
      INTO v_msg
      FROM purge_config pc
      LEFT JOIN information_schema.columns c
        ON c.table_schema = DATABASE()
       AND c.table_name   = pc.table_name
       AND c.column_name  = pc.retention_field
     WHERE c.column_name IS NULL;
    IF v_msg IS NOT NULL THEN
        CALL _purge_raise(CONCAT('Retention field audit FAIL — missing columns: ', v_msg));
    END IF;

    -- 2. FK audit — FKs from transactional tables must target other transactional
    --    or static-frozen tables. Anything else is a hard fail.
    SELECT GROUP_CONCAT(
               CONCAT(kcu.table_name, '.', kcu.column_name,
                      ' -> ', kcu.referenced_table_name,
                      ' (', kcu.constraint_name, ')')
               SEPARATOR '; ')
      INTO v_msg
      FROM information_schema.key_column_usage kcu
     WHERE kcu.table_schema          = DATABASE()
       AND kcu.referenced_table_name IS NOT NULL
       AND kcu.table_name IN (SELECT table_name FROM purge_config)
       AND kcu.referenced_table_name NOT IN (SELECT table_name FROM purge_config)
       AND kcu.referenced_table_name NOT IN (SELECT table_name FROM static_frozen);
    IF v_msg IS NOT NULL THEN
        CALL _purge_raise(CONCAT('FK audit FAIL: ', v_msg));
    END IF;

    -- 3. Backup verification (execute mode only)
    IF @mode = 'execute' THEN
        -- TODO: replace this with your environment's backup-status source. Example:
        -- SELECT TIMESTAMPDIFF(HOUR, last_verified_at, NOW())
        --   INTO v_last_backup_age FROM ops.backup_status
        --  WHERE status = 'verified' ORDER BY last_verified_at DESC LIMIT 1;
        SET v_last_backup_age = NULL;

        IF v_last_backup_age IS NULL THEN
            CALL _purge_raise('No verified backup found. Wire up backup check or run a backup.');
        END IF;
        IF v_last_backup_age > @backup_age_limit THEN
            CALL _purge_raise(CONCAT('Last backup ', v_last_backup_age,
                                     'h old (limit ', @backup_age_limit, 'h). Refusing.'));
        END IF;
    END IF;

    SELECT '[purge] preflight passed' AS msg;
END //

-- ---------------------------------------------------------------------------
-- 4 + 5. COUNT (always) and EXECUTE (when @mode = 'execute')
--        Iterates purge_config, building dynamic SQL per table.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS _purge_run //
CREATE PROCEDURE _purge_run()
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE v_table   VARCHAR(64);
    DECLARE v_field   VARCHAR(64);
    DECLARE v_days    INT;
    DECLARE v_count   BIGINT;
    DECLARE v_deleted_total BIGINT DEFAULT 0;
    DECLARE v_expected BIGINT;
    DECLARE v_sql     TEXT;

    DECLARE cur CURSOR FOR
        SELECT table_name, retention_field, retention_days
          FROM purge_config ORDER BY table_name;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;
    table_loop: LOOP
        FETCH cur INTO v_table, v_field, v_days;
        IF done THEN LEAVE table_loop; END IF;

        -- ---- 4. Dry-run count for this table ----
        SET @count_sql = CONCAT(
            'SELECT COUNT(*) INTO @v_count FROM `', v_table, '` ',
            'WHERE `', v_field, '` < NOW() - INTERVAL ', v_days, ' DAY'
        );
        PREPARE stmt FROM @count_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SELECT CONCAT('[purge] ', v_table, ': ', @v_count,
                      ' rows older than ', v_days, ' days would be deleted') AS msg;

        -- ---- 5. Execute (if enabled) ----
        IF @mode = 'execute' THEN
            batch_loop: LOOP
                IF v_deleted_total >= @max_rows THEN LEAVE batch_loop; END IF;

                -- Count what we're about to delete
                SET @count_batch_sql = CONCAT(
                    'SELECT COUNT(*) INTO @v_expected FROM (',
                    '  SELECT 1 FROM `', v_table, '` ',
                    '  WHERE `', v_field, '` < NOW() - INTERVAL ', v_days, ' DAY ',
                    '  LIMIT ', @batch_size, ') s'
                );
                PREPARE stmt FROM @count_batch_sql;
                EXECUTE stmt;
                DEALLOCATE PREPARE stmt;
                IF @v_expected = 0 THEN LEAVE batch_loop; END IF;

                -- Delete
                SET @del_sql = CONCAT(
                    'DELETE FROM `', v_table, '` ',
                    'WHERE `', v_field, '` < NOW() - INTERVAL ', v_days, ' DAY ',
                    'LIMIT ', @batch_size
                );
                START TRANSACTION;
                PREPARE stmt FROM @del_sql;
                EXECUTE stmt;
                DEALLOCATE PREPARE stmt;
                SET @v_deleted := ROW_COUNT();
                COMMIT;

                -- Assertion 1: deleted exactly the expected count
                IF @v_deleted <> @v_expected THEN
                    CALL _purge_raise(CONCAT('ASSERTION FAIL on ', v_table,
                                             ': expected ', @v_expected,
                                             ', deleted ', @v_deleted));
                END IF;
                -- Assertion 2: never exceed batch size
                IF @v_deleted > @batch_size THEN
                    CALL _purge_raise(CONCAT('ASSERTION FAIL on ', v_table,
                                             ': deleted ', @v_deleted,
                                             ' > batch_size ', @batch_size));
                END IF;

                SET v_deleted_total = v_deleted_total + @v_deleted;
                SELECT CONCAT('[purge] ', v_table, ': deleted ', @v_deleted,
                              ' (running total: ', v_deleted_total, ')') AS msg;
                DO SLEEP(0.05);
            END LOOP batch_loop;
        END IF;
    END LOOP table_loop;
    CLOSE cur;

    IF @mode = 'execute' THEN
        SELECT CONCAT('[purge] execute complete; deleted ', v_deleted_total, ' rows total') AS msg;
    ELSE
        SELECT '[purge] dry-run complete; no rows deleted' AS msg;
    END IF;
END //

DELIMITER ;

-- ---------------------------------------------------------------------------
-- DRIVE
-- ---------------------------------------------------------------------------
CALL _purge_preflight();
CALL _purge_run();

-- Cleanup helpers (keep the configs around for the caller's inspection)
DROP PROCEDURE _purge_preflight;
DROP PROCEDURE _purge_run;
DROP PROCEDURE _purge_raise;

// ============================================================================
// MONGODB TRANSACTIONAL DATA PURGE TEMPLATE
// ============================================================================
//
// THIS SCRIPT WILL REFUSE TO RUN WITHOUT EXPLICIT COLLECTION CLASSIFICATION.
// Every collection must be in either `transactionalCollections` (eligible)
// or `staticCollections` (frozen). New, unclassified collections cause a
// hard fail.
//
// MongoDB has no foreign-key enforcement. The FK-audit step is replaced with
// a "retention field present" check that catches the case where the field
// name is wrong on a collection (which would otherwise quietly delete
// everything).
//
// See: references/03-data-layer.md
// See: SKILL.md "Purge policy — NON-NEGOTIABLE"
//
// USAGE:
//   mongosh "mongodb://..." --eval "
//     const config = {
//       transactionalCollections: [
//         { name: 'sessions',  retentionField: 'createdAt', retentionDays: 7 },
//         { name: 'audit_log', retentionField: 'occurredAt', retentionDays: 90 }
//       ],
//       staticCollections: ['countries', 'roles', 'permissions'],
//       mode: 'dry-run',           // 'dry-run' | 'execute'
//       batchSize: 1000,
//       maxDocs: 100000,           // required if mode === 'execute'
//       lastBackupAgeHours: null,  // populate from your backup-status source
//       backupAgeLimitHours: 24
//     };
//   " purge.js
// ============================================================================

(function runPurge() {
  // -------------------------------------------------------------------------
  // 0. PARAMETER VALIDATION
  // -------------------------------------------------------------------------
  if (typeof config === "undefined") {
    throw new Error("config object is required");
  }
  const {
    transactionalCollections,
    staticCollections,
    mode,
    batchSize,
    maxDocs,
    lastBackupAgeHours,
    backupAgeLimitHours
  } = config;

  if (!["dry-run", "execute"].includes(mode)) {
    throw new Error(`mode must be 'dry-run' or 'execute', got: ${mode}`);
  }
  if (!Array.isArray(transactionalCollections) || transactionalCollections.length === 0) {
    throw new Error("transactionalCollections is required and non-empty");
  }
  if (!Array.isArray(staticCollections)) {
    throw new Error("staticCollections must be an array (use [] if none)");
  }
  if (mode === "execute" && (!Number.isInteger(maxDocs) || maxDocs <= 0)) {
    throw new Error("execute mode requires maxDocs > 0 (refusing unbounded delete)");
  }
  if (!Number.isInteger(batchSize) || batchSize <= 0) {
    throw new Error("batchSize must be a positive integer");
  }

  // Validate per-collection rules
  for (const c of transactionalCollections) {
    if (!c.name || !c.retentionField || !Number.isInteger(c.retentionDays) || c.retentionDays <= 0) {
      throw new Error(`Invalid transactional collection rule: ${JSON.stringify(c)}`);
    }
  }

  print(`[purge] mode=${mode}, batchSize=${batchSize}, maxDocs=${maxDocs ?? "n/a"}`);

  // -------------------------------------------------------------------------
  // 1. CLASSIFICATION COMPLETENESS CHECK
  // -------------------------------------------------------------------------
  const allCollections = db.getCollectionNames()
    .filter(n => !n.startsWith("system."));
  const transactionalNames = transactionalCollections.map(c => c.name);
  const classified = new Set([...transactionalNames, ...staticCollections]);
  const unclassified = allCollections.filter(n => !classified.has(n));

  if (unclassified.length > 0) {
    throw new Error(
      `Classification incomplete. Unclassified collections: ${unclassified.join(", ")}. ` +
      `Add them to transactionalCollections or staticCollections.`
    );
  }
  print("[purge] classification check passed");

  // -------------------------------------------------------------------------
  // 2. RETENTION-FIELD AUDIT (Mongo's analog of FK audit)
  //    For each transactional collection, sample a few documents and confirm
  //    the retention field exists. Catches the case where the field is named
  //    `created_at` in code but the collection actually stores `createdAt`,
  //    which would otherwise match nothing or (worse) match everything if the
  //    query plan handles missing fields oddly.
  // -------------------------------------------------------------------------
  for (const c of transactionalCollections) {
    const sample = db.getCollection(c.name).findOne({});
    if (sample && sample[c.retentionField] === undefined) {
      throw new Error(
        `Retention field audit FAIL on ${c.name}: field '${c.retentionField}' ` +
        `not present in sampled doc. Refusing.`
      );
    }
  }
  print("[purge] retention-field audit passed");

  // -------------------------------------------------------------------------
  // 3. BACKUP VERIFICATION (execute mode only)
  // -------------------------------------------------------------------------
  if (mode === "execute") {
    if (lastBackupAgeHours == null) {
      throw new Error("No verified backup info. Refusing execute. Wire up backup status.");
    }
    if (lastBackupAgeHours > backupAgeLimitHours) {
      throw new Error(
        `Last backup is ${lastBackupAgeHours}h old (limit: ${backupAgeLimitHours}h). Refusing.`
      );
    }
    print(`[purge] backup verified (${lastBackupAgeHours}h old)`);
  }

  // -------------------------------------------------------------------------
  // 4. DRY-RUN COUNT (always)
  // -------------------------------------------------------------------------
  for (const c of transactionalCollections) {
    const cutoff = new Date(Date.now() - c.retentionDays * 24 * 60 * 60 * 1000);
    const count = db.getCollection(c.name).countDocuments({
      [c.retentionField]: { $lt: cutoff }
    });
    print(`[purge] ${c.name}: ${count} docs would be deleted (older than ${cutoff.toISOString()})`);
  }

  if (mode === "dry-run") {
    print("[purge] dry-run complete; no docs deleted");
    return;
  }

  // -------------------------------------------------------------------------
  // 5. EXECUTION — batched, with assertions, capped at maxDocs total
  // -------------------------------------------------------------------------
  let deletedTotal = 0;

  for (const c of transactionalCollections) {
    const cutoff = new Date(Date.now() - c.retentionDays * 24 * 60 * 60 * 1000);
    const coll = db.getCollection(c.name);

    while (deletedTotal < maxDocs) {
      // Find a batch of victim _ids first; delete by exact id set
      const victims = coll.find({ [c.retentionField]: { $lt: cutoff } })
        .project({ _id: 1 })
        .limit(batchSize)
        .toArray();

      if (victims.length === 0) break;

      const ids = victims.map(v => v._id);
      const result = coll.deleteMany({ _id: { $in: ids } });

      // Assertion: deleted exactly the victim set
      if (result.deletedCount !== victims.length) {
        throw new Error(
          `[purge] ASSERTION FAIL on ${c.name}: expected ${victims.length}, ` +
          `deleted ${result.deletedCount}. Aborting.`
        );
      }
      // Assertion: never exceed batch size
      if (result.deletedCount > batchSize) {
        throw new Error(
          `[purge] ASSERTION FAIL on ${c.name}: deleted ${result.deletedCount} > batchSize ${batchSize}`
        );
      }

      deletedTotal += result.deletedCount;
      print(`[purge] ${c.name}: deleted ${result.deletedCount} (total: ${deletedTotal})`);

      // Brief pause to let secondaries catch up
      sleep(50);
    }
  }

  print(`[purge] execute complete; deleted ${deletedTotal} docs total`);
})();

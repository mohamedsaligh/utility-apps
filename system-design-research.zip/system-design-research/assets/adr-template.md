# ADR-NNNN: <short title of the decision>

**Status:** Proposed | Accepted | Superseded by ADR-MMMM | Deprecated
**Date:** YYYY-MM-DD
**Deciders:** <names or roles>
**Tags:** <e.g. backend, data, security>

---

## Context

What is the issue we're addressing? What forces are at play (technical, organizational, regulatory, deadline)? What constraints came out of discovery (NFRs, team size, compliance, existing investments)?

Be concrete. Numbers > adjectives. *"5k RPS at peak; 50ms P95 budget; 2-engineer backend team"* beats *"high traffic, low latency, small team"*.

---

## Options Considered

List **at least two** real options. A decision with one option isn't a decision; it's a fait accompli.

### Option 1 — <name>

- **What:** one-paragraph description.
- **Pros:** specific advantages.
- **Cons:** specific costs and risks.
- **Estimated effort:** rough order of magnitude.

### Option 2 — <name>

- **What:** ...
- **Pros:** ...
- **Cons:** ...
- **Estimated effort:** ...

### Option 3 — <name> (if applicable)

...

---

## Decision

We chose **<Option N>** because <the load-bearing reason or two>.

State the decision in one or two sentences. The detailed reasoning belongs above and below; the decision itself should be quotable.

---

## Consequences

### Positive

- <what gets better>
- <what becomes possible>

### Negative / costs

- <what gets harder>
- <what we accept as ongoing cost>

### Risks

- <what could go wrong> — mitigation: <how we'll detect or handle it>
- <what assumption we're betting on> — what would invalidate it

---

## Notes

Optional: links to related ADRs, RFCs, vendor docs, design discussions, prototype results, ticket references.

---

> **When to write an ADR:** the decision was non-obvious, an option was considered and rejected for a real reason, or a future engineer might wonder why this choice was made.
>
> **When NOT to:** the decision had no real alternative, or the reasoning is fully obvious from the code. Don't ADR-spam.

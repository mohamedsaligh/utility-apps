---
name: system-design-research
description: Use when designing system architecture, planning end-to-end technical design, doing greenfield system design, or scoping a major refactor/revamp spanning backend, frontend, data, or ops. Covers OOP/SOLID, package structure, schema design, repository/DAO layers, server-side caching with safe invalidation, performance (preload/prefetch/optimistic UI), resilience and self-healing, security, deployment, and local dev. Triggers on phrases like "design a system", "architect", "how should I structure", "revamp", "rewrite", "modernize", "plan the architecture", "what's the right way to lay out", "design end-to-end". SKIP for implementing a single function, debugging a specific error, small bug fixes, or questions answerable without cross-cutting design.
---

# System Design Research

This skill is a **router**, not a primer. The depth lives in `references/`. Your job is to: pick the right entry path, load only the references the current decision needs, delegate UX/aesthetic/AI-feature work to specialist skills, and enforce non-negotiable safeguards on dangerous operations.

The skill is language-agnostic and works for both greenfield and revamps.

## When this triggers vs. when to skip

**Trigger on:**
- "We're starting a new SaaS for X — how should we architect it?"
- "Our 2018 monolith handles auth + payments + reporting. We want to modernize. Where do we start?"
- "I'm adding multi-tenancy to an existing app. What needs to change end-to-end?"

**Skip (do NOT load this skill) on:**
- "Write a function that reverses a string."
- "Why is this test failing?" (debugging, not design)
- "Rename `foo` to `bar` across the codebase." (mechanical edit)

If the user asks something narrow but you sense the right answer requires design, name that explicitly: *"This touches caching invalidation across services — let me design that surface before patching the symptom."*

---

## Posture (read first, internalize)

Three principles govern every recommendation here. They are direct quotes / paraphrases of the discipline encoded in `andrej-karpathy-skills:karpathy-guidelines` — invoke that skill in full at the three known-risk moments listed below.

1. **Simplest thing that works.** Three similar lines beats a premature abstraction. A repo with three services beats a repo with three microservices when the team is two people.
2. **Verify before generalizing.** Make one case work end-to-end before designing the framework around N cases. The "framework" you'd derive from one example is almost always wrong.
3. **Surface assumptions.** State the constraints you're designing around (RPS, data volume, team size, latency budget, compliance scope). If you don't know them, ask — don't invent.

**Consult `andrej-karpathy-skills:karpathy-guidelines` at these moments:**
- Before adding a new abstraction layer ("should this be a base class? a factory? a generic protocol?").
- Before adopting a framework, library, or major dependency.
- Before generalizing a pattern from one observed case to a planned N.

"Consult" can mean either a literal Skill tool invocation (preferred when the decision is large or the user has opted into deeper review) or applying the discipline inline and naming it explicitly (acceptable for smaller decisions inside a fast pass). Don't silently apply the discipline — surface that you're applying it, so the user can challenge.

---

## Two entry paths

Decide first; the rest of the workflow branches.

| Signal in the user's message | Path |
|---|---|
| "new project", "starting", "from scratch", "greenfield", no existing repo cited | **Greenfield → Phase 1A** |
| "existing", "legacy", "revamp", "modernize", "rewrite", "refactor", code already in the working dir | **Revamp → Phase 1B (diagnostic-first)** |

Greenfield Phase 1 is **discovery** (what should we build?). Revamp Phase 1 is **diagnosis** (what's actually there, and where are the seams?). Skipping diagnosis on a revamp produces a "rewrite from scratch" recommendation that almost always fails. Read `references/01-discovery.md` for both paths.

---

## Phase 0 — Auto-research (conditional, not always-on)

Auto-research uses `WebSearch` and `WebFetch` to ground recommendations in current best practice. It is **conditional**. Always-on web research burns tokens and adds noise on settled topics (SOLID, GoF patterns, basic SQL).

**Do auto-research when:**
- The user names a specific, rapidly-evolving technology (a framework version, a managed service, a cloud-native component).
- The user uses words like "current", "modern", "2026", "latest best practice".
- Greenfield with no stack chosen yet — research current default stacks for the problem domain.
- Compliance/security topics where standards drift (auth standards, encryption recommendations, OWASP top 10 latest).

**Do NOT auto-research when:**
- Asking about settled fundamentals (encapsulation, normalization, REST basics).
- The user has already named a stack and is asking how to organize it.
- The question is fully answerable from reading the repo.

When you do research, search for the **specific named technology**, not the abstract concept. ("Postgres 16 partitioning best practices" — yes. "Database design best practices" — no.)

Cite what you find inline so the user can verify. If sources disagree, surface that — don't paper over it.

---

## Phase 1 — Discovery (greenfield) or Diagnosis (revamp)

Load `references/01-discovery.md`. It branches at the top into two paths with different checklists.

**Greenfield outputs:**
- Functional requirements (MoSCoW or similar).
- Non-functional requirements (RPS, latency, durability, compliance, team size, deploy cadence).
- Stakeholders and decision-makers.
- Hard constraints (cloud provider locked? language locked? deadline?).

**Revamp outputs:**
- Inventory of existing modules and their actual responsibilities (often divergent from naming).
- Classification of every database table as `transactional` or `static/reference` (this classification is required later for safe purge operations — see "Purge policy" below).
- Pain points with concrete symptoms (latency spikes? on-call burden? merge-conflict hotspots? customer complaints?).
- Identified seams — where can you change one piece without rewriting the world?

**Do not skip to design without these.** A design without grounded constraints is a design for an imaginary system.

---

## Phase 2 — Backend & data design loop

This is iterative, not linear. You may cycle through these references multiple times as decisions interact.

Load on demand:
- `references/02-backend-architecture.md` — package structure, OOP fundamentals, SOLID (with examples of when SOLID is wrong), layered architecture (controller / service / repo / DAO), dependency injection, API design (REST vs GraphQL vs RPC, versioning, idempotency keys).
- `references/03-data-layer.md` — schema design, indexing, static-vs-transactional classification, repository/DAO patterns, **caching strategy decision tree**, **full purge policy and FK-audit logic**.
- `references/06-resilience-observability.md` — circuit breakers, retry with backoff, idempotency, dead-letter queues, health checks, structured logs/metrics/traces, self-healing patterns.
- `references/07-security.md` — authN, authZ, secret management, OWASP top 10, threat modeling (STRIDE), input validation as security boundary.

**Decision sequence inside Phase 2 (default — greenfield or healthy revamp):**
1. Domain model first — identify entities, value objects, aggregates.
2. Persistence shape next — schema, indexes, normalization stance.
3. Service boundaries — what's a synchronous call, what's an event, what's a batch job?
4. Cross-cutting concerns — auth, logging, tracing, error envelopes, idempotency keys.
5. Operational safeguards — circuit breakers, retries, dead-letter queues.
6. Caching last — once you know read patterns, not before. See "Cache decision tree" below.

**Order inversion for revamps with active production pain.** If diagnosis surfaced an ongoing customer-affecting incident (login outages, recurring 5xx storms, cascading dependency failures), **flip the order**: load `06-resilience-observability.md` first and design the workload-isolation / quota / observability fix that stops the bleeding. Then return to the standard sequence for the longer-term restructure. Designing the right domain model while customers are signing in to a broken product is the wrong priority.

**Karpathy hook:** before introducing a new abstraction layer (e.g., "let's add a CQRS bus"), invoke `andrej-karpathy-skills:karpathy-guidelines` and justify why the simpler thing won't work.

---

## Phase 3 — Frontend design loop

Frontend has two distinct concerns: **architecture** (how the code is organized) and **aesthetics/UX** (how it looks and feels). This skill owns architecture; **delegate** aesthetics and UX to specialist skills.

Load on demand:
- `references/04-frontend-architecture.md` — component hierarchy (atomic design), composition over inheritance, state management patterns, reusable component contracts, "knowns/unknowns" — designing extension points without violating YAGNI.
- `references/05-performance.md` — backend bottlenecks, middleware (compression, batching, debouncing, rate limit), frontend (preload critical assets, prefetch route data, code-splitting, optimistic UI updates, skeleton states, perceived-performance tactics).

**Delegate explicitly:**
- For component styling, color, typography, layout, spacing, accessibility decisions → invoke `ui-ux-pro-max:ui-ux-pro-max`.
- For distinctive aesthetic implementation, breaking out of generic AI defaults → invoke `frontend-design`.
- Do **not** restate UX guidelines this skill doesn't own. Point and pass control.

**The reactive UX requirements the user cares about:**
- Optimistic UI for any action with high success probability.
- Preload above-the-fold critical CSS/JS; prefetch likely-next-route data on hover or viewport.
- Skeleton states (not spinners) for loads > 200ms.
- Debounced input for search; throttle for scroll/resize.
- Cancel inflight requests when the user navigates away.

These belong in `references/05-performance.md` with concrete patterns.

---

## Phase 4 — Operations

Load `references/08-ops.md`. Covers:
- CI/CD pipeline shape (lint → test → build → manual gate → deploy).
- Environment management (dev / staging / prod parity).
- Release strategy (blue-green vs. canary vs. rolling).
- Rollback strategy (must be automatic and tested, not manual on-call ritual).
- Local developer setup — one-command bootstrap, doctor script, start/stop/restart helpers, README structure for onboarding.

Templates live in `scripts/`:
- `scripts/local-setup.sh.template` — idempotent doctor + bootstrap.
- `scripts/deployment.yml.template` — GitHub Actions skeleton.

Adapt them to the project's stack; do not paste them verbatim if the stack diverges.

Also load `references/09-testing-strategy.md` here (not earlier) — testing strategy depends on what you've decided to build, so it slots in once the shape is known.

---

## Phase 5 — Synthesis (the deliverable)

The deliverable is **not** a single architecture document. It is a small set of **Architecture Decision Records (ADRs)** — one per non-obvious decision. Use `assets/adr-template.md`.

Write ADRs for decisions where:
- The choice was non-obvious and a future engineer might wonder why.
- An option was considered and rejected for a real reason.
- A constraint shaped the decision (e.g., compliance, deadline, team skill).

Do **not** write an ADR for "we chose Postgres because we needed a relational database" — that has no lost information. Do write one for "we chose Postgres over DynamoDB because team SQL fluency outweighs the operational savings of managed NoSQL at our scale".

If the user wants a single "architecture overview", produce a **short** index that points to the ADRs plus 1-2 diagrams. Resist the urge to produce a 30-page document no one will read.

---

## Plugin / skill routing table

| When you encounter… | Invoke skill |
|---|---|
| About to add an abstraction layer | `andrej-karpathy-skills:karpathy-guidelines` |
| About to adopt a framework, library, or major dependency | `andrej-karpathy-skills:karpathy-guidelines` |
| About to generalize a pattern from one example | `andrej-karpathy-skills:karpathy-guidelines` |
| UI/UX decisions: color, layout, typography, accessibility | `ui-ux-pro-max:ui-ux-pro-max` |
| Frontend aesthetic, distinctive design, breaking AI-default look | `frontend-design` |
| LLM features, prompt caching, model selection, tool use | `claude-api` |
| Creating, evaluating, or improving any other skill | `skill-creator:skill-creator` |

If a referenced skill is not installed, recommend the user install it but proceed with best-effort guidance from this skill — never fabricate that you've consulted a skill you haven't.

---

## Purge policy — NON-NEGOTIABLE

Database purge of historical/transactional data is one of the highest-blast-radius operations a system performs. The policy is restated here (in addition to the script files) because one careless edit to a SQL comment can't bypass policy if the policy lives in two places.

**The policy:**

1. **Allowlist-only, never denylist.** The caller MUST provide an explicit manifest classifying every table as either `transactional` (eligible for purge) or `static` (frozen, never touched). The script REFUSES TO RUN without the manifest.
2. **Dry-run is the default.** `--execute` requires an explicit non-zero `--max-rows` cap.
3. **Pre-flight FK audit.** The script walks foreign keys outward from each allowlisted table. If any FK targets a table not in either the transactional allowlist or the static-frozen list, the script HARD-FAILS with the named FK. This catches the case where a transactional table FKs into reference data.
4. **Backup-verified gate.** `--execute` checks that a backup completed within the last N hours and that its checksum is verified. If not, refuse.
5. **Batched deletes in transactions with row-count assertions.** Each batch asserts the deleted row count is within an expected envelope; aborts if delta exceeds Nx. This catches the case where a join-condition typo wipes the wrong scope.
6. **No-FK databases (Mongo) get a separate template** because their safety model is different. The static-frozen collection list is checked but FK introspection is skipped (because FKs don't exist).

When designing a purge for any project, produce three artifacts:
- The table/collection classification manifest (transactional vs static).
- The retention policy (per table, in days or by event).
- A test plan that runs the purge against a synthetic dataset with a deliberately-broken FK and confirms the script refuses.

See `references/03-data-layer.md` for the full execution model and `scripts/purge-templates/` for the templates.

---

## Cache auto-management — decision tree

"Auto cache management without affecting functionality" is not a single technique. Pick from:

1. **Tag-based invalidation tied to repository writes.** Every repository write publishes invalidation tags (e.g., `user:{id}`, `org:{id}`). Caches subscribe to tags. **Default for OLTP systems** with frequent writes and a need for read-after-write consistency.
2. **Versioned key prefix.** Cache keys include a version stamp; a global version bump invalidates the world. Best for **read-heavy systems with infrequent writes** where a brief warm-up after deploy is acceptable.
3. **Stale-while-revalidate (SWR) + short TTL.** Serve stale, refresh in background. Best for **tolerable-staleness reads** (dashboards, public catalogs) where strict consistency isn't required.
4. **TTL alone.** A backstop, never the primary mechanism. If your only invalidation is "wait for it to expire", the cache will silently serve wrong data and you will be debugging it at 2am.

**Required consistency check (cheap operational guard):** for every cached path, periodically assert that `cache_miss_path(input) == cache_hit_path(input)` for the same input. Catches silent divergence between the path that fills the cache and the path that returns from cache. Does not need to run on every request — a sampled background job is enough.

See `references/03-data-layer.md` for full patterns and code-shape examples.

---

## Final reminders (the load-bearing four)

- **You are a router.** Load only the references the current decision needs.
- **The deliverable is ADRs**, not an architecture-doc novel. Constraints first, then decisions.
- **For revamps with active customer pain, stop the bleeding first.** Tactical fix in parallel with diagnosis; don't let designing the right thing block fixing the wrong thing burning down today.
- **Purge policy is non-negotiable.** If the user pushes back, restate why and let them decide explicitly.

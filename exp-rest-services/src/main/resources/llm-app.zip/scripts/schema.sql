CREATE TABLE IF NOT EXISTS session_context
(
    id
    INTEGER
    PRIMARY
    KEY,
    session_id
    TEXT
    UNIQUE,
    user
    TEXT,
    context
    JSON,
    last_updated
    TIMESTAMP
    DEFAULT
    CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS validation_logs
(
    id
    INTEGER
    PRIMARY
    KEY,
    validation_type
    TEXT,
    run_at
    TIMESTAMP,
    result_summary
    TEXT,
    full_output
    JSON
);

from app.database.db import Base, engine
from app.models.session import SessionContext
from app.models.token import AuthToken  # Make sure this is included

if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    print("Database initialized.")

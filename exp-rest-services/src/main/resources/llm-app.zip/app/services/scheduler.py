from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from app.services.validation_service import ValidationService
from app.adapters.payment_client import PaymentClient
from app.utils.logger import logger

scheduler = AsyncIOScheduler()

payment_client = PaymentClient()
validation_service = ValidationService(payment_client)

async def run_static_validation():
    try:
        result = await validation_service.validate_static()
        logger.info(f"Static validation result: {result}")
    except Exception as e:
        logger.error(f"Static validation failed: {str(e)}")

async def run_transactional_validation():
    try:
        result = await validation_service.validate_transactional()
        logger.info(f"Transactional validation result: {result}")
    except Exception as e:
        logger.error(f"Transactional validation failed: {str(e)}")

def start_scheduler():
    scheduler.add_job(run_static_validation, IntervalTrigger(minutes=60))
    scheduler.add_job(run_transactional_validation, IntervalTrigger(minutes=60))
    scheduler.start()

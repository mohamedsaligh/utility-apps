import uuid
from datetime import datetime
from typing import Any


def generate_uuid() -> str:
    return uuid.uuid4().hex


def current_utc_timestamp() -> str:
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")


def is_empty(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, (str, list, dict, set, tuple)):
        return len(value) == 0
    return False


def safe_get(d: dict, keys: list, default=None) -> Any:
    value = d
    try:
        for key in keys:
            value = value[key]
        return value
    except (KeyError, TypeError):
        return default

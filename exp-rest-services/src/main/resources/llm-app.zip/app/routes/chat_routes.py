from fastapi import HTTPException

from fastapi import APIRouter, Depends
from app.schemas.chat import ChatRequest, ChatResponse
from app.dependencies import get_chat_service
from app.services.chat_service import ChatService

router = APIRouter()

@router.post("/send", response_model=ChatResponse)
async def send_message(
        request: ChatRequest,
        chat_service: ChatService = Depends(get_chat_service)
):
    try:
        return await chat_service.handle_chat(request)
    except Exception as e:
        import traceback
        print("❌ Chat error:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))

# return await chat_service.handle_chat(request)

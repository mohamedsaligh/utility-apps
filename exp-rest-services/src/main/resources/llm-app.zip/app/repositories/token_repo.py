from typing import Optional
from sqlalchemy.orm import Session
from datetime import datetime
from app.models.token import AuthToken


def get_valid_token(db: Session) -> Optional[AuthToken]:
    now = datetime.utcnow()
    token = db.query(AuthToken).filter(AuthToken.expires_at > now).first()
    print("🔐 get_valid_token() ->", token)
    return token

def store_token(db: Session, token: str, expires_at: datetime):
    token = token.strip()
    db.query(AuthToken).delete()
    db.add(AuthToken(token=token, expires_at=expires_at))
    db.commit()


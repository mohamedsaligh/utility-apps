import aiohttp
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any
from app.settings import settings
from app.models.token import AuthToken
from app.repositories.token_repo import get_valid_token, store_token
from app.utils.logger import logger

class LLMClient:
    def __init__(self, db: Session):
        self.db = db
        self.base_url = settings.LLM_API_URL
        self.username = settings.LLM_USERNAME
        self.password = settings.LLM_PASSWORD
        self.session: Optional[aiohttp.ClientSession] = None

    async def _ensure_session(self):
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10))

    async def _get_auth_token(self) -> str:
        print("📢 Getting new token from login API")
        token_obj = get_valid_token(self.db)
        if token_obj:
            logger.debug(f"✅ Using cached token: {token_obj.token}")
            return token_obj.token

        await self._ensure_session()
        payload = {"username": self.username, "password": self.password}

        async with self.session.post(f"{self.base_url}/auth/login", json=payload) as resp:
            resp.raise_for_status()
            result = await resp.json()
            token = result["access_token"]
            expiry = datetime.utcnow() + timedelta(seconds=3600)
            store_token(self.db, token, expiry)
            logger.info(f"🔐 New token stored: {token}")
            return token

    async def chat(self, message: str, context: dict, kb_id: str) -> Dict[str, Any]:
        await self._ensure_session()
        token = await self._get_auth_token()
        logger.info(f"🧾 Using token: {token}")

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        payload = {
            "message": message,
            "context": context or {},
            "knowledge_base_id": kb_id
        }

        async with self.session.post(f"{self.base_url}/chat", headers=headers, json=payload) as resp:
            if resp.status == 401:
                logger.error(f"🚫 HTTP error from LLM: 401 - Unauthorized")
            resp.raise_for_status()
            return await resp.json()

    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()


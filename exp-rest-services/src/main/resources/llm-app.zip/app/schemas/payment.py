from pydantic import BaseModel, Field
from typing import Optional, List, Any
from datetime import datetime


class Transaction(BaseModel):
    id: str
    amount: float
    status: str
    timestamp: Optional[datetime]
    metadata: Optional[dict] = None


class StaticConfigItem(BaseModel):
    id: str
    name: str
    status: str
    details: Optional[dict] = None


class TransactionListResponse(BaseModel):
    items: List[Transaction]


class StaticConfigResponse(BaseModel):
    items: List[StaticConfigItem]

from pydantic import BaseModel


class ChatRequest(BaseModel):
    session_id: str
    user: str
    message: str
    knowledge_base_id: str


class ChatResponse(BaseModel):
    session_id: str
    user: str
    reply: str

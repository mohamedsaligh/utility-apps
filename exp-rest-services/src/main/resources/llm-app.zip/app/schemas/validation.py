from pydantic import BaseModel
from typing import List, Optional, Dict, Any


class ValidationIssue(BaseModel):
    item: Optional[str]
    issue: str
    details: Optional[Dict[str, Any]] = None


class ValidationResult(BaseModel):
    status: str
    issues: List[ValidationIssue]


class ValidationRequest(BaseModel):
    type: str
    parameters: Optional[Dict[str, Any]] = None

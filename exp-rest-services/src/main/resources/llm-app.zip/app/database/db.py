import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.config import settings

# SQLite database file path (default is set in .env or settings)
DATABASE_URL = f"sqlite:///{settings.DB_PATH}"

# Create a SQLAlchemy engine
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}  # needed for SQLite in multi-threaded env
)

# Create a configured "Session" class
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# Base class for models to inherit from
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db  # provides the session
    finally:
        db.close()  # ensures cleanup

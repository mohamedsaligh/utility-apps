from pydantic_settings import BaseSettings, SettingsConfigDict

from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    LLM_API_URL: str
    LLM_API_KEY: str
    LLM_USERNAME: str
    LLM_PASSWORD: str
    PAYMENT_API_URL: str
    PAYMENT_API_KEY: str
    DB_PATH: str = "./app/database/app.db"
    LOG_LEVEL: str = "INFO"

    # class Config:
    #     env_file = ".env"
    #     extra = "allow"

    model_config = SettingsConfigDict(env_file=".env", extra="allow")

settings = Settings()

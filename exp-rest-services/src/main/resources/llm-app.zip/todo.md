### init.db

```python
from app.database.db import Base, engine
from app.models import session  # import all model files

if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    print("SQLite DB initialized successfully.")
```


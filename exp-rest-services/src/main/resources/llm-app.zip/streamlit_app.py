import streamlit as st
import requests
import uuid

st.set_page_config(page_title="💬 LLM Chatbot", layout="centered")


def perform_logout():
    try:
        st.session_state.logout_triggered = True
        requests.post(
            "http://localhost:9001/auth/logout",
            headers={"Authorization": f"Bearer {st.session_state.access_token}"}
        )
    except Exception as e:
        st.warning(f"Logout request failed: {e}")

    st.session_state.clear()
    st.query_params.update({"page": "login"})


# Session state setup
if "access_token" not in st.session_state:
    st.session_state["access_token"] = None

if "logged_in" not in st.session_state:
    st.session_state["logged_in"] = False

# Login page
if not st.session_state.logged_in:
    st.title("🔐 Login")
    username = st.text_input("Username", value="admin")
    password = st.text_input("Password", type="password", value="admin123")
    if st.button("Login"):
        res = requests.post("http://localhost:9001/auth/login", json={"username": username, "password": password})
        if res.status_code == 200:
            token = res.json().get("access_token")
            st.session_state.access_token = token
            st.session_state.logged_in = True
            st.session_state.username = username
            st.rerun()
        else:
            st.error("Login failed")
    st.stop()

# Sidebar: Logo, Title, Context Selector, Logout
with st.sidebar:
    st.image("https://cdn-icons-png.flaticon.com/512/4712/4712105.png", width=48)
    st.markdown("### 💬 LLM Chatbot")
    st.caption("Knowledge Context")

    kb_options = ["product-info", "policy-guide", "support-script"]
    kb_id = st.selectbox("Select Knowledge", kb_options)

    # st.button("🚪 Logout", on_click=lambda: st.session_state.update({"logged_in": False, "access_token": None}))
    st.sidebar.button("🚪 Logout", on_click=perform_logout)

# Main chat UI
st.title("💬 Chat with Knowledge")
st.caption("🚀 Context-aware assistant")

if "messages" not in st.session_state:
    st.session_state["messages"] = [{"role": "assistant", "content": "Hello! Select a knowledge context and start chatting."}]

if "session_id" not in st.session_state:
    st.session_state["session_id"] = uuid.uuid4().hex

# Display chat messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input
if prompt := st.chat_input("Type a message"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    placeholder = st.chat_message("assistant").empty()
    placeholder.markdown("⏳ *Assistant is typing...*", unsafe_allow_html=True)

    enriched_prompt = prompt

    try:
        response = requests.post(
            "http://localhost:8000/chat/send",
            headers={"Authorization": f"Bearer {st.session_state.access_token}"},
            json={
                "session_id": st.session_state.session_id,
                "user": st.session_state.username,
                "message": enriched_prompt,
                "knowledge_base_id": kb_id
            }
        )
        reply = response.json().get("reply", "[No reply]")

        if kb_id == "policy-guide":
            reply = f"**Policy Answer:**\n\n{reply}"
        elif kb_id == "product-info":
            reply = f"🛍️ **Product Detail:**\n\n{reply}"

    except Exception as e:
        reply = f"❌ Error: {e}"

    st.session_state.messages.append({"role": "assistant", "content": reply})
    placeholder.markdown(reply)

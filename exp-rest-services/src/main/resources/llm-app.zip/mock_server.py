from fastapi import FastAPI, Request, HTTPException, Header, Depends
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime, timedelta
import uvicorn
import secrets

app = FastAPI(title="Mock LLM + Auth + Chat")

# SQLite DB setup
DATABASE_URL = "sqlite:///./app/database/app.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

USERS = {"admin": "admin123"}
TOKENS = {}


# AuthToken table
class AuthToken(Base):
    __tablename__ = "auth_token"
    id = Column(Integer, primary_key=True)
    token = Column(String, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/auth/login")
async def login(request: Request, db: Session = Depends(get_db)):
    data = await request.json()
    username = data.get("username")
    password = data.get("password")

    if username != "admin" or password != "admin123":
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = secrets.token_hex(16)
    expiry = datetime.utcnow() + timedelta(seconds=3600)

    db.query(AuthToken).delete()
    db.add(AuthToken(token=token, expires_at=expiry))
    db.commit()

    return {"access_token": token}


# Validate token from DB
def validate_token(authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Malformed token")

    token = authorization.split(" ")[1].strip()
    auth_token = db.query(AuthToken).filter(AuthToken.token == token, AuthToken.expires_at > datetime.utcnow()).first()

    if not auth_token:
        raise HTTPException(status_code=401, detail="Token expired or invalid")

    return "mock-user"


@app.post("/chat")
async def chat_endpoint(request: Request, user=Depends(validate_token)):
    data = await request.json()
    message = data.get("message", "")
    kb = data.get("knowledge_base_id", "general")
    reply = f"[{kb.upper()}] LLM says: {message[::-1]}"
    return {"reply": reply, "context": {"received": True, "kb": kb}}


@app.post("/auth/logout")
async def logout(authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Malformed token")

    token = authorization.split(" ")[1].strip()

    token_obj = db.query(AuthToken).filter(AuthToken.token == token).first()
    if not token_obj:
        raise HTTPException(status_code=401, detail="Invalid token")


if __name__ == "__main__":
    uvicorn.run("mock_server:app", host="0.0.0.0", port=9001, reload=True)